module.exports = {
  apps: [
    {
      name: 'iq-puzzle',
      script: 'npx',
      args: 'tsx server.ts',
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_memory_restart: '768M',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
    },
  ],
};
