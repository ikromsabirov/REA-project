import 'dotenv/config';
import express from 'express';
import http from 'http';
import { isIP } from 'net';
import path from 'path';
import helmet from 'helmet';
import rateLimit, { ipKeyGenerator } from 'express-rate-limit';
import { createServer as createViteServer } from 'vite';
import { initDatabase } from './server/db.ts';
import { apiRouter } from './server/routes.ts';
import { setupSocketServer } from './server/socket.ts';

function extractClientIp(req: express.Request): string {
  const forwarded = req.headers.forwarded;
  if (typeof forwarded === 'string' && forwarded.length > 0) {
    const ipv6BracketMatch = forwarded.match(/for="?\[([^\]]+)\]/i);
    if (ipv6BracketMatch?.[1] && isIP(ipv6BracketMatch[1])) {
      return ipv6BracketMatch[1];
    }
    const plainMatch = forwarded.match(/for="?([^;\s",]+)/i);
    if (plainMatch?.[1]) {
      const raw = plainMatch[1];
      const colonCount = (raw.match(/:/g) || []).length;
      const candidate = colonCount === 1 ? raw.replace(/:\d+$/, '') : raw;
      if (isIP(candidate)) return candidate;
    }
  }
  return req.ip || req.socket.remoteAddress || '127.0.0.1';
}

async function startServer() {
  initDatabase();

  const app = express();
  app.set('trust proxy', 1);
  const server = http.createServer(app);
  const port = Number(process.env.PORT || 3000);

  // Security middleware (frame-friendly for AI Studio preview iframe)
  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
      frameguard: false,
    })
  );

  app.use(express.json({ limit: '4mb' }));

  const keyGenerator = (req: express.Request) => ipKeyGenerator(extractClientIp(req));

  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 600,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    keyGenerator,
    validate: { forwardedHeader: false },
  });
  app.use('/api', apiLimiter);

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 60,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    keyGenerator,
    validate: { forwardedHeader: false },
  });
  app.use('/api/auth', authLimiter);

  // Mount REST API routes
  app.use('/api', apiRouter);

  // Attach Socket.IO real-time server on the same HTTP server (port 3000)
  setupSocketServer(server);

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(port, '0.0.0.0', () => {
    console.log(`IQ PUZZLE server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start IQ PUZZLE server:', err);
  process.exit(1);
});
