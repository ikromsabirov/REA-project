# IQ PUZZLE — Serverga joylaştiriş qöllanmasi

Uşbu arxivda **IQ PUZZLE** platformasining töliq frontend va backend kodi hamda mavjud öyinlar ma'lumotlar bazasi (`data/iq_puzzle.db`) jamlangan.

## Talablar
- **Node.js 22.13+** (ichki `node:sqlite` moduli uçun Node 22 tavsiya etiladi) yoki **Docker**
- Kamida 512 MB RAM va 1 GB böş joy

---

## 1-usul: Docker orqali işga tuşiriş (Eng tez usul)

1. Arxivni serverda oçing:
   ```bash
   unzip iq-puzzle-server-deploy.zip -d iq-puzzle
   cd iq-puzzle
   ```
2. Muhit özgaruvçilarini sozlang:
   ```bash
   cp .env.example .env
   nano .env
   ```
   `JWT_SECRET`, `KEY_ENCRYPTION_SECRET`, `APP_URL` va kerak bölsa `GEMINI_API_KEY` qiymatlarini kiriting.
3. Serverni işga tuşiring:
   ```bash
   docker compose up -d --build
   ```
4. Platforma `http://<server-ip>:3000` manzilida oçiladi. `data/iq_puzzle.db` fayli `./data` papkasida doimiy saqlanadi.

---

## 2-usul: Linux VPS (Node.js 22 + PM2 + Nginx)

1. Node.js 22 va PM2 örnating:
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
   sudo apt-get install -y nodejs
   sudo npm install -g pm2
   ```
2. Arxivni oçing va paketlarni örnating:
   ```bash
   unzip iq-puzzle-server-deploy.zip -d iq-puzzle
   cd iq-puzzle
   cp .env.example .env
   nano .env
   npm install
   npm run build
   ```
3. PM2 bilan fon rejimida işga tuşiring:
   ```bash
   pm2 start ecosystem.config.cjs
   pm2 save
   pm2 startup
   ```

### Nginx + WebSocket (Socket.IO) sozlamasi

```nginx
server {
    listen 80;
    server_name your-domain.uz;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

HTTPS sertifikat uçun:
```bash
sudo certbot --nginx -d your-domain.uz
```

---

## Ma'lumotlar bazasi haqida
- Mavjud barça öyinlar, savollar, foydalanuvçilar va natijalar `data/iq_puzzle.db` faylida saqlangan.
- Serverda zaxira nusxa (backup) oliş uçun `data/iq_puzzle.db` faylini nusxalaş kifoya.
