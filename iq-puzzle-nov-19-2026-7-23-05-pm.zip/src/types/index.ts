export type Language = 'uz' | 'ru' | 'en';
export type Theme = 'light' | 'dark';
export type Difficulty = 'easy' | 'medium' | 'hard';
export type ResultDisplayMode = 'after_each' | 'after_finish' | 'live_leaderboard';
export type AIProvider = 'gemini' | 'openai' | 'anthropic';

export interface User {
  id: string;
  fullName: string;
  login: string;
  email: string;
  role: 'teacher' | 'admin';
  preferredLang: Language;
}

export interface QuestionItem {
  id?: string;
  orderIndex?: number;
  prompt: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
  isApproved?: boolean;
  aiGenerated?: boolean;
}

export interface GameRecord {
  id: string;
  teacher_id: string;
  teacher_name?: string;
  title: string;
  language: Language;
  subject: string;
  difficulty: Difficulty;
  question_count: number;
  actual_question_count?: number;
  approved_question_count?: number;
  time_per_question: number;
  points_per_question: number;
  total_duration_minutes: number;
  max_students: number;
  scheduled_at: string | null;
  result_display_mode: ResultDisplayMode;
  creation_method: 'manual' | 'ai';
  status: 'draft' | 'published';
  ai_topic: string | null;
  ai_provider: string | null;
  game_type?: string;
  category?: string;
  hints_limit?: number;
  config_json?: string;
  created_at: string;
  updated_at: string;
}

export interface CompetitionSummary {
  id: string;
  game_id: string;
  teacher_id: string;
  title: string;
  class_name: string;
  code: string;
  status: 'waiting' | 'active' | 'finished';
  game_title?: string;
  game_language?: Language;
  subject?: string;
  game_type?: string;
  category?: string;
  participant_count?: number;
  created_at: string;
  started_at?: string | null;
  ended_at?: string | null;
}

export interface ParticipantItem {
  rank: number;
  id: string;
  displayName: string;
  className: string;
  score: number;
  correctCount: number;
  wrongCount: number;
  totalTimeMs: number;
  connected: boolean;
  finishedAt?: string | null;
  joinedAt: string;
}

export interface CompetitionSnapshot {
  competition: {
    id: string;
    title: string;
    className: string;
    code: string;
    status: 'waiting' | 'active' | 'finished';
    currentQuestionIndex: number;
    totalQuestions: number;
    questionStartedAt: number | null;
    remainingSec: number;
    startedAt: string | null;
    endedAt: string | null;
  };
  game: {
    id: string;
    title: string;
    language: Language;
    subject: string;
    difficulty: Difficulty;
    questionCount: number;
    timePerQuestion: number;
    pointsPerQuestion: number;
    totalDurationMinutes: number;
    maxStudents: number;
    resultDisplayMode: ResultDisplayMode;
    gameType: string;
    category: string;
    hintsLimit: number;
    config?: Record<string, unknown>;
    seed?: number;
  };
  currentQuestion: {
    id: string;
    index: number;
    prompt: string;
    options: string[];
    correctIndex?: number;
    explanation?: string;
  } | null;
  answeredParticipantIds: string[];
  participants: ParticipantItem[];
  questionsReview?: Array<{
    id: string;
    prompt: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  }>;
  joinUrl?: string;
  qrDataUrl?: string;
}

export interface LeaderboardEntry {
  rank: number;
  id: string;
  displayName: string;
  className: string;
  score: number;
  correctCount: number;
  wrongCount: number;
  totalTimeMs: number;
  competitionId: string;
  competitionTitle: string;
  competitionCode: string;
  subject: string;
  language: Language;
  joinedAt: string;
}
