import type { Difficulty, Language } from '../types';

export type GameCategoryId =
  | 'logic'
  | 'memory'
  | 'spatial'
  | 'attention'
  | 'math'
  | 'words';

export type GameTypeId =
  | 'iq-matrix'
  | 'sequence'
  | 'logic-grid'
  | 'matchstick'
  | 'odd-one-out'
  | 'memory-cards'
  | 'simon-memory'
  | 'image-memory'
  | 'number-memory'
  | 'rotation-3d'
  | 'paper-folding'
  | 'tangram'
  | 'cube-net'
  | 'find-difference'
  | 'stroop'
  | 'hidden-objects'
  | 'number-search'
  | 'sudoku'
  | 'number-crossword'
  | 'make-24'
  | 'number-pyramid'
  | 'word-search'
  | 'anagram'
  | 'rebus'
  | 'word-association';

export interface CommonGameSettings {
  gameType: GameTypeId;
  title: string;
  language: Language;
  difficulty: Difficulty;
  stagesCount: number;
  timePerTaskSec: number;
  timerEnabled: boolean;
  maxScore: number;
  hintsLimit: number;
  showExplanation: boolean;
  customTasks?: unknown[];
  seed?: number;
}

export interface StageOutcome {
  stageIndex: number;
  isCorrect: boolean;
  pointsAwarded: number;
  timeTakenMs: number;
  hintsUsed: number;
  explanation?: string;
}

export interface GameResultSummary {
  gameType: GameTypeId;
  category: GameCategoryId;
  difficulty: Difficulty;
  language: Language;
  score: number;
  maxScore: number;
  correctCount: number;
  wrongCount: number;
  hintsUsed: number;
  timeSpentMs: number;
  accuracy: number;
  stages: StageOutcome[];
}

export interface GamePlayProps {
  settings: CommonGameSettings;
  mode: 'practice' | 'competition';
  onStageComplete?: (outcome: StageOutcome) => void;
  onGameComplete: (result: GameResultSummary) => void;
  onExit?: () => void;
}

export interface GameCatalogEntry {
  id: GameTypeId;
  number: number;
  category: GameCategoryId;
  avgDurationMin: number;
  maxScore: number;
  defaultStages: number;
  defaultTimeSec: number;
  has3D?: boolean;
  hasAudio?: boolean;
  accentColor: string;
  name: Record<Language, string>;
  description: Record<Language, string>;
  typeLabel: Record<Language, string>;
}
