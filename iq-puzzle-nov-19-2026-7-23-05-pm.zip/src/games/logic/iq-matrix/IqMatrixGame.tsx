import { useEffect, useMemo, useState } from 'react';
import { ShapeSvg, type GeoShapeSpec, type GeoShapeType } from '../../shared/ShapeSvg';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface MatrixStage {
  gridSize: 3 | 4;
  cells: Array<GeoShapeSpec | null>; // last cell is null
  options: GeoShapeSpec[];
  correctIndex: number;
  explanation: string;
}

const SHAPES: GeoShapeType[] = ['circle', 'triangle', 'square', 'diamond', 'pentagon', 'hexagon', 'star'];
const COLORS = ['#4f46e5', '#0284c7', '#059669', '#d97706', '#e11d48'];

function specKey(s: GeoShapeSpec): string {
  return `${s.shape}|${s.color}|${s.rotation || 0}|${s.fill || 'solid'}|${s.count || 1}|${s.scale || 1}`;
}

function generateMatrixStages(
  count: number,
  difficulty: Difficulty,
  lang: Language,
  seed: number
): MatrixStage[] {
  const rng = createSeededRng(seed);
  const stages: MatrixStage[] = [];
  const gridSize: 3 | 4 = difficulty === 'hard' ? 4 : 3;
  const optCount = difficulty === 'easy' ? 4 : 6;

  for (let i = 0; i < count; i++) {
    const rowShapes = [...SHAPES].sort(() => rng() - 0.5).slice(0, gridSize);
    const rowColors = [...COLORS].sort(() => rng() - 0.5).slice(0, gridSize);
    const rotStep = difficulty === 'easy' ? 0 : 90;
    const baseRot = Math.floor(rng() * 4) * 90;

    const cells: Array<GeoShapeSpec | null> = [];
    let answerSpec: GeoShapeSpec = { shape: 'circle', color: COLORS[0] };

    for (let r = 0; r < gridSize; r++) {
      for (let c = 0; c < gridSize; c++) {
        const shape = rowShapes[(r + c) % gridSize];
        const color = difficulty === 'easy' ? rowColors[r] : rowColors[(r + 2 * c) % gridSize];
        const rotation = (baseRot + c * rotStep + r * (difficulty === 'hard' ? 45 : 0)) % 360;
        const fill: GeoShapeSpec['fill'] =
          difficulty === 'hard' ? (['solid', 'outline', 'tinted'][c % 3] as GeoShapeSpec['fill']) : 'solid';
        const specCount = difficulty === 'medium' || difficulty === 'hard' ? ((r + c) % 3) + 1 : 1;

        const spec: GeoShapeSpec = {
          shape,
          color,
          rotation,
          fill,
          count: specCount,
        };
        if (r === gridSize - 1 && c === gridSize - 1) {
          answerSpec = spec;
          cells.push(null);
        } else {
          cells.push(spec);
        }
      }
    }

    const distractors: GeoShapeSpec[] = [];
    const seen = new Set<string>([specKey(answerSpec)]);
    let guard = 0;
    while (distractors.length < optCount - 1 && guard < 100) {
      guard++;
      const cand: GeoShapeSpec = {
        shape: rowShapes[Math.floor(rng() * rowShapes.length)],
        color: rowColors[Math.floor(rng() * rowColors.length)],
        rotation: (answerSpec.rotation! + [0, 90, 180, 270][Math.floor(rng() * 4)]) % 360,
        fill: answerSpec.fill,
        count: Math.max(1, ((answerSpec.count || 1) + Math.floor(rng() * 3) - 1) % 4 || 1),
      };
      const k = specKey(cand);
      if (!seen.has(k)) {
        seen.add(k);
        distractors.push(cand);
      }
    }

    const options = [...distractors];
    const correctIndex = Math.floor(rng() * optCount);
    options.splice(correctIndex, 0, answerSpec);

    const explanation =
      lang === 'ru'
        ? `В каждой строке и столбце фигуры, цвета и количество (${answerSpec.count}) следуют циклическому сдвигу.`
        : lang === 'en'
          ? `Each row and column shifts shape, color, rotation (${answerSpec.rotation}°), and count (${answerSpec.count}).`
          : toNewUzbekAlphabet(
              `Har bir qator va ustunda shakl, rang, burchak (${answerSpec.rotation}°) hamda son (${answerSpec.count}) siklik tarzda almashadi.`
            );

    stages.push({ gridSize, cells, options, correctIndex, explanation });
  }
  return stages;
}

export function IqMatrixGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [eliminatedOpts, setEliminatedOpts] = useState<number[]>([]);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(() => {
    if (settings.customTasks && settings.customTasks.length > 0) {
      return settings.customTasks as MatrixStage[];
    }
    return generateMatrixStages(
      settings.stagesCount,
      settings.difficulty,
      settings.language,
      settings.seed || Date.now()
    );
  }, [settings]);

  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || selectedOpt !== null) return;
    if (timeLeft <= 0) {
      handleChoose(-1);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, selectedOpt]);

  const handleUseHint = () => {
    if (hintsLeft <= 0 || selectedOpt !== null || !current) return;
    const wrongIndices = current.options
      .map((_, idx) => idx)
      .filter((idx) => idx !== current.correctIndex && !eliminatedOpts.includes(idx));
    if (wrongIndices.length === 0) return;
    const toRemove = wrongIndices.slice(0, Math.max(1, Math.floor(wrongIndices.length / 2)));
    setEliminatedOpts((prev) => [...prev, ...toRemove]);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleChoose = (optIdx: number) => {
    if (selectedOpt !== null || !current) return;
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const isCorrect = optIdx === current.correctIndex;
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    setSelectedOpt(optIdx);
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: current.explanation,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} ${
        settings.showExplanation ? `— ${current.explanation}` : ''
      }`,
    });

    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'iq-matrix',
          category: 'logic',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setSelectedOpt(null);
        setFeedback(null);
        setEliminatedOpts([]);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1500);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setSelectedOpt(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setEliminatedOpts([]);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-8">
        {/* Matrix Grid */}
        <div
          className="mx-auto grid gap-3 sm:gap-4"
          style={{
            maxWidth: current.gridSize === 4 ? '540px' : '460px',
            gridTemplateColumns: `repeat(${current.gridSize}, minmax(0, 1fr))`,
          }}
        >
          {current.cells.map((cell, idx) => (
            <div
              key={idx}
              className={`aspect-square flex items-center justify-center rounded-2xl border p-2 ${
                cell === null
                  ? 'border-dashed border-2 border-indigo-500 bg-indigo-50/60 dark:bg-indigo-950/30 font-display text-3xl sm:text-4xl font-bold text-indigo-600 dark:text-indigo-400'
                  : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950'
              }`}
            >
              {cell ? <ShapeSvg spec={cell} size={current.gridSize === 4 ? 96 : 116} /> : '?'}
            </div>
          ))}
        </div>

        {/* Options */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 max-w-2xl mx-auto">
          {current.options.map((opt, idx) => {
            const isEliminated = eliminatedOpts.includes(idx);
            const isSelected = selectedOpt === idx;
            const isCorrect = selectedOpt !== null && idx === current.correctIndex;
            const isWrong = isSelected && idx !== current.correctIndex;

            return (
              <button
                key={idx}
                type="button"
                disabled={selectedOpt !== null || isEliminated}
                onClick={() => handleChoose(idx)}
                className={`flex items-center justify-center rounded-2xl border p-4 transition-all cursor-pointer disabled:cursor-default ${
                  isEliminated
                    ? 'opacity-20 border-slate-200 dark:border-slate-800'
                    : isCorrect
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40'
                      : isWrong
                        ? 'border-red-500 bg-red-50 dark:bg-red-950/40'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:border-indigo-500 hover:bg-indigo-50/40 dark:hover:bg-indigo-950/20'
                }`}
              >
                <ShapeSvg spec={opt} size={98} />
              </button>
            );
          })}
        </div>
      </div>
    </GameShell>
  );
}
