import { useEffect, useMemo, useState } from 'react';
import { ShapeSvg, type GeoShapeSpec, type GeoShapeType } from '../../shared/ShapeSvg';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface SequenceStage {
  kind: 'number' | 'shape' | 'symbol';
  items: Array<string | GeoShapeSpec>;
  options: Array<string | GeoShapeSpec>;
  correctIndex: number;
  explanation: string;
}

const GEO_SHAPES: GeoShapeType[] = ['triangle', 'square', 'pentagon', 'hexagon', 'circle', 'star'];
const COLORS = ['#4f46e5', '#0284c7', '#059669', '#d97706', '#e11d48'];
const SYMBOLS = ['◆', '▲', '●', '■', '★', '✦'];

function generateSequenceStages(
  count: number,
  difficulty: Difficulty,
  lang: Language,
  seed: number
): SequenceStage[] {
  const rng = createSeededRng(seed);
  const stages: SequenceStage[] = [];

  for (let i = 0; i < count; i++) {
    const mode = i % 3;
    if (mode === 0) {
      // Numeric sequence
      let seq: number[] = [];
      let answer = 0;
      let expUz = '';
      let expRu = '';
      let expEn = '';

      if (difficulty === 'easy') {
        const start = Math.floor(rng() * 8) + 2;
        const step = Math.floor(rng() * 6) + 2;
        seq = [0, 1, 2, 3, 4].map((k) => start + k * step);
        answer = start + 5 * step;
        expUz = `Har bir keyingi son +${step} ga ortib bormoqda.`;
        expRu = `Каждое следующее число увеличивается на +${step}.`;
        expEn = `Each step increases by +${step}.`;
      } else if (difficulty === 'medium') {
        const start = Math.floor(rng() * 3) + 2;
        const mult = Math.floor(rng() * 2) + 2;
        seq = [0, 1, 2, 3, 4].map((k) => start * Math.pow(mult, k));
        answer = start * Math.pow(mult, 5);
        expUz = `Har bir had ${mult} ga ko'paytirilmoqda.`;
        expRu = `Каждый элемент умножается на ${mult}.`;
        expEn = `Each term is multiplied by ${mult}.`;
      } else {
        // Hard: alternating +a, ×2 or second-order differences
        const base = Math.floor(rng() * 5) + 2;
        const d1 = Math.floor(rng() * 3) + 2;
        seq = [base];
        for (let k = 1; k <= 4; k++) {
          seq.push(seq[k - 1] + d1 * k);
        }
        answer = seq[4] + d1 * 5;
        expUz = `Farqlar har qadamda +${d1} ga ortib bormoqda (+${d1}, +${d1 * 2}, +${d1 * 3}...).`;
        expRu = `Разность увеличивается на +${d1} на каждом шаге.`;
        expEn = `Differences grow by +${d1} at each step.`;
      }

      const distractors = new Set<number>([answer]);
      while (distractors.size < 4) {
        const delta = (Math.floor(rng() * 7) - 3) * (difficulty === 'medium' ? 4 : 2);
        const cand = Math.max(1, answer + (delta === 0 ? 3 : delta));
        distractors.add(cand);
      }
      const opts = Array.from(distractors).sort(() => rng() - 0.5);
      const correctIndex = opts.indexOf(answer);

      stages.push({
        kind: 'number',
        items: seq.map(String),
        options: opts.map(String),
        correctIndex,
        explanation:
          lang === 'ru' ? expRu : lang === 'en' ? expEn : toNewUzbekAlphabet(expUz),
      });
    } else if (mode === 1) {
      // Geometric shape + rotation + color sequence
      const startColorIdx = Math.floor(rng() * COLORS.length);
      const startShapeIdx = Math.floor(rng() * GEO_SHAPES.length);
      const seq: GeoShapeSpec[] = [0, 1, 2, 3].map((k) => ({
        shape: GEO_SHAPES[(startShapeIdx + k) % 4],
        color: COLORS[(startColorIdx + k) % COLORS.length],
        rotation: (k * 45) % 360,
        count: difficulty === 'hard' ? (k % 3) + 1 : 1,
      }));
      const answer: GeoShapeSpec = {
        shape: GEO_SHAPES[(startShapeIdx + 4) % 4],
        color: COLORS[(startColorIdx + 4) % COLORS.length],
        rotation: (4 * 45) % 360,
        count: difficulty === 'hard' ? (4 % 3) + 1 : 1,
      };
      const distractors: GeoShapeSpec[] = [
        { ...answer, color: COLORS[(startColorIdx + 1) % COLORS.length] },
        { ...answer, shape: GEO_SHAPES[(startShapeIdx + 1) % 4] },
        { ...answer, rotation: (answer.rotation! + 90) % 360, count: ((answer.count || 1) % 3) + 1 },
      ];
      const opts = [answer, ...distractors].sort(() => rng() - 0.5);
      const correctIndex = opts.indexOf(answer);

      stages.push({
        kind: 'shape',
        items: seq,
        options: opts,
        correctIndex,
        explanation:
          lang === 'ru'
            ? 'Фигура, цвет и угол поворота (+45°) сдвигаются на каждом шаге.'
            : lang === 'en'
              ? 'Shape, color, and rotation (+45°) advance at every step.'
              : toNewUzbekAlphabet(
                  "Shakl, rang va aylanish burchagi (+45°) har qadamda tartib bilan o'zgaradi."
                ),
      });
    } else {
      // Symbol pattern sequence (e.g. A B C A B ?)
      const s1 = SYMBOLS[Math.floor(rng() * 3)];
      const s2 = SYMBOLS[3 + Math.floor(rng() * 3)];
      const pattern = difficulty === 'hard' ? [s1, s1, s2, s1, s1] : [s1, s2, s1, s2, s1];
      const answer = s2;
      const opts = [s2, s1, SYMBOLS[(SYMBOLS.indexOf(s1) + 1) % SYMBOLS.length], SYMBOLS[(SYMBOLS.indexOf(s2) + 1) % SYMBOLS.length]];
      const uniqueOpts = Array.from(new Set(opts));
      while (uniqueOpts.length < 4) {
        uniqueOpts.push(SYMBOLS[uniqueOpts.length]);
      }
      const shuffled = uniqueOpts.slice(0, 4).sort(() => rng() - 0.5);
      stages.push({
        kind: 'symbol',
        items: pattern,
        options: shuffled,
        correctIndex: shuffled.indexOf(answer),
        explanation:
          lang === 'ru'
            ? 'Символы образуют повторяющийся ритмический цикл.'
            : lang === 'en'
              ? 'The symbols follow a repeating rhythmic cycle.'
              : toNewUzbekAlphabet('Belgilar takrorlanuvchi ritmik qonuniyat asosida joylashgan.'),
      });
    }
  }
  return stages;
}

export function SequenceGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [hiddenOpts, setHiddenOpts] = useState<number[]>([]);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(() => {
    if (settings.customTasks && settings.customTasks.length > 0) {
      return settings.customTasks as SequenceStage[];
    }
    return generateSequenceStages(
      settings.stagesCount,
      settings.difficulty,
      settings.language,
      settings.seed || Date.now()
    );
  }, [settings]);

  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || selectedOpt !== null) return;
    if (timeLeft <= 0) {
      handlePick(-1);
      return;
    }
    const t = setTimeout(() => setTimeLeft((v) => v - 1), 1000);
    return () => clearTimeout(t);
  }, [timeLeft, settings.timerEnabled, finalResult, selectedOpt]);

  const handleHint = () => {
    if (hintsLeft <= 0 || selectedOpt !== null || !current) return;
    const wrong = current.options
      .map((_, i) => i)
      .filter((i) => i !== current.correctIndex && !hiddenOpts.includes(i));
    if (wrong.length === 0) return;
    setHiddenOpts((prev) => [...prev, wrong[0]]);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handlePick = (idx: number) => {
    if (selectedOpt !== null || !current) return;
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const isCorrect = idx === current.correctIndex;
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    setSelectedOpt(idx);
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: current.explanation,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} ${
        settings.showExplanation ? `— ${current.explanation}` : ''
      }`,
    });

    onStageComplete?.(outcome);
    const next = [...outcomes, outcome];
    setOutcomes(next);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'sequence',
          category: 'logic',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: next,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setSelectedOpt(null);
        setFeedback(null);
        setHiddenOpts([]);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1500);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setSelectedOpt(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setHiddenOpts([]);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={outcomes.reduce((a, b) => a + b.pointsAwarded, 0)}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-8">
        <div className="flex flex-wrap items-center justify-center gap-3.5 sm:gap-4">
          {current.items.map((item, idx) => (
            <div
              key={idx}
              className="flex h-24 w-24 sm:h-32 sm:w-32 items-center justify-center rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-2 font-mono text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white"
            >
              {current.kind === 'shape' ? (
                <ShapeSvg spec={item as GeoShapeSpec} size={104} />
              ) : (
                String(item)
              )}
            </div>
          ))}
          <div className="flex h-24 w-24 sm:h-32 sm:w-32 items-center justify-center rounded-2xl border-2 border-dashed border-indigo-500 bg-indigo-50/70 dark:bg-indigo-950/30 font-display text-4xl font-extrabold text-indigo-600 dark:text-indigo-400">
            ?
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 max-w-3xl mx-auto">
          {current.options.map((opt, idx) => {
            const hidden = hiddenOpts.includes(idx);
            const isCorrect = selectedOpt !== null && idx === current.correctIndex;
            const isWrong = selectedOpt === idx && idx !== current.correctIndex;

            return (
              <button
                key={idx}
                type="button"
                disabled={selectedOpt !== null || hidden}
                onClick={() => handlePick(idx)}
                className={`flex min-h-[112px] items-center justify-center rounded-2xl border p-4 font-mono text-3xl font-bold transition-colors cursor-pointer disabled:cursor-default ${
                  hidden
                    ? 'opacity-20 border-slate-200 dark:border-slate-800'
                    : isCorrect
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                      : isWrong
                        ? 'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-200'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white hover:border-indigo-500'
                }`}
              >
                {current.kind === 'shape' ? (
                  <ShapeSvg spec={opt as GeoShapeSpec} size={94} />
                ) : (
                  String(opt)
                )}
              </button>
            );
          })}
        </div>
      </div>
    </GameShell>
  );
}
