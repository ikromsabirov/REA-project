import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Language } from '../../../types';

// 7-segment bitmask: [a(top), b(tr), c(br), d(bottom), e(bl), f(tl), g(mid)]
const DIGIT_SEGMENTS: Record<string, boolean[]> = {
  '0': [true, true, true, true, true, true, false],
  '1': [false, true, true, false, false, false, false],
  '2': [true, true, false, true, true, false, true],
  '3': [true, true, true, true, false, false, true],
  '4': [false, true, true, false, false, true, true],
  '5': [true, false, true, true, false, true, true],
  '6': [true, false, true, true, true, true, true],
  '7': [true, true, true, false, false, false, false],
  '8': [true, true, true, true, true, true, true],
  '9': [true, true, true, true, false, true, true],
};

function decodeDigit(segs: boolean[]): number | null {
  for (const [digit, pattern] of Object.entries(DIGIT_SEGMENTS)) {
    if (pattern.every((v, i) => v === segs[i])) return Number(digit);
  }
  return null;
}

interface MatchstickPuzzle {
  initialDigits: [string, string, string];
  initialOp: '+' | '-';
  maxMoves: number;
  hintText: Record<Language, string>;
  solutionText: string;
}

const PUZZLES: MatchstickPuzzle[] = [
  {
    initialDigits: ['6', '4', '4'],
    initialOp: '+',
    maxMoves: 1,
    hintText: {
      uz: toNewUzbekAlphabet("6 raqamidan 1 ta cho'pni olib '+' belgisiga emas, 4 ni o'zgartirib ko'ring: 8 - 4 = 4 yoki 5 + 4 = 9."),
      ru: 'Превратите 6 в 5, перенеся спичку в последнюю 4 (получится 9).',
      en: 'Move one stick from 6 (to make 5) and turn the result 4 into 9.',
    },
    solutionText: '5 + 4 = 9',
  },
  {
    initialDigits: ['9', '3', '8'],
    initialOp: '-',
    maxMoves: 1,
    hintText: {
      uz: toNewUzbekAlphabet("8 raqamidagi o'ng yuqori cho'pni olib 9 ni o'zgartirmasdan 6 hosil qiling."),
      ru: 'Уберите одну спичку из 8, чтобы получить 6 (или 9 - 3 = 6).',
      en: 'Move one stick within 8 or from 8 to 5: 9 - 3 = 6.',
    },
    solutionText: '9 - 3 = 6',
  },
  {
    initialDigits: ['3', '5', '9'],
    initialOp: '+',
    maxMoves: 1,
    hintText: {
      uz: toNewUzbekAlphabet("9 ning yuqori o'ng cho'pini 3 ga o'tkazing."),
      ru: 'Переместите одну спичку из 9 в 3 (получится 3 + 5 = 8? Нет: 5 + 4 = 9!).',
      en: 'Move one stick from 3 (to make 2? No: turn 3->3, 9->8, or 3+6=9!).',
    },
    solutionText: '3 + 6 = 9',
  },
  {
    initialDigits: ['8', '3', '3'],
    initialOp: '-',
    maxMoves: 1,
    hintText: {
      uz: toNewUzbekAlphabet("8 raqamidan bitta cho'pni olib 6 ga aylantiring."),
      ru: 'Уберите одну спичку из 8, сделав 6 (6 - 3 = 3).',
      en: 'Turn 8 into 6 by moving one stick within 8 -> 6 - 3 = 3 (or 9 - 3 = 6).',
    },
    solutionText: '6 - 3 = 3',
  },
];

// Segment geometry coordinates inside 60x100 viewBox
const SEG_COORDS: Array<{ x1: number; y1: number; x2: number; y2: number }> = [
  { x1: 14, y1: 10, x2: 46, y2: 10 }, // a top
  { x1: 48, y1: 14, x2: 48, y2: 46 }, // b tr
  { x1: 48, y1: 54, x2: 48, y2: 86 }, // c br
  { x1: 14, y1: 90, x2: 46, y2: 90 }, // d bottom
  { x1: 12, y1: 54, x2: 12, y2: 86 }, // e bl
  { x1: 12, y1: 14, x2: 12, y2: 46 }, // f tl
  { x1: 14, y1: 50, x2: 46, y2: 50 }, // g mid
];

export function MatchstickGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const stages = useMemo(
    () => PUZZLES.slice(0, Math.min(PUZZLES.length, settings.stagesCount)),
    [settings.stagesCount]
  );

  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [digits, setDigits] = useState<boolean[][]>(() =>
    stages[0].initialDigits.map((d) => [...DIGIT_SEGMENTS[d]])
  );
  const [opPlusVert, setOpPlusVert] = useState(stages[0].initialOp === '+');
  const [holdingStick, setHoldingStick] = useState(false);
  const [movesUsed, setMovesUsed] = useState(0);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [hintBanner, setHintBanner] = useState('');
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const current = stages[stageIdx];

  const resetCurrentStage = (idx: number) => {
    const p = stages[idx];
    setDigits(p.initialDigits.map((d) => [...DIGIT_SEGMENTS[d]]));
    setOpPlusVert(p.initialOp === '+');
    setHoldingStick(false);
    setMovesUsed(0);
    setHintBanner('');
  };

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      finishStage(false);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((v) => v - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const checkEquationValid = (nextDigits: boolean[][], nextOpPlus: boolean, nextHolding: boolean) => {
    if (nextHolding) return false;
    const d0 = decodeDigit(nextDigits[0]);
    const d1 = decodeDigit(nextDigits[1]);
    const d2 = decodeDigit(nextDigits[2]);
    if (d0 === null || d1 === null || d2 === null) return false;
    const lhs = nextOpPlus ? d0 + d1 : d0 - d1;
    // Also ensure not identical to initial broken state
    const initLhs =
      current.initialOp === '+'
        ? Number(current.initialDigits[0]) + Number(current.initialDigits[1])
        : Number(current.initialDigits[0]) - Number(current.initialDigits[1]);
    if (lhs === d2 && !(d0 === Number(current.initialDigits[0]) && d1 === Number(current.initialDigits[1]) && d2 === Number(current.initialDigits[2]) && initLhs === d2)) {
      return true;
    }
    return false;
  };

  const toggleSegment = (digitIdx: number, segIdx: number) => {
    if (feedback) return;
    const isLit = digits[digitIdx][segIdx];
    if (isLit && !holdingStick) {
      if (movesUsed >= current.maxMoves) return;
      const next = digits.map((row, r) => (r === digitIdx ? row.map((v, c) => (c === segIdx ? false : v)) : row));
      setDigits(next);
      setHoldingStick(true);
    } else if (!isLit && holdingStick) {
      const next = digits.map((row, r) => (r === digitIdx ? row.map((v, c) => (c === segIdx ? true : v)) : row));
      setDigits(next);
      setHoldingStick(false);
      setMovesUsed((m) => m + 1);
      if (checkEquationValid(next, opPlusVert, false)) {
        finishStage(true);
      }
    }
  };

  const toggleOperatorVert = () => {
    if (feedback) return;
    if (opPlusVert && !holdingStick) {
      if (movesUsed >= current.maxMoves) return;
      setOpPlusVert(false);
      setHoldingStick(true);
    } else if (!opPlusVert && holdingStick) {
      setOpPlusVert(true);
      setHoldingStick(false);
      setMovesUsed((m) => m + 1);
      if (checkEquationValid(digits, true, false)) {
        finishStage(true);
      }
    }
  };

  const finishStage = (isCorrect: boolean) => {
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: current.solutionText,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} — ${current.solutionText}`,
    });

    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'matchstick',
          category: 'logic',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        const nextIdx = stageIdx + 1;
        setStageIdx(nextIdx);
        resetCurrentStage(nextIdx);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1500);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          resetCurrentStage(0);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  const instructionText =
    settings.language === 'ru'
      ? holdingStick
        ? 'Нажмите на пустой слот, чтобы поставить спичку.'
        : `Переместите ${current.maxMoves} спичку, чтобы равенство стало верным.`
      : settings.language === 'en'
        ? holdingStick
          ? 'Tap an empty dashed slot to place the matchstick.'
          : `Tap a matchstick to pick it up, then place it (${current.maxMoves} move).`
        : toNewUzbekAlphabet(
            holdingStick
              ? "Bo'sh chiziqli o'ringa bosib cho'pni joylashtiring."
              : `Tenglik to'g'ri bo'lishi uchun ${current.maxMoves} ta cho'pni ko'chiring.`
          );

  const renderDigitSvg = (digitIdx: number) => (
    <svg width={104} height={168} viewBox="0 0 60 100" className="overflow-visible">
      {SEG_COORDS.map((c, segIdx) => {
        const lit = digits[digitIdx][segIdx];
        return (
          <g
            key={segIdx}
            onClick={() => toggleSegment(digitIdx, segIdx)}
            className="cursor-pointer"
          >
            <line x1={c.x1} y1={c.y1} x2={c.x2} y2={c.y2} stroke="transparent" strokeWidth={14} />
            {lit ? (
              <>
                <line
                  x1={c.x1}
                  y1={c.y1}
                  x2={c.x2}
                  y2={c.y2}
                  stroke="#d97706"
                  strokeWidth={6}
                  strokeLinecap="round"
                />
                <circle cx={c.x1} cy={c.y1} r={3.5} fill="#dc2626" />
              </>
            ) : (
              <line
                x1={c.x1}
                y1={c.y1}
                x2={c.x2}
                y2={c.y2}
                stroke="currentColor"
                strokeOpacity={0.18}
                strokeWidth={3}
                strokeDasharray="4 4"
                strokeLinecap="round"
              />
            )}
          </g>
        );
      })}
    </svg>
  );

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={outcomes.reduce((a, b) => a + b.pointsAwarded, 0)}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={() => {
        if (hintsLeft <= 0) return;
        setHintsLeft((h) => h - 1);
        setHintsUsedStage((u) => u + 1);
        setHintBanner(current.hintText[settings.language]);
      }}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-6 text-center">
        <p className="text-base font-medium text-slate-700 dark:text-slate-300">
          {instructionText}
        </p>

        {hintBanner && (
          <p className="rounded-xl border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/40 px-4 py-2 text-sm text-amber-800 dark:text-amber-200">
            {hintBanner}
          </p>
        )}

        <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-5 py-4 text-slate-700 dark:text-slate-200">
          {renderDigitSvg(0)}

          {/* Operator (+ or -) */}
          <svg
            width={68}
            height={136}
            viewBox="0 0 50 100"
            onClick={toggleOperatorVert}
            className="cursor-pointer"
          >
            <line
              x1={8}
              y1={50}
              x2={42}
              y2={50}
              stroke="#d97706"
              strokeWidth={6}
              strokeLinecap="round"
            />
            {opPlusVert ? (
              <line
                x1={25}
                y1={33}
                x2={25}
                y2={67}
                stroke="#d97706"
                strokeWidth={6}
                strokeLinecap="round"
              />
            ) : (
              <line
                x1={25}
                y1={33}
                x2={25}
                y2={67}
                stroke="currentColor"
                strokeOpacity={0.18}
                strokeWidth={3}
                strokeDasharray="4 4"
                strokeLinecap="round"
              />
            )}
          </svg>

          {renderDigitSvg(1)}

          <span className="font-mono text-5xl font-extrabold text-slate-700 dark:text-slate-300">
            =
          </span>

          {renderDigitSvg(2)}
        </div>

        <button
          type="button"
          onClick={() => resetCurrentStage(stageIdx)}
          className="rounded-xl border border-slate-300 dark:border-slate-700 px-5 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
        >
          {ui.clear}
        </button>
      </div>
    </GameShell>
  );
}
