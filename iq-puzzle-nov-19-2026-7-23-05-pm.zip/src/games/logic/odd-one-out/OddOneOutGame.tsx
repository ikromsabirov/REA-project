import { useEffect, useMemo, useState } from 'react';
import { ShapeSvg, type GeoShapeSpec } from '../../shared/ShapeSvg';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface OddStage {
  items: GeoShapeSpec[];
  oddIndex: number;
  explanation: string;
}

function generateOddStages(
  count: number,
  difficulty: Difficulty,
  lang: Language,
  seed: number
): OddStage[] {
  const rng = createSeededRng(seed);
  const itemCount = difficulty === 'easy' ? 4 : difficulty === 'medium' ? 5 : 6;
  const stages: OddStage[] = [];

  for (let i = 0; i < count; i++) {
    const rule = i % 3;
    const items: GeoShapeSpec[] = [];
    const oddIndex = Math.floor(rng() * itemCount);
    let expUz = '';
    let expRu = '';
    let expEn = '';

    if (rule === 0) {
      // Polygons vs Circle (straight edges vs curved)
      const polys: GeoShapeSpec['shape'][] = ['triangle', 'square', 'pentagon', 'hexagon'];
      for (let k = 0; k < itemCount; k++) {
        items.push({
          shape: k === oddIndex ? 'circle' : polys[k % polys.length],
          color: ['#4f46e5', '#0284c7', '#059669', '#d97706'][k % 4],
          fill: 'solid',
        });
      }
      expUz = "Boshqa barcha shakllar ko'pburchak, faqat doirada burchak va qirra yo'q.";
      expRu = 'Все остальные фигуры — многоугольники, а круг не имеет углов.';
      expEn = 'All other figures are polygons with straight sides, whereas the circle is curved.';
    } else if (rule === 1) {
      // Fill mode difference (all outline except one solid, or innerDot)
      const shapes: GeoShapeSpec['shape'][] = ['square', 'triangle', 'diamond', 'hexagon', 'star', 'pentagon'];
      for (let k = 0; k < itemCount; k++) {
        items.push({
          shape: shapes[k % shapes.length],
          color: '#0284c7',
          fill: k === oddIndex ? 'solid' : 'outline',
          innerDot: k !== oddIndex && difficulty === 'hard',
        });
      }
      expUz = "Qolgan shakllar kontur (bo'sh) ko'rinishida, faqat bittasi to'liq bo'yalgan.";
      expRu = 'Остальные фигуры контурные, и только одна полностью закрашена.';
      expEn = 'Every other shape is hollow/outlined, while only one is solidly filled.';
    } else {
      // Count parity: all have 2 shapes except one has 3
      const shapes: GeoShapeSpec['shape'][] = ['triangle', 'diamond', 'circle', 'square', 'pentagon', 'star'];
      for (let k = 0; k < itemCount; k++) {
        items.push({
          shape: shapes[k % shapes.length],
          color: '#7c3aed',
          count: k === oddIndex ? 3 : 2,
          fill: 'tinted',
        });
      }
      expUz = "Boshqa kataklarda 2 tadan shakl bor, ortiqcha katakda esa 3 ta shakl joylashgan.";
      expRu = 'Во всех остальных ячейках по 2 фигуры, а в лишней — 3.';
      expEn = 'All other tiles contain 2 shapes, whereas the odd tile contains 3.';
    }

    stages.push({
      items,
      oddIndex,
      explanation:
        lang === 'ru' ? expRu : lang === 'en' ? expEn : toNewUzbekAlphabet(expUz),
    });
  }

  return stages;
}

export function OddOneOutGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [hiddenOpts, setHiddenOpts] = useState<number[]>([]);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () =>
      generateOddStages(
        settings.stagesCount,
        settings.difficulty,
        settings.language,
        settings.seed || Date.now()
      ),
    [settings]
  );
  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || selectedOpt !== null) return;
    if (timeLeft <= 0) {
      handlePick(-1);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((v) => v - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, selectedOpt]);

  const handlePick = (idx: number) => {
    if (selectedOpt !== null || !current) return;
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const isCorrect = idx === current.oddIndex;
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    setSelectedOpt(idx);
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: current.explanation,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} — ${current.explanation}`,
    });

    onStageComplete?.(outcome);
    const next = [...outcomes, outcome];
    setOutcomes(next);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'odd-one-out',
          category: 'logic',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: next,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setSelectedOpt(null);
        setFeedback(null);
        setHiddenOpts([]);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1500);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setSelectedOpt(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setHiddenOpts([]);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={outcomes.reduce((a, b) => a + b.pointsAwarded, 0)}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={() => {
        if (hintsLeft <= 0 || selectedOpt !== null) return;
        const wrong = current.items
          .map((_, i) => i)
          .filter((i) => i !== current.oddIndex && !hiddenOpts.includes(i));
        if (!wrong.length) return;
        setHiddenOpts((p) => [...p, wrong[0]]);
        setHintsLeft((h) => h - 1);
        setHintsUsedStage((u) => u + 1);
      }}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 max-w-3xl mx-auto">
        {current.items.map((item, idx) => {
          const hidden = hiddenOpts.includes(idx);
          const isCorrect = selectedOpt !== null && idx === current.oddIndex;
          const isWrong = selectedOpt === idx && idx !== current.oddIndex;
          return (
            <button
              key={idx}
              type="button"
              disabled={selectedOpt !== null || hidden}
              onClick={() => handlePick(idx)}
              className={`flex items-center justify-center rounded-2xl border p-6 transition-colors cursor-pointer disabled:cursor-default ${
                hidden
                  ? 'opacity-20 border-slate-200 dark:border-slate-800'
                  : isCorrect
                    ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40'
                    : isWrong
                      ? 'border-red-500 bg-red-50 dark:bg-red-950/40'
                      : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 hover:border-indigo-500'
              }`}
            >
              <ShapeSvg spec={item} size={124} />
            </button>
          );
        })}
      </div>
    </GameShell>
  );
}
