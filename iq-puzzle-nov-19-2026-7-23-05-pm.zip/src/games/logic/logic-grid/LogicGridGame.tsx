import { useEffect, useMemo, useState } from 'react';
import { Check } from 'lucide-react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface LogicGridStage {
  people: string[];
  items: string[];
  clues: string[];
  solution: Record<string, string>; // person -> item
  explanation: string;
}

function getLogicGridStages(
  count: number,
  difficulty: Difficulty,
  lang: Language,
  seed: number
): LogicGridStage[] {
  const rng = createSeededRng(seed);
  const size = difficulty === 'easy' ? 3 : 4;

  const peopleBank: Record<Language, string[]> = {
    uz: [toNewUzbekAlphabet('Aziz'), toNewUzbekAlphabet('Madina'), toNewUzbekAlphabet('Shohruh'), toNewUzbekAlphabet('Chamanoy')],
    ru: ['Азиз', 'Мадина', 'Шохрух', 'Чаманой'],
    en: ['Alex', 'Maya', 'Sam', 'Elena'],
  };
  const itemBanks: Array<Record<Language, string[]>> = [
    {
      uz: [toNewUzbekAlphabet('Shaxmat'), toNewUzbekAlphabet('Kitob'), toNewUzbekAlphabet('Globus'), toNewUzbekAlphabet('Chizg‘ich')],
      ru: ['Шахматы', 'Книга', 'Глобус', 'Линейка'],
      en: ['Chess', 'Book', 'Globe', 'Compass'],
    },
    {
      uz: [toNewUzbekAlphabet('Ko‘k'), toNewUzbekAlphabet('Sariq'), toNewUzbekAlphabet('Yashil'), toNewUzbekAlphabet('Qizil')],
      ru: ['Синий', 'Жёлтый', 'Зелёный', 'Красный'],
      en: ['Blue', 'Yellow', 'Green', 'Red'],
    },
    {
      uz: [toNewUzbekAlphabet('Fizika'), toNewUzbekAlphabet('Matematika'), toNewUzbekAlphabet('Tarix'), toNewUzbekAlphabet('Biologiya')],
      ru: ['Физика', 'Математика', 'История', 'Биология'],
      en: ['Physics', 'Math', 'History', 'Biology'],
    },
  ];

  const stages: LogicGridStage[] = [];
  for (let i = 0; i < count; i++) {
    const people = peopleBank[lang].slice(0, size);
    const items = itemBanks[i % itemBanks.length][lang].slice(0, size);
    const shuffledItems = [...items].sort(() => rng() - 0.5);
    const solution: Record<string, string> = {};
    people.forEach((p, idx) => {
      solution[p] = shuffledItems[idx];
    });

    const clues: string[] = [];
    if (lang === 'ru') {
      clues.push(`1. У ${people[0]} точно предмет «${solution[people[0]]}».`);
      clues.push(`2. У ${people[1]} НЕ «${solution[people[0]]}» и НЕ «${solution[people[2]]}».`);
      if (size === 4) {
        clues.push(`3. У ${people[3]} предмет «${solution[people[3]]}».`);
      } else {
        clues.push(`3. У ${people[2]} не «${solution[people[1]]}».`);
      }
    } else if (lang === 'en') {
      clues.push(`1. ${people[0]} has ${solution[people[0]]}.`);
      clues.push(`2. ${people[1]} has neither ${solution[people[0]]} nor ${solution[people[2]]}.`);
      if (size === 4) {
        clues.push(`3. ${people[3]} is paired with ${solution[people[3]]}.`);
      } else {
        clues.push(`3. ${people[2]} does not have ${solution[people[1]]}.`);
      }
    } else {
      clues.push(toNewUzbekAlphabet(`1. ${people[0]}da aniq "${solution[people[0]]}" bor.`));
      clues.push(
        toNewUzbekAlphabet(
          `2. ${people[1]}da "${solution[people[0]]}" ham, "${solution[people[2]]}" ham yo'q.`
        )
      );
      if (size === 4) {
        clues.push(toNewUzbekAlphabet(`3. ${people[3]}ga "${solution[people[3]]}" tegishli.`));
      } else {
        clues.push(toNewUzbekAlphabet(`3. ${people[2]}da "${solution[people[1]]}" emas.`));
      }
    }

    const explanation = people.map((p) => `${p} → ${solution[p]}`).join(' · ');
    stages.push({ people, items, clues, solution, explanation });
  }
  return stages;
}

export function LogicGridGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [assignments, setAssignments] = useState<Record<string, string>>({});
  const [draggingItem, setDraggingItem] = useState<string | null>(null);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () =>
      getLogicGridStages(
        settings.stagesCount,
        settings.difficulty,
        settings.language,
        settings.seed || Date.now()
      ),
    [settings]
  );
  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || submitted) return;
    if (timeLeft <= 0) {
      handleVerify();
      return;
    }
    const timer = setTimeout(() => setTimeLeft((v) => v - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, submitted]);

  const assignItem = (person: string, item: string) => {
    if (submitted) return;
    setAssignments((prev) => {
      const next = { ...prev };
      // Remove item from any other person so 1-to-1 bijection stays clean
      Object.keys(next).forEach((k) => {
        if (next[k] === item) delete next[k];
      });
      next[person] = item;
      return next;
    });
  };

  const handleHint = () => {
    if (hintsLeft <= 0 || submitted || !current) return;
    const unSolved = current.people.find((p) => assignments[p] !== current.solution[p]);
    if (!unSolved) return;
    assignItem(unSolved, current.solution[unSolved]);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleVerify = () => {
    if (submitted || !current) return;
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const isCorrect = current.people.every((p) => assignments[p] === current.solution[p]);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    setSubmitted(true);
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: current.explanation,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} — ${current.explanation}`,
    });

    onStageComplete?.(outcome);
    const next = [...outcomes, outcome];
    setOutcomes(next);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'logic-grid',
          category: 'logic',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: next,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setAssignments({});
        setSubmitted(false);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1800);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setAssignments({});
          setSubmitted(false);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const usedItems = new Set(Object.values(assignments));

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={outcomes.reduce((a, b) => a + b.pointsAwarded, 0)}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-6">
        {/* Clues */}
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 space-y-2 text-base text-slate-800 dark:text-slate-200">
          {current.clues.map((c, idx) => (
            <p key={idx}>{c}</p>
          ))}
        </div>

        {/* Draggable Item Pool */}
        <div className="flex flex-wrap gap-2.5 justify-center">
          {current.items.map((item) => {
            const used = usedItems.has(item);
            return (
              <div
                key={item}
                draggable={!submitted}
                onDragStart={() => setDraggingItem(item)}
                onDragEnd={() => setDraggingItem(null)}
                className={`rounded-xl border px-4 py-2.5 text-base font-semibold select-none cursor-grab transition-opacity ${
                  used
                    ? 'opacity-45 border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900'
                    : 'border-indigo-300 dark:border-indigo-700 bg-indigo-50/70 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-100'
                }`}
              >
                {item}
              </div>
            );
          })}
        </div>

        {/* Assignment Matrix Table (click OR drag-and-drop) */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-center">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-sm font-semibold text-slate-600 dark:text-slate-300">
                <th className="p-3 text-left">—</th>
                {current.items.map((it) => (
                  <th key={it} className="p-3">
                    {it}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {current.people.map((person) => (
                <tr
                  key={person}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={() => {
                    if (draggingItem) assignItem(person, draggingItem);
                  }}
                >
                  <td className="p-3 text-left font-bold text-slate-900 dark:text-white">
                    {person}
                  </td>
                  {current.items.map((item) => {
                    const active = assignments[person] === item;
                    return (
                      <td key={item} className="p-2">
                        <button
                          type="button"
                          disabled={submitted}
                          onClick={() => assignItem(person, item)}
                          className={`mx-auto flex h-11 w-11 items-center justify-center rounded-xl border transition-colors cursor-pointer ${
                            active
                              ? 'border-indigo-600 bg-indigo-600 text-white'
                              : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:border-indigo-400'
                          }`}
                        >
                          {active && <Check className="h-5 w-5" />}
                        </button>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-center">
          <button
            type="button"
            disabled={submitted || Object.keys(assignments).length < current.people.length}
            onClick={handleVerify}
            className="rounded-xl bg-indigo-600 px-8 py-3 text-base font-semibold text-white hover:bg-indigo-700 disabled:opacity-40 cursor-pointer"
          >
            {ui.check}
          </button>
        </div>
      </div>
    </GameShell>
  );
}
