import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface SceneItem {
  id: string;
  x: number;
  y: number;
  r: number;
  kind: 'sun' | 'cloud' | 'tree' | 'window' | 'bird' | 'flower' | 'flag' | 'chimney' | 'star' | 'rock';
  baseColor: string;
  altColor: string;
  isChanged: boolean;
  changeMode: 'color' | 'missing' | 'shift';
}

interface DiffStage {
  items: SceneItem[];
  diffIds: string[];
}

function generateDiffStages(count: number, difficulty: Difficulty, seed: number): DiffStage[] {
  const rng = createSeededRng(seed);
  const diffTargetCount = difficulty === 'easy' ? 4 : difficulty === 'medium' ? 5 : 6;
  const stages: DiffStage[] = [];

  for (let i = 0; i < count; i++) {
    const baseItems: Omit<SceneItem, 'isChanged' | 'changeMode'>[] = [
      { id: 'sun', x: 52, y: 42, r: 22, kind: 'sun', baseColor: '#f59e0b', altColor: '#ef4444' },
      { id: 'cloud1', x: 150, y: 44, r: 24, kind: 'cloud', baseColor: '#e0f2fe', altColor: '#fde68a' },
      { id: 'bird1', x: 245, y: 38, r: 16, kind: 'bird', baseColor: '#0f172a', altColor: '#4f46e5' },
      { id: 'tree1', x: 46, y: 150, r: 26, kind: 'tree', baseColor: '#10b981', altColor: '#f97316' },
      { id: 'window1', x: 145, y: 145, r: 18, kind: 'window', baseColor: '#38bdf8', altColor: '#facc15' },
      { id: 'chimney', x: 180, y: 92, r: 16, kind: 'chimney', baseColor: '#b91c1c', altColor: '#1e293b' },
      { id: 'flag', x: 255, y: 105, r: 18, kind: 'flag', baseColor: '#e11d48', altColor: '#0284c7' },
      { id: 'flower', x: 96, y: 188, r: 15, kind: 'flower', baseColor: '#ec4899', altColor: '#8b5cf6' },
      { id: 'rock', x: 248, y: 186, r: 18, kind: 'rock', baseColor: '#64748b', altColor: '#0d9488' },
    ];

    const shuffledIds = baseItems.map((b) => b.id).sort(() => rng() - 0.5);
    const chosenDiffs = new Set(shuffledIds.slice(0, diffTargetCount));
    const modes: SceneItem['changeMode'][] = ['color', 'missing', 'shift'];

    const items: SceneItem[] = baseItems.map((item, idx) => ({
      ...item,
      isChanged: chosenDiffs.has(item.id),
      changeMode: modes[(idx + i) % modes.length],
    }));

    stages.push({ items, diffIds: Array.from(chosenDiffs) });
  }
  return stages;
}

function SceneItemSvg({
  item,
  variant,
  found,
  hinted,
  onClick,
}: {
  item: SceneItem;
  variant: 'left' | 'right';
  found: boolean;
  hinted: boolean;
  onClick: () => void;
}) {
  const applyDiff = variant === 'right' && item.isChanged;
  if (applyDiff && item.changeMode === 'missing') {
    return (
      <g onClick={onClick} className="cursor-pointer">
        <circle cx={item.x} cy={item.y} r={item.r + 4} fill="transparent" />
        {(found || hinted) && (
          <circle
            cx={item.x}
            cy={item.y}
            r={item.r + 4}
            fill="none"
            stroke={found ? '#10b981' : '#f59e0b'}
            strokeWidth={3}
            strokeDasharray={hinted && !found ? '4 2' : undefined}
          />
        )}
      </g>
    );
  }

  const color = applyDiff && item.changeMode === 'color' ? item.altColor : item.baseColor;
  const dx = applyDiff && item.changeMode === 'shift' ? 14 : 0;

  return (
    <g transform={`translate(${dx}, 0)`} onClick={onClick} className="cursor-pointer">
      {item.kind === 'sun' && <circle cx={item.x} cy={item.y} r={18} fill={color} />}
      {item.kind === 'cloud' && (
        <g fill={color}>
          <circle cx={item.x - 10} cy={item.y} r={12} />
          <circle cx={item.x + 6} cy={item.y - 4} r={15} />
          <circle cx={item.x + 18} cy={item.y + 2} r={10} />
        </g>
      )}
      {item.kind === 'bird' && (
        <path
          d={`M${item.x - 12},${item.y} Q${item.x - 5},${item.y - 10} ${item.x},${item.y} Q${item.x + 5},${item.y - 10} ${item.x + 12},${item.y}`}
          fill="none"
          stroke={color}
          strokeWidth={3}
          strokeLinecap="round"
        />
      )}
      {item.kind === 'tree' && (
        <g>
          <rect x={item.x - 5} y={item.y + 8} width={10} height={24} fill="#78350f" />
          <circle cx={item.x} cy={item.y - 4} r={20} fill={color} />
        </g>
      )}
      {item.kind === 'window' && (
        <g>
          <rect x={item.x - 12} y={item.y - 12} width={24} height={24} rx={3} fill={color} stroke="#1e293b" strokeWidth={2} />
          <line x1={item.x} y1={item.y - 12} x2={item.x} y2={item.y + 12} stroke="#1e293b" strokeWidth={2} />
          <line x1={item.x - 12} y1={item.y} x2={item.x + 12} y2={item.y} stroke="#1e293b" strokeWidth={2} />
        </g>
      )}
      {item.kind === 'chimney' && (
        <rect x={item.x - 8} y={item.y - 14} width={16} height={26} fill={color} stroke="#0f172a" strokeWidth={1.5} />
      )}
      {item.kind === 'flag' && (
        <g>
          <line x1={item.x - 8} y1={item.y - 16} x2={item.x - 8} y2={item.y + 20} stroke="#334155" strokeWidth={3} />
          <polygon points={`${item.x - 6},${item.y - 16} ${item.x + 18},${item.y - 8} ${item.x - 6},${item.y}`} fill={color} />
        </g>
      )}
      {item.kind === 'flower' && (
        <g>
          <line x1={item.x} y1={item.y} x2={item.x} y2={item.y + 18} stroke="#15803d" strokeWidth={3} />
          <circle cx={item.x} cy={item.y} r={10} fill={color} />
          <circle cx={item.x} cy={item.y} r={4} fill="#fef08a" />
        </g>
      )}
      {item.kind === 'rock' && (
        <ellipse cx={item.x} cy={item.y + 4} rx={18} ry={12} fill={color} />
      )}

      {(found || hinted) && (
        <circle
          cx={item.x}
          cy={item.y}
          r={item.r + 4}
          fill="none"
          stroke={found ? '#10b981' : '#f59e0b'}
          strokeWidth={3}
          strokeDasharray={hinted && !found ? '4 2' : undefined}
        />
      )}
    </g>
  );
}

export function FindDifferenceGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [foundIds, setFoundIds] = useState<string[]>([]);
  const [hintId, setHintId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () => generateDiffStages(settings.stagesCount, settings.difficulty, settings.seed || Date.now()),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      finishStage(false);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const finishStage = (isCorrect: boolean) => {
    if (feedback || !current) return;
    const timeTakenMs = Math.max(400, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };
    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'find-difference',
          category: 'attention',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFoundIds([]);
        setHintId(null);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1200);
  };

  const handleItemTap = (item: SceneItem) => {
    if (feedback || !current) return;
    if (!item.isChanged) {
      playErrorTone(soundEnabled);
      return;
    }
    if (foundIds.includes(item.id)) return;
    playSuccessChime(soundEnabled);
    const nextFound = [...foundIds, item.id];
    setFoundIds(nextFound);
    if (hintId === item.id) setHintId(null);
    if (nextFound.length === current.diffIds.length) {
      finishStage(true);
    }
  };

  const handleUseHint = () => {
    if (hintsLeft <= 0 || !current || feedback) return;
    const unfound = current.diffIds.find((id) => !foundIds.includes(id));
    if (!unfound) return;
    setHintId(unfound);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setFoundIds([]);
          setHintId(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  const label =
    settings.language === 'ru'
      ? `Найдено отличий: ${foundIds.length} / ${current.diffIds.length}`
      : settings.language === 'en'
        ? `Differences found: ${foundIds.length} / ${current.diffIds.length}`
        : toNewUzbekAlphabet(`Topilgan farqlar: ${foundIds.length} / ${current.diffIds.length}`);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-4">
        <p className="text-center font-mono text-base font-bold text-emerald-700 dark:text-emerald-400 tabular-nums">
          {label}
        </p>

        <div className="grid gap-4 md:grid-cols-2">
          {(['left', 'right'] as const).map((side) => (
            <svg
              key={side}
              viewBox="0 0 300 215"
              className="w-full rounded-2xl border border-slate-200 dark:border-slate-700 bg-sky-100 dark:bg-slate-900 select-none"
            >
              {/* Static landscape background */}
              <rect x={0} y={162} width={300} height={53} fill="#86efac" />
              <rect x={110} y={108} width={88} height={64} fill="#fef9c3" stroke="#78350f" strokeWidth={2} />
              <polygon points="100,108 154,68 208,108" fill="#ea580c" stroke="#7c2d12" strokeWidth={2} />
              <rect x={144} y={142} width={20} height={30} fill="#92400e" />

              {current.items.map((item) => (
                <SceneItemSvg
                  key={item.id}
                  item={item}
                  variant={side}
                  found={foundIds.includes(item.id)}
                  hinted={hintId === item.id}
                  onClick={() => handleItemTap(item)}
                />
              ))}
            </svg>
          ))}
        </div>
      </div>
    </GameShell>
  );
}
