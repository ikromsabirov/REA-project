import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty } from '../../../types';

interface NumberGridStage {
  size: 3 | 4 | 5;
  numbers: number[];
}

function generateNumberGrids(count: number, difficulty: Difficulty, seed: number): NumberGridStage[] {
  const rng = createSeededRng(seed);
  const stages: NumberGridStage[] = [];
  for (let i = 0; i < count; i++) {
    const size: 3 | 4 | 5 =
      difficulty === 'easy' ? 3 : difficulty === 'medium' ? (i === 0 ? 3 : 4) : i === 0 ? 4 : 5;
    const total = size * size;
    const nums = Array.from({ length: total }, (_, idx) => idx + 1).sort(() => rng() - 0.5);
    stages.push({ size, numbers: nums });
  }
  return stages;
}

export function NumberSearchGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [nextTarget, setNextTarget] = useState(1);
  const [hintTarget, setHintTarget] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () => generateNumberGrids(settings.stagesCount, settings.difficulty, settings.seed || Date.now()),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      finishStage(false);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const finishStage = (isCorrect: boolean) => {
    if (feedback || !current) return;
    const timeTakenMs = Math.max(400, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };

    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'number-search',
          category: 'attention',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setNextTarget(1);
        setHintTarget(null);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1000);
  };

  const handleTap = (num: number) => {
    if (feedback || !current) return;
    if (num !== nextTarget) {
      playErrorTone(soundEnabled);
      return;
    }
    playSuccessChime(soundEnabled);
    setHintTarget(null);
    if (num === current.size * current.size) {
      finishStage(true);
    } else {
      setNextTarget((n) => n + 1);
    }
  };

  const handleUseHint = () => {
    if (hintsLeft <= 0 || feedback) return;
    setHintTarget(nextTarget);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setNextTarget(1);
          setHintTarget(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  const label =
    settings.language === 'ru'
      ? `Нажмите следующее число: ${nextTarget}`
      : settings.language === 'en'
        ? `Tap next number: ${nextTarget}`
        : toNewUzbekAlphabet(`Keyingi raqamni bosing: ${nextTarget}`);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-5 text-center">
        <p className="font-mono text-lg font-extrabold text-emerald-700 dark:text-emerald-400 tabular-nums">
          {label}
        </p>

        <div
          className="mx-auto grid gap-2 sm:gap-2.5"
          style={{
            maxWidth: current.size === 5 ? '380px' : '320px',
            gridTemplateColumns: `repeat(${current.size}, minmax(0, 1fr))`,
          }}
        >
          {current.numbers.map((num) => {
            const done = num < nextTarget;
            const hinted = hintTarget === num;
            return (
              <button
                key={num}
                type="button"
                disabled={done}
                onClick={() => handleTap(num)}
                className={`aspect-square rounded-xl border font-mono text-xl font-bold transition-all cursor-pointer tabular-nums ${
                  done
                    ? 'border-emerald-300 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600/50 dark:text-emerald-500/40'
                    : hinted
                      ? 'border-amber-500 bg-amber-100 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 ring-2 ring-amber-400'
                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white hover:border-emerald-500'
                }`}
              >
                {num}
              </button>
            );
          })}
        </div>
      </div>
    </GameShell>
  );
}
