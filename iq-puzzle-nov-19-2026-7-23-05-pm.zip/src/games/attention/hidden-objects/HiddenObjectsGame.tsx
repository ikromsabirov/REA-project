import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface HiddenItem {
  id: string;
  symbol: string;
  label: Record<Language, string>;
  x: number;
  y: number;
  color: string;
}

const OBJECT_POOL: Array<Omit<HiddenItem, 'x' | 'y'>> = [
  { id: 'key', symbol: '🔑', color: '#f59e0b', label: { uz: toNewUzbekAlphabet('Kalit'), ru: 'Ключ', en: 'Key' } },
  { id: 'compass', symbol: '🧭', color: '#0284c7', label: { uz: toNewUzbekAlphabet('Kompas'), ru: 'Компас', en: 'Compass' } },
  { id: 'flask', symbol: '⚗️', color: '#10b981', label: { uz: toNewUzbekAlphabet('Kolba'), ru: 'Колба', en: 'Flask' } },
  { id: 'lens', symbol: '🔍', color: '#6366f1', label: { uz: toNewUzbekAlphabet('Lupa'), ru: 'Лупа', en: 'Magnifier' } },
  { id: 'hourglass', symbol: '⏳', color: '#d97706', label: { uz: toNewUzbekAlphabet('Qumsoat'), ru: 'Песочные часы', en: 'Hourglass' } },
  { id: 'magnet', symbol: '🧲', color: '#e11d48', label: { uz: toNewUzbekAlphabet('Magnit'), ru: 'Магнит', en: 'Magnet' } },
  { id: 'bell', symbol: '🔔', color: '#eab308', label: { uz: toNewUzbekAlphabet("Qo'ng'iroq"), ru: 'Колокольчик', en: 'Bell' } },
  { id: 'crystal', symbol: '💎', color: '#06b6d4', label: { uz: toNewUzbekAlphabet('Kristall'), ru: 'Кристалл', en: 'Crystal' } },
  { id: 'feather', symbol: '🪶', color: '#8b5cf6', label: { uz: toNewUzbekAlphabet('Pat'), ru: 'Перо', en: 'Feather' } },
  { id: 'gear', symbol: '⚙️', color: '#64748b', label: { uz: toNewUzbekAlphabet('Tishli g‘ildirak'), ru: 'Шестерня', en: 'Gear' } },
];

const DECOYS = ['📚', '🪴', '🕯️', '📐', '🎨', '🧩', '📎', '🪨'];

interface HiddenStage {
  allObjects: Array<HiddenItem & { isTarget: boolean }>;
  targets: HiddenItem[];
}

function generateHiddenStages(count: number, difficulty: Difficulty, seed: number): HiddenStage[] {
  const rng = createSeededRng(seed);
  const targetCount = difficulty === 'easy' ? 4 : difficulty === 'medium' ? 5 : 6;
  const stages: HiddenStage[] = [];

  for (let i = 0; i < count; i++) {
    const shuffled = [...OBJECT_POOL].sort(() => rng() - 0.5);
    const chosen = shuffled.slice(0, targetCount);

    const coords: Array<{ x: number; y: number }> = [];
    for (let k = 0; k < targetCount + 7; k++) {
      let x = 35 + Math.floor(rng() * 290);
      let y = 35 + Math.floor(rng() * 175);
      // Simple spacing pass
      for (let g = 0; g < 15; g++) {
        if (coords.every((c) => Math.hypot(c.x - x, c.y - y) > 34)) break;
        x = 35 + Math.floor(rng() * 290);
        y = 35 + Math.floor(rng() * 175);
      }
      coords.push({ x, y });
    }

    const targets: HiddenItem[] = chosen.map((item, idx) => ({
      ...item,
      x: coords[idx].x,
      y: coords[idx].y,
    }));

    const decoyItems = Array.from({ length: 7 }, (_, idx) => ({
      id: `decoy-${idx}`,
      symbol: DECOYS[(idx + i) % DECOYS.length],
      label: { uz: '', ru: '', en: '' },
      color: '#94a3b8',
      x: coords[targetCount + idx].x,
      y: coords[targetCount + idx].y,
      isTarget: false,
    }));

    const allObjects = [
      ...targets.map((t) => ({ ...t, isTarget: true })),
      ...decoyItems,
    ].sort(() => rng() - 0.5);

    stages.push({ allObjects, targets });
  }
  return stages;
}

export function HiddenObjectsGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [foundIds, setFoundIds] = useState<string[]>([]);
  const [hintId, setHintId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () => generateHiddenStages(settings.stagesCount, settings.difficulty, settings.seed || Date.now()),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      finishStage(false);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const finishStage = (isCorrect: boolean) => {
    if (feedback || !current) return;
    const timeTakenMs = Math.max(400, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };
    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'hidden-objects',
          category: 'attention',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFoundIds([]);
        setHintId(null);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1200);
  };

  const handleTap = (obj: HiddenItem & { isTarget: boolean }) => {
    if (feedback || !current) return;
    if (!obj.isTarget) {
      playErrorTone(soundEnabled);
      return;
    }
    if (foundIds.includes(obj.id)) return;
    playSuccessChime(soundEnabled);
    const next = [...foundIds, obj.id];
    setFoundIds(next);
    if (hintId === obj.id) setHintId(null);
    if (next.length === current.targets.length) {
      finishStage(true);
    }
  };

  const handleUseHint = () => {
    if (hintsLeft <= 0 || !current || feedback) return;
    const missing = current.targets.find((t) => !foundIds.includes(t.id));
    if (!missing) return;
    setHintId(missing.id);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setFoundIds([]);
          setHintId(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-4">
        {/* Target checklist */}
        <div className="flex flex-wrap justify-center gap-2">
          {current.targets.map((t) => {
            const found = foundIds.includes(t.id);
            return (
              <div
                key={t.id}
                className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-sm font-semibold ${
                  found
                    ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 line-through'
                    : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100'
                }`}
              >
                <span>{t.symbol}</span>
                <span>{toNewUzbekAlphabet(t.label[settings.language])}</span>
              </div>
            );
          })}
        </div>

        {/* Illustrated Room Scene */}
        <svg
          viewBox="0 0 360 240"
          className="mx-auto w-full max-w-3xl rounded-2xl border border-slate-200 dark:border-slate-700 bg-gradient-to-b from-amber-50 via-stone-100 to-amber-100 dark:from-slate-900 dark:via-slate-950 dark:to-slate-900 select-none"
        >
          {/* Decorative shelves & desk */}
          <rect x={20} y={65} width={140} height={8} rx={3} fill="#92400e" fillOpacity={0.35} />
          <rect x={195} y={95} width={145} height={8} rx={3} fill="#92400e" fillOpacity={0.35} />
          <rect x={15} y={185} width={330} height={14} rx={4} fill="#78350f" fillOpacity={0.35} />

          {current.allObjects.map((obj) => {
            const isFound = foundIds.includes(obj.id);
            const isHinted = hintId === obj.id;
            return (
              <g
                key={obj.id}
                onClick={() => handleTap(obj)}
                className="cursor-pointer"
                opacity={isFound ? 0.35 : 1}
              >
                {isHinted && (
                  <circle
                    cx={obj.x}
                    cy={obj.y}
                    r={20}
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth={3}
                    strokeDasharray="4 2"
                  />
                )}
                {isFound && (
                  <circle cx={obj.x} cy={obj.y} r={18} fill="#10b981" fillOpacity={0.25} stroke="#10b981" strokeWidth={2} />
                )}
                <text
                  x={obj.x}
                  y={obj.y}
                  textAnchor="middle"
                  dominantBaseline="central"
                  fontSize="28"
                >
                  {obj.symbol}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </GameShell>
  );
}
