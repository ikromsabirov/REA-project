import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface ColorEntry {
  id: 'red' | 'blue' | 'green' | 'amber' | 'purple';
  hex: string;
  names: Record<Language, string>;
}

const COLORS: ColorEntry[] = [
  {
    id: 'red',
    hex: '#dc2626',
    names: { uz: toNewUzbekAlphabet('QIZIL'), ru: 'КРАСНЫЙ', en: 'RED' },
  },
  {
    id: 'blue',
    hex: '#2563eb',
    names: { uz: toNewUzbekAlphabet("KO'K"), ru: 'СИНИЙ', en: 'BLUE' },
  },
  {
    id: 'green',
    hex: '#059669',
    names: { uz: toNewUzbekAlphabet('YASHIL'), ru: 'ЗЕЛЁНЫЙ', en: 'GREEN' },
  },
  {
    id: 'amber',
    hex: '#d97706',
    names: { uz: toNewUzbekAlphabet('SARIQ'), ru: 'ЖЁЛТЫЙ', en: 'YELLOW' },
  },
  {
    id: 'purple',
    hex: '#7c3aed',
    names: { uz: toNewUzbekAlphabet('BINAFSHA'), ru: 'ФИОЛЕТОВЫЙ', en: 'PURPLE' },
  },
];

interface StroopStage {
  wordColor: ColorEntry;
  inkColor: ColorEntry;
  options: ColorEntry[];
}

function generateStroopStages(count: number, difficulty: Difficulty, seed: number): StroopStage[] {
  const rng = createSeededRng(seed);
  const pool = difficulty === 'easy' ? COLORS.slice(0, 4) : COLORS;
  const stages: StroopStage[] = [];

  for (let i = 0; i < count; i++) {
    const wordColor = pool[Math.floor(rng() * pool.length)];
    let inkColor = pool[Math.floor(rng() * pool.length)];
    if (inkColor.id === wordColor.id) {
      inkColor = pool[(pool.indexOf(wordColor) + 1) % pool.length];
    }
    const options = [...pool].sort(() => rng() - 0.5);
    stages.push({ wordColor, inkColor, options });
  }
  return stages;
}

export function StroopGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [eliminatedIds, setEliminatedIds] = useState<string[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () => generateStroopStages(settings.stagesCount, settings.difficulty, settings.seed || Date.now()),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || selectedId !== null) return;
    if (timeLeft <= 0) {
      handleSelect('timeout');
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, selectedId]);

  const handleUseHint = () => {
    if (hintsLeft <= 0 || selectedId !== null || !current) return;
    const wrong = current.options.filter(
      (c) => c.id !== current.inkColor.id && !eliminatedIds.includes(c.id)
    );
    if (wrong.length === 0) return;
    setEliminatedIds((prev) => [...prev, wrong[0].id]);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleSelect = (colorId: string) => {
    if (selectedId !== null || !current) return;
    const timeTakenMs = Math.max(150, Date.now() - stageStartedAt);
    const isCorrect = colorId === current.inkColor.id;
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    setSelectedId(colorId);
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} · ${timeTakenMs} ms`,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'stroop',
          category: 'attention',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setSelectedId(null);
        setFeedback(null);
        setEliminatedIds([]);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 900);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setSelectedId(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setEliminatedIds([]);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  const instruction =
    settings.language === 'ru'
      ? 'Выберите ЦВЕТ ЧЕРНИЛ, а не значение слова:'
      : settings.language === 'en'
        ? 'Tap the INK COLOR of the word, NOT the written text:'
        : toNewUzbekAlphabet("So'z ma'nosini emas, YOZUV RANGINI tanlang:");

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-8 text-center">
        <p className="text-base font-medium text-slate-600 dark:text-slate-300">{instruction}</p>

        <div className="py-6">
          <span
            className="font-display text-5xl sm:text-6xl font-black tracking-tight select-none"
            style={{ color: current.inkColor.hex }}
          >
            {current.wordColor.names[settings.language]}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 max-w-xl mx-auto">
          {current.options.map((opt) => {
            const isElim = eliminatedIds.includes(opt.id);
            const isSelected = selectedId === opt.id;
            const isCorrect = selectedId !== null && opt.id === current.inkColor.id;
            const isWrong = isSelected && opt.id !== current.inkColor.id;

            return (
              <button
                key={opt.id}
                type="button"
                disabled={selectedId !== null || isElim}
                onClick={() => handleSelect(opt.id)}
                className={`flex items-center justify-center gap-2.5 rounded-xl border px-4 py-4 text-base font-bold transition-all cursor-pointer disabled:cursor-default ${
                  isElim
                    ? 'opacity-20 border-slate-200 dark:border-slate-800'
                    : isCorrect
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40'
                      : isWrong
                        ? 'border-red-500 bg-red-50 dark:bg-red-950/40'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:border-slate-400'
                }`}
              >
                <span className="h-4 w-4 rounded-full" style={{ backgroundColor: opt.hex }} />
                <span className="text-slate-900 dark:text-white">{opt.names[settings.language]}</span>
              </button>
            );
          })}
        </div>
      </div>
    </GameShell>
  );
}
