import { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { RotateCw, Pause, Play } from 'lucide-react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

type Voxel = [number, number, number];

interface PolycubeSpec {
  id: string;
  blocks: Voxel[];
  accentColor: string;
}

interface RotationStage {
  target: PolycubeSpec;
  options: Array<{ blocks: Voxel[]; yawDeg: number; pitchDeg: number; isMirror: boolean }>;
  correctIndex: number;
  explanation: string;
}

const POLYCUBE_TEMPLATES: PolycubeSpec[] = [
  {
    id: 'l-hook',
    blocks: [
      [0, 0, 0],
      [1, 0, 0],
      [0, 1, 0],
      [0, 2, 0],
      [0, 2, 1],
    ],
    accentColor: '#4f46e5',
  },
  {
    id: 'z-step',
    blocks: [
      [0, 0, 0],
      [1, 0, 0],
      [1, 1, 0],
      [1, 1, 1],
      [2, 1, 1],
    ],
    accentColor: '#0284c7',
  },
  {
    id: 't-corner',
    blocks: [
      [0, 0, 0],
      [1, 0, 0],
      [2, 0, 0],
      [1, 1, 0],
      [1, 1, 1],
    ],
    accentColor: '#d97706',
  },
  {
    id: 'spiral-5',
    blocks: [
      [0, 0, 0],
      [0, 1, 0],
      [1, 1, 0],
      [1, 1, 1],
      [1, 2, 1],
    ],
    accentColor: '#059669',
  },
  {
    id: 'bridge-6',
    blocks: [
      [0, 0, 0],
      [0, 1, 0],
      [1, 1, 0],
      [2, 1, 0],
      [2, 0, 0],
      [2, 1, 1],
    ],
    accentColor: '#7c3aed',
  },
];

function mirrorBlocksX(blocks: Voxel[]): Voxel[] {
  return blocks.map(([x, y, z]) => [-x, y, z]);
}

function flipBlocksY(blocks: Voxel[]): Voxel[] {
  return blocks.map(([x, y, z]) => [x, -y, z]);
}

function generateRotationStages(
  count: number,
  difficulty: Difficulty,
  lang: Language,
  seed: number
): RotationStage[] {
  const rng = createSeededRng(seed);
  const stages: RotationStage[] = [];
  const shuffled = [...POLYCUBE_TEMPLATES].sort(() => rng() - 0.5);

  for (let i = 0; i < count; i++) {
    const base = shuffled[i % shuffled.length];
    const targetBlocks =
      difficulty === 'hard'
        ? [...base.blocks, [base.blocks[0][0], base.blocks[0][1], -1] as Voxel]
        : base.blocks;

    const correctYaw = [110, 155, 225, 290][Math.floor(rng() * 4)];
    const correctPitch = difficulty === 'easy' ? 22 : [28, -24, 34][Math.floor(rng() * 3)];

    const distractor1 = {
      blocks: mirrorBlocksX(targetBlocks),
      yawDeg: correctYaw,
      pitchDeg: correctPitch,
      isMirror: true,
    };
    const distractor2 = {
      blocks: flipBlocksY(mirrorBlocksX(targetBlocks)),
      yawDeg: (correctYaw + 60) % 360,
      pitchDeg: 25,
      isMirror: true,
    };
    const distractor3 = {
      blocks: targetBlocks.slice(0, -1).concat([[2, 2, 0]]),
      yawDeg: (correctYaw + 130) % 360,
      pitchDeg: 28,
      isMirror: true,
    };

    const opts = [distractor1, distractor2, distractor3];
    const correctIndex = Math.floor(rng() * 4);
    opts.splice(correctIndex, 0, {
      blocks: targetBlocks,
      yawDeg: correctYaw,
      pitchDeg: correctPitch,
      isMirror: false,
    });

    const explanation =
      lang === 'ru'
        ? `Правильная фигура получена поворотом исходной модели на ${correctYaw}° без зеркального отражения.`
        : lang === 'en'
          ? `The valid option is the original polycube rotated by ${correctYaw}° without chiral mirroring.`
          : toNewUzbekAlphabet(
              `To'g'ri variant — asl 3D shaklning aks ettirilmasdan ${correctYaw}° ga aylantirilgan ko'rinishi.`
            );

    stages.push({
      target: { ...base, blocks: targetBlocks },
      options: opts,
      correctIndex,
      explanation,
    });
  }
  return stages;
}

function projectIso(
  voxel: Voxel,
  yawDeg: number,
  pitchDeg: number
): { sx: number; sy: number; depth: number } {
  const [vx, vy, vz] = voxel;
  const ry = (yawDeg * Math.PI) / 180;
  const rx = (pitchDeg * Math.PI) / 180;

  // Yaw around Y
  const x1 = vx * Math.cos(ry) - vz * Math.sin(ry);
  const z1 = vx * Math.sin(ry) + vz * Math.cos(ry);
  const y1 = vy;

  // Pitch around X
  const y2 = y1 * Math.cos(rx) - z1 * Math.sin(rx);
  const z2 = y1 * Math.sin(rx) + z1 * Math.cos(rx);

  return { sx: x1, sy: -y2, depth: z2 };
}

function PolycubeProjectionSvg({
  blocks,
  yawDeg,
  pitchDeg,
  color,
}: {
  blocks: Voxel[];
  yawDeg: number;
  pitchDeg: number;
  color: string;
}) {
  // Center blocks around centroid
  const cx = blocks.reduce((a, b) => a + b[0], 0) / blocks.length;
  const cy = blocks.reduce((a, b) => a + b[1], 0) / blocks.length;
  const cz = blocks.reduce((a, b) => a + b[2], 0) / blocks.length;

  const projected = blocks
    .map(([x, y, z]) => {
      const p = projectIso([x - cx, y - cy, z - cz], yawDeg, pitchDeg);
      return { ...p };
    })
    .sort((a, b) => a.depth - b.depth);

  const scale = 22;

  return (
    <svg viewBox="-65 -65 130 130" className="h-36 w-36 sm:h-44 sm:w-44">
      {projected.map((p, idx) => {
        const px = p.sx * scale;
        const py = p.sy * scale;
        const shade = Math.max(0.55, Math.min(1, 0.78 + p.depth * 0.12));
        return (
          <g key={idx} transform={`translate(${px}, ${py})`}>
            <rect
              x={-11}
              y={-11}
              width={22}
              height={22}
              rx={3}
              fill={color}
              fillOpacity={shade}
              stroke="#0f172a"
              strokeWidth={1.6}
            />
            <line
              x1={-7}
              y1={-7}
              x2={7}
              y2={-7}
              stroke="#ffffff"
              strokeOpacity={0.35}
              strokeWidth={1.6}
            />
          </g>
        );
      })}
    </svg>
  );
}

function ThreePolycubeCanvas({
  blocks,
  color,
  autoRotate,
}: {
  blocks: Voxel[];
  color: string;
  autoRotate: boolean;
}) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const autoRotateRef = useRef(autoRotate);
  autoRotateRef.current = autoRotate;
  const [webglError, setWebglError] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer | null = null;
    let rafId = 0;
    let controls: OrbitControls | null = null;
    let scene: THREE.Scene | null = null;
    let envTarget: THREE.WebGLRenderTarget | null = null;
    let resizeObserver: ResizeObserver | null = null;

    try {
      const width = container.clientWidth || 340;
      const height = container.clientHeight || 260;

      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      const gl = renderer.getContext();
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      const gpu = dbg ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) : '';
      const isSoftwareGl = /SwiftShader|llvmpipe|Software|Microsoft Basic/i.test(gpu);

      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isSoftwareGl ? 1 : 2));
      renderer.setSize(width, height);
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.05;

      container.innerHTML = '';
      container.appendChild(renderer.domElement);

      scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
      camera.position.set(4.5, 3.8, 5.2);

      const pmrem = new THREE.PMREMGenerator(renderer);
      envTarget = pmrem.fromScene(new RoomEnvironment(), 0.04);
      scene.environment = envTarget.texture;
      pmrem.dispose();

      const keyLight = new THREE.DirectionalLight('#fff8eb', 2.2);
      keyLight.position.set(5, 7, 6);
      scene.add(keyLight);
      scene.add(new THREE.HemisphereLight('#e0e7ff', '#1e293b', 0.8));

      const group = new THREE.Group();
      const cx = blocks.reduce((a, b) => a + b[0], 0) / blocks.length;
      const cy = blocks.reduce((a, b) => a + b[1], 0) / blocks.length;
      const cz = blocks.reduce((a, b) => a + b[2], 0) / blocks.length;

      const geo = new THREE.BoxGeometry(0.94, 0.94, 0.94);
      const edgeGeo = new THREE.EdgesGeometry(geo);
      const mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(color),
        roughness: 0.3,
        metalness: 0.15,
      });
      const edgeMat = new THREE.LineBasicMaterial({ color: '#0f172a', transparent: true, opacity: 0.55 });

      blocks.forEach(([x, y, z]) => {
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(x - cx, y - cy, z - cz);
        const wire = new THREE.LineSegments(edgeGeo, edgeMat);
        mesh.add(wire);
        group.add(mesh);
      });

      scene.add(group);

      controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.dampingFactor = 0.06;
      controls.enablePan = false;
      controls.minDistance = 3.2;
      controls.maxDistance = 10;

      const animate = () => {
        rafId = requestAnimationFrame(animate);
        if (autoRotateRef.current) {
          group.rotation.y += 0.008;
        }
        controls?.update();
        if (renderer && scene) {
          renderer.render(scene, camera);
        }
      };
      animate();

      resizeObserver = new ResizeObserver(() => {
        if (!container || !renderer) return;
        const w = container.clientWidth || 340;
        const h = container.clientHeight || 260;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      });
      resizeObserver.observe(container);
    } catch {
      setWebglError(true);
    }

    return () => {
      cancelAnimationFrame(rafId);
      resizeObserver?.disconnect();
      controls?.dispose();
      if (scene) {
        scene.traverse((obj) => {
          if (obj instanceof THREE.Mesh || obj instanceof THREE.LineSegments) {
            obj.geometry?.dispose();
            if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
            else obj.material?.dispose();
          }
        });
      }
      envTarget?.dispose();
      if (renderer) {
        renderer.dispose();
        renderer.domElement.remove();
      }
    };
  }, [blocks, color]);

  if (webglError) {
    return (
      <div className="flex h-80 sm:h-96 items-center justify-center rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-950">
        <PolycubeProjectionSvg blocks={blocks} yawDeg={35} pitchDeg={26} color={color} />
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="h-80 sm:h-96 w-full rounded-2xl border border-slate-200 dark:border-slate-700 bg-gradient-to-br from-slate-100 to-indigo-50/70 dark:from-slate-950 dark:to-slate-900 touch-none cursor-grab active:cursor-grabbing"
    />
  );
}

export function Rotation3DGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [autoRotate, setAutoRotate] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [eliminatedOpts, setEliminatedOpts] = useState<number[]>([]);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () =>
      generateRotationStages(
        settings.stagesCount,
        settings.difficulty,
        settings.language,
        settings.seed || Date.now()
      ),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || selectedOpt !== null) return;
    if (timeLeft <= 0) {
      handleChoose(-1);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, selectedOpt]);

  const handleUseHint = () => {
    if (hintsLeft <= 0 || selectedOpt !== null || !current) return;
    const wrong = [0, 1, 2, 3].filter((i) => i !== current.correctIndex && !eliminatedOpts.includes(i));
    if (wrong.length === 0) return;
    setEliminatedOpts((prev) => [...prev, wrong[0]]);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleChoose = (optIdx: number) => {
    if (selectedOpt !== null || !current) return;
    const timeTakenMs = Math.max(300, Date.now() - stageStartedAt);
    const isCorrect = optIdx === current.correctIndex;
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    setSelectedOpt(optIdx);
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: current.explanation,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} ${
        settings.showExplanation ? `— ${current.explanation}` : ''
      }`,
    });

    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'rotation-3d',
          category: 'spatial',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setSelectedOpt(null);
        setFeedback(null);
        setEliminatedOpts([]);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1500);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setSelectedOpt(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setEliminatedOpts([]);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  const prompt =
    settings.language === 'ru'
      ? 'Поверните 3D-фигуру мышью или пальцем и выберите её правильную проекцию (без зеркала):'
      : settings.language === 'en'
        ? 'Drag to rotate the 3D polycube and select its true rotated view (not mirrored):'
        : toNewUzbekAlphabet(
            "3D shaklni sichqoncha yoki barmoq bilan aylantirib, uning to'g'ri aylantirilgan ko'rinishini tanlang:"
          );

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-base font-medium text-slate-700 dark:text-slate-200">{prompt}</p>
          <button
            type="button"
            onClick={() => setAutoRotate((r) => !r)}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-sm font-medium text-slate-700 dark:text-slate-200 cursor-pointer"
          >
            {autoRotate ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            <RotateCw className="h-4 w-4" />
            <span>{autoRotate ? 'Auto ON' : 'Auto OFF'}</span>
          </button>
        </div>

        <ThreePolycubeCanvas
          blocks={current.target.blocks}
          color={current.target.accentColor}
          autoRotate={autoRotate}
        />

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {current.options.map((opt, idx) => {
            const isEliminated = eliminatedOpts.includes(idx);
            const isSelected = selectedOpt === idx;
            const isCorrect = selectedOpt !== null && idx === current.correctIndex;
            const isWrong = isSelected && idx !== current.correctIndex;

            return (
              <button
                key={idx}
                type="button"
                disabled={selectedOpt !== null || isEliminated}
                onClick={() => handleChoose(idx)}
                className={`flex flex-col items-center justify-center rounded-xl border p-3 transition-all cursor-pointer disabled:cursor-default ${
                  isEliminated
                    ? 'opacity-20 border-slate-200 dark:border-slate-800'
                    : isCorrect
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40'
                      : isWrong
                        ? 'border-red-500 bg-red-50 dark:bg-red-950/40'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:border-amber-500'
                }`}
              >
                <PolycubeProjectionSvg
                  blocks={opt.blocks}
                  yawDeg={opt.yawDeg}
                  pitchDeg={opt.pitchDeg}
                  color={current.target.accentColor}
                />
              </button>
            );
          })}
        </div>
      </div>
    </GameShell>
  );
}
