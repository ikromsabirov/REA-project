import React, { useEffect, useMemo, useRef, useState } from 'react';
import { RotateCw, FlipHorizontal2 } from 'lucide-react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface TanPiece {
  id: string;
  label: string;
  color: string;
  polygon: string; // centered around (0,0)
  targetX: number;
  targetY: number;
  targetRot: number; // multiples of 45
  targetFlip?: boolean;
  symmetricalRotMod?: number; // e.g. 90 for square
}

interface TanPlacement {
  x: number;
  y: number;
  rot: number;
  flipped: boolean;
  snapped: boolean;
}

interface TangramPuzzle {
  title: Record<Language, string>;
  pieces: TanPiece[];
}

const PUZZLES: TangramPuzzle[] = [
  {
    title: {
      uz: toNewUzbekAlphabet('Kvadrat va uy silueti'),
      ru: 'Геометрический дом',
      en: 'Geometric House',
    },
    pieces: [
      {
        id: 'roof-left',
        label: 'A',
        color: '#4f46e5',
        polygon: '-40,20 0,-20 40,20',
        targetX: 180,
        targetY: 90,
        targetRot: 0,
      },
      {
        id: 'body-sq',
        label: 'B',
        color: '#0284c7',
        polygon: '-30,-30 30,-30 30,30 -30,30',
        targetX: 180,
        targetY: 140,
        targetRot: 0,
        symmetricalRotMod: 90,
      },
      {
        id: 'wing-tri',
        label: 'C',
        color: '#d97706',
        polygon: '-25,-25 25,25 -25,25',
        targetX: 235,
        targetY: 145,
        targetRot: 0,
      },
      {
        id: 'chimney',
        label: 'D',
        color: '#059669',
        polygon: '-12,-20 12,-20 12,20 -12,20',
        targetX: 215,
        targetY: 75,
        targetRot: 0,
        symmetricalRotMod: 180,
      },
    ],
  },
  {
    title: {
      uz: toNewUzbekAlphabet('Raketa silueti'),
      ru: 'Ракета',
      en: 'Rocket Silhouette',
    },
    pieces: [
      {
        id: 'nose',
        label: 'A',
        color: '#e11d48',
        polygon: '-28,24 0,-26 28,24',
        targetX: 180,
        targetY: 66,
        targetRot: 0,
      },
      {
        id: 'core',
        label: 'B',
        color: '#4f46e5',
        polygon: '-28,-35 28,-35 28,35 -28,35',
        targetX: 180,
        targetY: 125,
        targetRot: 0,
        symmetricalRotMod: 180,
      },
      {
        id: 'fin-l',
        label: 'C',
        color: '#d97706',
        polygon: '0,-28 0,28 -28,28',
        targetX: 152,
        targetY: 152,
        targetRot: 0,
      },
      {
        id: 'fin-r',
        label: 'D',
        color: '#059669',
        polygon: '0,-28 28,28 0,28',
        targetX: 208,
        targetY: 152,
        targetRot: 0,
      },
      {
        id: 'flame',
        label: 'E',
        color: '#f59e0b',
        polygon: '-20,-16 20,-16 0,22',
        targetX: 180,
        targetY: 182,
        targetRot: 0,
      },
    ],
  },
  {
    title: {
      uz: toNewUzbekAlphabet('Kema silueti'),
      ru: 'Парусник',
      en: 'Sailboat Silhouette',
    },
    pieces: [
      {
        id: 'sail-main',
        label: 'A',
        color: '#0284c7',
        polygon: '-28,32 28,32 -28,-32',
        targetX: 186,
        targetY: 96,
        targetRot: 0,
      },
      {
        id: 'sail-sub',
        label: 'B',
        color: '#f59e0b',
        polygon: '18,22 -18,22 18,-22',
        targetX: 144,
        targetY: 106,
        targetRot: 0,
      },
      {
        id: 'hull',
        label: 'C',
        color: '#7c3aed',
        polygon: '-55,-16 55,-16 35,16 -35,16',
        targetX: 175,
        targetY: 158,
        targetRot: 0,
      },
      {
        id: 'flag',
        label: 'D',
        color: '#e11d48',
        polygon: '-14,-10 14,0 -14,10',
        targetX: 172,
        targetY: 54,
        targetRot: 0,
      },
    ],
  },
];

function createInitialPlacements(puzzle: TangramPuzzle, difficulty: Difficulty): Record<string, TanPlacement> {
  const out: Record<string, TanPlacement> = {};
  puzzle.pieces.forEach((p, idx) => {
    out[p.id] = {
      x: 68 + (idx % 3) * 112,
      y: 255 + Math.floor(idx / 3) * 58,
      rot: difficulty === 'easy' ? p.targetRot : ((idx + 1) * 45) % 360,
      flipped: false,
      snapped: false,
    };
  });
  return out;
}

export function TangramGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () => Array.from({ length: settings.stagesCount }, (_, i) => PUZZLES[i % PUZZLES.length]),
    [settings.stagesCount]
  );

  const current = stages[stageIdx];
  const [placements, setPlacements] = useState<Record<string, TanPlacement>>(() =>
    current ? createInitialPlacements(current, settings.difficulty) : {}
  );
  const [activeId, setActiveId] = useState<string | null>(null);
  const [draggingId, setDraggingId] = useState<string | null>(null);

  useEffect(() => {
    if (current) {
      setPlacements(createInitialPlacements(current, settings.difficulty));
      setActiveId(current.pieces[0]?.id ?? null);
    }
  }, [stageIdx, current, settings.difficulty]);

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      finishStage(false);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const finishStage = (isCorrect: boolean) => {
    if (feedback || !current) return;
    const timeTakenMs = Math.max(400, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };

    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'tangram',
          category: 'spatial',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1300);
  };

  const toSvgCoords = (clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return { x: 180, y: 150 };
    const rect = svg.getBoundingClientRect();
    return {
      x: ((clientX - rect.left) / rect.width) * 360,
      y: ((clientY - rect.top) / rect.height) * 340,
    };
  };

  const checkSnapAndWin = (piece: TanPiece, pl: TanPlacement, all: Record<string, TanPlacement>) => {
    const dist = Math.hypot(pl.x - piece.targetX, pl.y - piece.targetY);
    const rotMod = piece.symmetricalRotMod ?? 360;
    const rotAligned = ((pl.rot - piece.targetRot) % rotMod + rotMod) % rotMod === 0;
    const updated = { ...pl };
    if (dist < 22 && rotAligned) {
      updated.x = piece.targetX;
      updated.y = piece.targetY;
      updated.rot = piece.targetRot;
      updated.snapped = true;
    } else {
      updated.snapped = false;
    }
    const nextAll = { ...all, [piece.id]: updated };
    setPlacements(nextAll);
    if (current.pieces.every((p) => nextAll[p.id]?.snapped)) {
      finishStage(true);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!draggingId || !current || feedback) return;
    const pt = toSvgCoords(e.clientX, e.clientY);
    setPlacements((prev) => ({
      ...prev,
      [draggingId]: {
        ...prev[draggingId],
        x: Math.max(25, Math.min(335, pt.x)),
        y: Math.max(25, Math.min(315, pt.y)),
        snapped: false,
      },
    }));
  };

  const handlePointerUp = () => {
    if (!draggingId || !current) return;
    const piece = current.pieces.find((p) => p.id === draggingId);
    const pl = placements[draggingId];
    setDraggingId(null);
    if (piece && pl) checkSnapAndWin(piece, pl, placements);
  };

  const rotateActive = () => {
    if (!activeId || !current || feedback) return;
    const piece = current.pieces.find((p) => p.id === activeId);
    const pl = placements[activeId];
    if (!piece || !pl) return;
    const updated = { ...pl, rot: (pl.rot + 45) % 360 };
    checkSnapAndWin(piece, updated, placements);
  };

  const flipActive = () => {
    if (!activeId || !current || feedback) return;
    const piece = current.pieces.find((p) => p.id === activeId);
    const pl = placements[activeId];
    if (!piece || !pl) return;
    const updated = { ...pl, flipped: !pl.flipped };
    checkSnapAndWin(piece, updated, placements);
  };

  const handleUseHint = () => {
    if (hintsLeft <= 0 || !current || feedback) return;
    const unsnapped = current.pieces.find((p) => !placements[p.id]?.snapped);
    if (!unsnapped) return;
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
    const snappedPl: TanPlacement = {
      x: unsnapped.targetX,
      y: unsnapped.targetY,
      rot: unsnapped.targetRot,
      flipped: false,
      snapped: true,
    };
    checkSnapAndWin(unsnapped, snappedPl, placements);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-base font-semibold text-slate-800 dark:text-slate-100">
            {current.title[settings.language]}
          </p>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={rotateActive}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
            >
              <RotateCw className="h-4 w-4" />
              <span>+45°</span>
            </button>
            <button
              type="button"
              onClick={flipActive}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
            >
              <FlipHorizontal2 className="h-4 w-4" />
              <span>Flip</span>
            </button>
          </div>
        </div>

        <svg
          ref={svgRef}
          viewBox="0 0 360 340"
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          className="mx-auto w-full max-w-2xl rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 touch-none select-none"
        >
          {/* Target Silhouette Slots */}
          {current.pieces.map((p) => (
            <polygon
              key={`slot-${p.id}`}
              points={p.polygon}
              transform={`translate(${p.targetX}, ${p.targetY}) rotate(${p.targetRot})`}
              fill="#cbd5e1"
              fillOpacity={0.38}
              stroke="#64748b"
              strokeDasharray="4 3"
              strokeWidth={1.5}
            />
          ))}

          {/* Draggable Pieces */}
          {current.pieces.map((p) => {
            const pl = placements[p.id];
            if (!pl) return null;
            const isSelected = activeId === p.id;
            return (
              <g
                key={p.id}
                transform={`translate(${pl.x}, ${pl.y}) rotate(${pl.rot}) scale(${pl.flipped ? -1 : 1}, 1)`}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  setActiveId(p.id);
                  setDraggingId(p.id);
                }}
                className="cursor-grab active:cursor-grabbing"
              >
                <polygon
                  points={p.polygon}
                  fill={p.color}
                  fillOpacity={pl.snapped ? 0.96 : 0.85}
                  stroke={isSelected ? '#ffffff' : '#0f172a'}
                  strokeWidth={isSelected ? 2.5 : 1.5}
                />
                {pl.snapped && (
                  <circle r={4} fill="#10b981" stroke="#ffffff" strokeWidth={1.5} />
                )}
              </g>
            );
          })}
        </svg>
      </div>
    </GameShell>
  );
}
