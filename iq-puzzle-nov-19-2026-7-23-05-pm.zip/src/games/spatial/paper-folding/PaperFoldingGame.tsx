import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

type FoldKind = 'vertical-half' | 'horizontal-half' | 'quarter';

interface Hole {
  x: number; // 0..3 grid on 4x4 paper
  y: number;
}

interface PaperFoldStage {
  folds: FoldKind;
  punches: Hole[]; // punches in folded quadrant/half
  options: Hole[][];
  correctIndex: number;
  explanation: string;
}

function unfoldHoles(folds: FoldKind, punches: Hole[]): Hole[] {
  const result = new Map<string, Hole>();
  const add = (x: number, y: number) => result.set(`${x},${y}`, { x, y });

  for (const p of punches) {
    if (folds === 'vertical-half') {
      // Folded right over left -> punch in left half x in {0,1}, y in {0..3}
      add(p.x, p.y);
      add(3 - p.x, p.y);
    } else if (folds === 'horizontal-half') {
      // Folded bottom over top -> punch in top half x in {0..3}, y in {0,1}
      add(p.x, p.y);
      add(p.x, 3 - p.y);
    } else {
      // Quarter fold -> punch in top-left x in {0,1}, y in {0,1}
      add(p.x, p.y);
      add(3 - p.x, p.y);
      add(p.x, 3 - p.y);
      add(3 - p.x, 3 - p.y);
    }
  }
  return Array.from(result.values());
}

function holesSignature(holes: Hole[]): string {
  return holes
    .map((h) => `${h.x},${h.y}`)
    .sort()
    .join('|');
}

function generatePaperFoldingStages(
  count: number,
  difficulty: Difficulty,
  lang: Language,
  seed: number
): PaperFoldStage[] {
  const rng = createSeededRng(seed);
  const stages: PaperFoldStage[] = [];
  const foldTypes: FoldKind[] =
    difficulty === 'easy'
      ? ['vertical-half', 'horizontal-half']
      : ['vertical-half', 'horizontal-half', 'quarter'];

  for (let i = 0; i < count; i++) {
    const folds = foldTypes[i % foldTypes.length];
    const punchCount = difficulty === 'hard' ? 2 : 1;
    const punches: Hole[] = [];

    for (let p = 0; p < punchCount; p++) {
      const px = folds === 'horizontal-half' ? Math.floor(rng() * 4) : Math.floor(rng() * 2);
      const py = folds === 'vertical-half' ? Math.floor(rng() * 4) : Math.floor(rng() * 2);
      if (!punches.some((h) => h.x === px && h.y === py)) {
        punches.push({ x: px, y: py });
      } else {
        punches.push({ x: (px + 1) % 2, y: py });
      }
    }

    const answer = unfoldHoles(folds, punches);
    const seen = new Set([holesSignature(answer)]);
    const distractors: Hole[][] = [];

    let guard = 0;
    while (distractors.length < 3 && guard < 80) {
      guard++;
      const mutated = answer.map((h, idx) =>
        idx === guard % answer.length ? { x: (h.x + 1) % 4, y: (h.y + (guard % 2)) % 4 } : h
      );
      // Occasionally drop a symmetric reflection for classic distractor
      const candidate = guard % 2 === 0 && answer.length > 2 ? answer.slice(0, -1) : mutated;
      const sig = holesSignature(candidate);
      if (!seen.has(sig)) {
        seen.add(sig);
        distractors.push(candidate);
      }
    }

    const options = [...distractors];
    const correctIndex = Math.floor(rng() * 4);
    options.splice(correctIndex, 0, answer);

    const foldText =
      folds === 'quarter'
        ? lang === 'ru'
          ? 'вчетверо (4 симметрии)'
          : lang === 'en'
            ? 'into quarters (4-way symmetry)'
            : toNewUzbekAlphabet("to'rtga (4 tomonlama simmetriya)")
        : lang === 'ru'
          ? 'пополам (зеркальная симметрия)'
          : lang === 'en'
            ? 'in half (mirror symmetry)'
            : toNewUzbekAlphabet('ikkiga (oyna simmetriyasi)');

    const explanation =
      lang === 'ru'
        ? `Лист сложен ${foldText}, поэтому каждое отверстие отражается по линиям сгиба.`
        : lang === 'en'
          ? `The sheet was folded ${foldText}, reflecting every punch across each crease.`
          : toNewUzbekAlphabet(
              `Qog'oz ${foldText} buklangani sababli har bir teshik buklama chizig'i bo'ylab aks etadi.`
            );

    stages.push({ folds, punches, options, correctIndex, explanation });
  }
  return stages;
}

function PaperSvg({
  folds,
  holes,
  showFoldedOnly,
  large,
}: {
  folds: FoldKind;
  holes: Hole[];
  showFoldedOnly?: boolean;
  large?: boolean;
}) {
  return (
    <svg
      viewBox="0 0 120 120"
      className={large ? 'h-44 w-44 sm:h-52 sm:w-52' : 'h-36 w-36 sm:h-44 sm:w-44'}
    >
      <rect x={8} y={8} width={104} height={104} rx={8} fill="#fef3c7" stroke="#d97706" strokeWidth={2} />

      {showFoldedOnly && folds === 'vertical-half' && (
        <rect x={60} y={8} width={52} height={104} rx={4} fill="#cbd5e1" fillOpacity={0.65} />
      )}
      {showFoldedOnly && folds === 'horizontal-half' && (
        <rect x={8} y={60} width={104} height={52} rx={4} fill="#cbd5e1" fillOpacity={0.65} />
      )}
      {showFoldedOnly && folds === 'quarter' && (
        <>
          <rect x={60} y={8} width={52} height={104} fill="#cbd5e1" fillOpacity={0.65} />
          <rect x={8} y={60} width={52} height={52} fill="#cbd5e1" fillOpacity={0.65} />
        </>
      )}

      {/* Crease lines */}
      <line x1={60} y1={8} x2={60} y2={112} stroke="#94a3b8" strokeDasharray="4 3" strokeWidth={1.5} />
      <line x1={8} y1={60} x2={112} y2={60} stroke="#94a3b8" strokeDasharray="4 3" strokeWidth={1.5} />

      {/* Punched holes */}
      {holes.map((h, i) => (
        <circle
          key={i}
          cx={21 + h.x * 26}
          cy={21 + h.y * 26}
          r={9}
          fill="#0f172a"
          stroke="#f59e0b"
          strokeWidth={1.5}
        />
      ))}
    </svg>
  );
}

export function PaperFoldingGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [eliminatedOpts, setEliminatedOpts] = useState<number[]>([]);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () =>
      generatePaperFoldingStages(
        settings.stagesCount,
        settings.difficulty,
        settings.language,
        settings.seed || Date.now()
      ),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || selectedOpt !== null) return;
    if (timeLeft <= 0) {
      handleChoose(-1);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, selectedOpt]);

  const handleUseHint = () => {
    if (hintsLeft <= 0 || selectedOpt !== null || !current) return;
    const wrong = [0, 1, 2, 3].filter((i) => i !== current.correctIndex && !eliminatedOpts.includes(i));
    if (wrong.length === 0) return;
    setEliminatedOpts((prev) => [...prev, wrong[0]]);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleChoose = (optIdx: number) => {
    if (selectedOpt !== null || !current) return;
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const isCorrect = optIdx === current.correctIndex;
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    setSelectedOpt(optIdx);
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: current.explanation,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} ${
        settings.showExplanation ? `— ${current.explanation}` : ''
      }`,
    });

    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'paper-folding',
          category: 'spatial',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setSelectedOpt(null);
        setFeedback(null);
        setEliminatedOpts([]);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1500);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setSelectedOpt(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setEliminatedOpts([]);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  const prompt =
    settings.language === 'ru'
      ? 'Сложенный лист прокололи. Как он будет выглядеть после полного разворачивания?'
      : settings.language === 'en'
        ? 'The folded sheet is punched as shown. What pattern appears when unfolded?'
        : toNewUzbekAlphabet(
            "Buklangan qog'oz teshib chiqildi. Ochilganda qanday shakl hosil bo'ladi?"
          );

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-6">
        <p className="text-center text-base font-medium text-slate-700 dark:text-slate-200">{prompt}</p>

        <div className="flex flex-col items-center gap-2 rounded-2xl border border-amber-200 dark:border-amber-900 bg-amber-50/40 dark:bg-amber-950/20 p-5">
          <PaperSvg folds={current.folds} holes={current.punches} showFoldedOnly large />
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-700 dark:text-amber-400">
            {current.folds.replace('-', ' ')}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {current.options.map((opt, idx) => {
            const isEliminated = eliminatedOpts.includes(idx);
            const isSelected = selectedOpt === idx;
            const isCorrect = selectedOpt !== null && idx === current.correctIndex;
            const isWrong = isSelected && idx !== current.correctIndex;

            return (
              <button
                key={idx}
                type="button"
                disabled={selectedOpt !== null || isEliminated}
                onClick={() => handleChoose(idx)}
                className={`flex items-center justify-center rounded-xl border p-3 transition-all cursor-pointer disabled:cursor-default ${
                  isEliminated
                    ? 'opacity-20 border-slate-200 dark:border-slate-800'
                    : isCorrect
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40'
                      : isWrong
                        ? 'border-red-500 bg-red-50 dark:bg-red-950/40'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:border-amber-500'
                }`}
              >
                <PaperSvg folds={current.folds} holes={opt} />
              </button>
            );
          })}
        </div>
      </div>
    </GameShell>
  );
}
