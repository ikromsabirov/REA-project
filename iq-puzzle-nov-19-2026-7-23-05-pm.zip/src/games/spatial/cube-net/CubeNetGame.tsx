import { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Box } from 'lucide-react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface FaceSpec {
  symbol: string;
  color: string;
}

interface NetCell {
  r: number;
  c: number;
  faceKey: 'T' | 'B' | 'F' | 'K' | 'L' | 'R'; // Top, Bottom, Front, BacK, Left, Right
  face: FaceSpec;
}

interface CubeNetStage {
  net: NetCell[];
  askFace: NetCell['faceKey'];
  correctOpposite: FaceSpec;
  options: FaceSpec[];
  correctIndex: number;
  explanation: string;
}

const SYMBOLS: FaceSpec[] = [
  { symbol: '★', color: '#4f46e5' },
  { symbol: '▲', color: '#0284c7' },
  { symbol: '●', color: '#059669' },
  { symbol: '◆', color: '#d97706' },
  { symbol: '■', color: '#e11d48' },
  { symbol: '✚', color: '#7c3aed' },
];

// Cross net & T-net layouts with guaranteed topological opposite pairs: (T<->B), (F<->K), (L<->R)
const NET_LAYOUTS: Array<Array<{ r: number; c: number; key: NetCell['faceKey'] }>> = [
  // Classic cross
  [
    { r: 0, c: 1, key: 'T' },
    { r: 1, c: 0, key: 'L' },
    { r: 1, c: 1, key: 'F' },
    { r: 1, c: 2, key: 'R' },
    { r: 2, c: 1, key: 'B' },
    { r: 3, c: 1, key: 'K' },
  ],
  // Shifted Z-net
  [
    { r: 0, c: 0, key: 'L' },
    { r: 0, c: 1, key: 'T' },
    { r: 1, c: 1, key: 'F' },
    { r: 2, c: 1, key: 'B' },
    { r: 2, c: 2, key: 'R' },
    { r: 3, c: 1, key: 'K' },
  ],
];

const OPPOSITE_MAP: Record<NetCell['faceKey'], NetCell['faceKey']> = {
  T: 'B',
  B: 'T',
  F: 'K',
  K: 'F',
  L: 'R',
  R: 'L',
};

function generateCubeNetStages(
  count: number,
  difficulty: Difficulty,
  lang: Language,
  seed: number
): CubeNetStage[] {
  const rng = createSeededRng(seed);
  const stages: CubeNetStage[] = [];

  for (let i = 0; i < count; i++) {
    const layout = NET_LAYOUTS[difficulty === 'easy' ? 0 : i % NET_LAYOUTS.length];
    const shuffledFaces = [...SYMBOLS].sort(() => rng() - 0.5);
    const net: NetCell[] = layout.map((cell, idx) => ({
      r: cell.r,
      c: cell.c,
      faceKey: cell.key,
      face: shuffledFaces[idx],
    }));

    const askCell = net[Math.floor(rng() * net.length)];
    const oppKey = OPPOSITE_MAP[askCell.faceKey];
    const oppCell = net.find((n) => n.faceKey === oppKey)!;

    const distractors = net
      .filter((n) => n.face.symbol !== oppCell.face.symbol && n.face.symbol !== askCell.face.symbol)
      .slice(0, 3)
      .map((n) => n.face);

    const options = [...distractors];
    const correctIndex = Math.floor(rng() * 4);
    options.splice(correctIndex, 0, oppCell.face);

    const explanation =
      lang === 'ru'
        ? `При сворачивании развёртки в куб грань "${askCell.face.symbol}" оказывается напротив "${oppCell.face.symbol}".`
        : lang === 'en'
          ? `When folded into a 3D cube, face "${askCell.face.symbol}" sits directly opposite "${oppCell.face.symbol}".`
          : toNewUzbekAlphabet(
              `Yoyilma 3D kubga yig'ilganda "${askCell.face.symbol}" belgisi "${oppCell.face.symbol}" ga qarama-qarshi joylashadi.`
            );

    stages.push({
      net,
      askFace: askCell.faceKey,
      correctOpposite: oppCell.face,
      options,
      correctIndex,
      explanation,
    });
  }
  return stages;
}

function makeFaceTexture(face: FaceSpec): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, 256, 256);
  ctx.strokeStyle = face.color;
  ctx.lineWidth = 14;
  ctx.strokeRect(10, 10, 236, 236);
  ctx.fillStyle = face.color;
  ctx.font = 'bold 118px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(face.symbol, 128, 134);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function ThreeCubeCheckModal({ net }: { net: NetCell[] }) {
  const hostRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    let renderer: THREE.WebGLRenderer | null = null;
    let raf = 0;
    let controls: OrbitControls | null = null;
    const textures: THREE.CanvasTexture[] = [];

    try {
      const w = host.clientWidth || 240;
      const h = host.clientHeight || 220;
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setSize(w, h);
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      host.innerHTML = '';
      host.appendChild(renderer.domElement);

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(40, w / h, 0.1, 50);
      camera.position.set(2.8, 2.3, 3.1);

      scene.add(new THREE.AmbientLight('#ffffff', 1.4));
      const dl = new THREE.DirectionalLight('#ffffff', 1.1);
      dl.position.set(4, 6, 4);
      scene.add(dl);

      const findFace = (k: NetCell['faceKey']) => net.find((c) => c.faceKey === k)!.face;
      // BoxGeometry material order: +X(R), -X(L), +Y(T), -Y(B), +Z(F), -Z(K)
      const order: NetCell['faceKey'][] = ['R', 'L', 'T', 'B', 'F', 'K'];
      const mats = order.map((k) => {
        const tex = makeFaceTexture(findFace(k));
        textures.push(tex);
        return new THREE.MeshStandardMaterial({ map: tex, roughness: 0.4 });
      });

      const cube = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.5, 1.5), mats);
      scene.add(cube);

      controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.enablePan = false;

      const loop = () => {
        raf = requestAnimationFrame(loop);
        cube.rotation.y += 0.008;
        controls?.update();
        renderer?.render(scene, camera);
      };
      loop();
    } catch {
      // Fallback ignored cleanly
    }

    return () => {
      cancelAnimationFrame(raf);
      controls?.dispose();
      textures.forEach((t) => t.dispose());
      if (renderer) {
        renderer.dispose();
        renderer.domElement.remove();
      }
    };
  }, [net]);

  return (
    <div
      ref={hostRef}
      className="h-52 w-full rounded-2xl border border-indigo-200 dark:border-indigo-800 bg-slate-100 dark:bg-slate-950 touch-none"
    />
  );
}

export function CubeNetGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [eliminatedOpts, setEliminatedOpts] = useState<number[]>([]);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () =>
      generateCubeNetStages(
        settings.stagesCount,
        settings.difficulty,
        settings.language,
        settings.seed || Date.now()
      ),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || selectedOpt !== null) return;
    if (timeLeft <= 0) {
      handleChoose(-1);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, selectedOpt]);

  const handleUseHint = () => {
    if (hintsLeft <= 0 || selectedOpt !== null || !current) return;
    const wrong = [0, 1, 2, 3].filter((i) => i !== current.correctIndex && !eliminatedOpts.includes(i));
    if (wrong.length === 0) return;
    setEliminatedOpts((prev) => [...prev, wrong[0]]);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleChoose = (optIdx: number) => {
    if (selectedOpt !== null || !current) return;
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const isCorrect = optIdx === current.correctIndex;
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    setSelectedOpt(optIdx);
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: current.explanation,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} ${
        settings.showExplanation ? `— ${current.explanation}` : ''
      }`,
    });

    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'cube-net',
          category: 'spatial',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setSelectedOpt(null);
        setFeedback(null);
        setEliminatedOpts([]);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 2200);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setSelectedOpt(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setEliminatedOpts([]);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);
  const askCell = current.net.find((n) => n.faceKey === current.askFace)!;

  const prompt =
    settings.language === 'ru'
      ? `Если сложить эту развёртку в куб, какой символ окажется НАПРОТИВ грани "${askCell.face.symbol}"?`
      : settings.language === 'en'
        ? `When folded into a cube, which face lies OPPOSITE "${askCell.face.symbol}"?`
        : toNewUzbekAlphabet(
            `Ushbu yoyilma kubga yig'ilganda "${askCell.face.symbol}" belgisiga QARAMA-QARSHI qaysi tomon tushadi?`
          );

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-5">
        <p className="text-center text-base font-medium text-slate-700 dark:text-slate-200">{prompt}</p>

        <div className="grid gap-5 md:grid-cols-2 items-center">
          {/* 2D Cube Net */}
          <div className="mx-auto grid grid-cols-3 gap-1.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-4">
            {[0, 1, 2, 3].map((r) =>
              [0, 1, 2].map((c) => {
                const cell = current.net.find((n) => n.r === r && n.c === c);
                if (!cell) return <div key={`${r}-${c}`} className="h-18 w-18 sm:h-24 sm:w-24" />;
                const isAsked = cell.faceKey === current.askFace;
                return (
                  <div
                    key={`${r}-${c}`}
                    className={`flex h-18 w-18 sm:h-24 sm:w-24 items-center justify-center rounded-xl border-2 text-3xl sm:text-4xl font-bold ${
                      isAsked
                        ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/50 ring-2 ring-amber-400/50'
                        : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900'
                    }`}
                    style={{ color: cell.face.color }}
                  >
                    {cell.face.symbol}
                  </div>
                );
              })
            )}
          </div>

          {/* 3D Verification Preview (revealed after answer or informative wireframe before) */}
          <div className="space-y-2 text-center">
            {selectedOpt !== null ? (
              <>
                <ThreeCubeCheckModal net={current.net} />
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  3D Verification
                </p>
              </>
            ) : (
              <div className="flex h-64 flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-950/60 p-4 text-slate-500 dark:text-slate-400">
                <Box className="h-12 w-12 text-amber-500 mb-2" />
                <p className="text-sm font-medium max-w-xs">
                  {settings.language === 'ru'
                    ? 'Выберите ответ, чтобы увидеть 3D-развёртку куба'
                    : settings.language === 'en'
                      ? 'Submit an answer to inspect the interactive 3D folded cube'
                      : toNewUzbekAlphabet("Javob tanlang va 3D kub yig'ilishini tekshiring")}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Options */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {current.options.map((opt, idx) => {
            const isEliminated = eliminatedOpts.includes(idx);
            const isSelected = selectedOpt === idx;
            const isCorrect = selectedOpt !== null && idx === current.correctIndex;
            const isWrong = isSelected && idx !== current.correctIndex;

            return (
              <button
                key={idx}
                type="button"
                disabled={selectedOpt !== null || isEliminated}
                onClick={() => handleChoose(idx)}
                className={`flex h-24 items-center justify-center rounded-xl border text-4xl font-bold transition-all cursor-pointer disabled:cursor-default ${
                  isEliminated
                    ? 'opacity-20 border-slate-200 dark:border-slate-800'
                    : isCorrect
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40'
                      : isWrong
                        ? 'border-red-500 bg-red-50 dark:bg-red-950/40'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:border-amber-500'
                }`}
                style={{ color: opt.color }}
              >
                {opt.symbol}
              </button>
            );
          })}
        </div>
      </div>
    </GameShell>
  );
}
