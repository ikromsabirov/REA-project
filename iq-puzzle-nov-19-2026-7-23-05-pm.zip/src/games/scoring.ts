import type { GameCategoryId, GameResultSummary, GameTypeId, StageOutcome } from './types';
import type { Difficulty, Language } from '../types';

/**
 * Unified IQ PUZZLE Scoring Engine:
 * - Correct answer: 100 base points (scaled if custom max stage points)
 * - Fast answer bonus: 0 - 50 points based on remaining time ratio
 * - Wrong answer: 0 points
 * - Hint deduction: -10 points per hint used (floor 0)
 */
export function calculateStagePoints(params: {
  isCorrect: boolean;
  timeTakenMs: number;
  timeLimitSec: number;
  hintsUsed?: number;
  basePoints?: number;
}): number {
  if (!params.isCorrect) return 0;
  const base = params.basePoints ?? 100;
  const limitMs = Math.max(1000, params.timeLimitSec * 1000);
  const ratio = Math.max(0, Math.min(1, (limitMs - params.timeTakenMs) / limitMs));
  const speedBonus = Math.round(50 * ratio);
  const hintPenalty = (params.hintsUsed ?? 0) * 10;
  return Math.max(10, base + speedBonus - hintPenalty);
}

export function buildResultSummary(params: {
  gameType: GameTypeId;
  category: GameCategoryId;
  difficulty: Difficulty;
  language: Language;
  stages: StageOutcome[];
  maxScorePerStage?: number;
}): GameResultSummary {
  const score = params.stages.reduce((acc, s) => acc + s.pointsAwarded, 0);
  const correctCount = params.stages.filter((s) => s.isCorrect).length;
  const wrongCount = params.stages.filter((s) => !s.isCorrect).length;
  const hintsUsed = params.stages.reduce((acc, s) => acc + s.hintsUsed, 0);
  const timeSpentMs = params.stages.reduce((acc, s) => acc + s.timeTakenMs, 0);
  const total = Math.max(1, params.stages.length);
  const maxScore = total * (params.maxScorePerStage ?? 150);

  return {
    gameType: params.gameType,
    category: params.category,
    difficulty: params.difficulty,
    language: params.language,
    score,
    maxScore,
    correctCount,
    wrongCount,
    hintsUsed,
    timeSpentMs,
    accuracy: Math.round((correctCount / total) * 100),
    stages: params.stages,
  };
}

/**
 * Deterministic seeded PRNG (Mulberry32) so competition rooms generate identical challenges.
 */
export function createSeededRng(seedInput: number): () => number {
  let t = seedInput >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Gentle Web Audio API sound FX (no external MP3 assets required).
 */
let sharedAudioCtx: AudioContext | null = null;

function getAudioCtx(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const Ctx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  if (!sharedAudioCtx) sharedAudioCtx = new Ctx();
  if (sharedAudioCtx.state === 'suspended') {
    sharedAudioCtx.resume().catch(() => {});
  }
  return sharedAudioCtx;
}

export function playTone(freq: number, durationMs = 140, type: OscillatorType = 'sine', enabled = true): void {
  if (!enabled) return;
  try {
    const ctx = getAudioCtx();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + durationMs / 1000);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + durationMs / 1000);
  } catch {
    // ignore audio block
  }
}

export function playSuccessChime(enabled = true): void {
  if (!enabled) return;
  playTone(523.25, 110, 'sine', true);
  setTimeout(() => playTone(659.25, 160, 'sine', true), 90);
}

export function playErrorTone(enabled = true): void {
  if (!enabled) return;
  playTone(220, 180, 'triangle', true);
}

/**
 * Safe recursive-descent arithmetic expression parser (NO eval / Function).
 * Used for Game #20 (Make 24) and arithmetic validation.
 */
export function evaluateSafeArithmetic(expr: string): { valid: boolean; value: number; usedNumbers: number[]; error?: string } {
  const cleaned = expr.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').trim();
  if (!cleaned) return { valid: false, value: 0, usedNumbers: [], error: 'Empty expression' };

  if (!/^[0-9+\-*/().\s]+$/.test(cleaned)) {
    return { valid: false, value: 0, usedNumbers: [], error: 'Unsupported characters in expression' };
  }

  type Token = { type: 'num'; val: number } | { type: 'op'; val: string };
  const tokens: Token[] = [];
  const usedNumbers: number[] = [];

  let i = 0;
  while (i < cleaned.length) {
    const ch = cleaned[i];
    if (ch === ' ') {
      i++;
      continue;
    }
    if (/[0-9]/.test(ch)) {
      let numStr = '';
      while (i < cleaned.length && /[0-9.]/.test(cleaned[i])) {
        numStr += cleaned[i++];
      }
      const num = Number(numStr);
      if (!Number.isFinite(num)) {
        return { valid: false, value: 0, usedNumbers: [], error: 'Invalid number' };
      }
      tokens.push({ type: 'num', val: num });
      usedNumbers.push(num);
      continue;
    }
    if ('+-*/()'.includes(ch)) {
      tokens.push({ type: 'op', val: ch });
      i++;
      continue;
    }
    return { valid: false, value: 0, usedNumbers: [], error: 'Invalid token' };
  }

  let pos = 0;
  const peek = () => tokens[pos];
  const consume = () => tokens[pos++];

  function parseExpr(): number {
    let left = parseTerm();
    while (peek()?.type === 'op' && (peek()!.val === '+' || peek()!.val === '-')) {
      const op = consume()!.val;
      const right = parseTerm();
      left = op === '+' ? left + right : left - right;
    }
    return left;
  }

  function parseTerm(): number {
    let left = parseFactor();
    while (peek()?.type === 'op' && (peek()!.val === '*' || peek()!.val === '/')) {
      const op = consume()!.val;
      const right = parseFactor();
      if (op === '/') {
        if (Math.abs(right) < 1e-9) throw new Error('Division by zero');
        left = left / right;
      } else {
        left = left * right;
      }
    }
    return left;
  }

  function parseFactor(): number {
    const tok = peek();
    if (!tok) throw new Error('Unexpected end of expression');
    if (tok.type === 'op' && tok.val === '(') {
      consume();
      const val = parseExpr();
      const close = consume();
      if (!close || close.type !== 'op' || close.val !== ')') {
        throw new Error('Missing closing parenthesis');
      }
      return val;
    }
    if (tok.type === 'num') {
      consume();
      return tok.val;
    }
    throw new Error('Unexpected token');
  }

  try {
    const value = parseExpr();
    if (pos !== tokens.length) {
      return { valid: false, value: 0, usedNumbers: [], error: 'Unexpected trailing tokens' };
    }
    return { valid: true, value, usedNumbers };
  } catch (err) {
    return {
      valid: false,
      value: 0,
      usedNumbers: [],
      error: err instanceof Error ? err.message : 'Invalid expression',
    };
  }
}
