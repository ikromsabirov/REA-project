import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface WordPlacement {
  word: string;
  cells: Array<{ r: number; c: number }>;
}

interface WordSearchStage {
  size: number;
  grid: string[][];
  placements: WordPlacement[];
}

const WORD_BANKS: Record<Language, string[][]> = {
  uz: [
    [toNewUzbekAlphabet('MANTIQ'), toNewUzbekAlphabet('ZAKO'), toNewUzbekAlphabet('BILIM'), toNewUzbekAlphabet('KITOB')],
    [toNewUzbekAlphabet('SHAKL'), toNewUzbekAlphabet('RAQAM'), toNewUzbekAlphabet('QONUN'), toNewUzbekAlphabet('FIKR')],
    [toNewUzbekAlphabet('OLIM'), toNewUzbekAlphabet('TARIX'), toNewUzbekAlphabet('XOTIRA'), toNewUzbekAlphabet('OYIN')],
  ].map((list) => list.map((w) => w.toUpperCase())),
  ru: [
    ['ЛОГИКА', 'РАЗУМ', 'ЗНАНИЕ', 'КНИГА'],
    ['ЧИСЛО', 'ПАМЯТЬ', 'АНАЛИЗ', 'ЗАДАЧА'],
    ['СХЕМА', 'УЧЁБА', 'ТАЙНА', 'МЫСЛЬ'],
  ],
  en: [
    ['LOGIC', 'BRAIN', 'MEMORY', 'PUZZLE'],
    ['SHAPE', 'NUMBER', 'REASON', 'FOCUS'],
    ['MATRIX', 'CIPHER', 'THEORY', 'SOLVE'],
  ],
};

const ALPHABETS: Record<Language, string> = {
  uz: 'ABDEFGHIJKLMNOPQRSTUVXYZÖĞŞÇ',
  ru: 'АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЫЭЮЯ',
  en: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
};

function generateWordSearchStages(
  count: number,
  difficulty: Difficulty,
  lang: Language,
  seed: number
): WordSearchStage[] {
  const rng = createSeededRng(seed);
  const size = difficulty === 'easy' ? 7 : difficulty === 'medium' ? 8 : 9;
  const banks = WORD_BANKS[lang] || WORD_BANKS.en;
  const alpha = ALPHABETS[lang] || ALPHABETS.en;
  const dirs: Array<[number, number]> =
    difficulty === 'easy'
      ? [
          [0, 1],
          [1, 0],
        ]
      : [
          [0, 1],
          [1, 0],
          [1, 1],
          [-1, 1],
        ];

  const stages: WordSearchStage[] = [];
  for (let s = 0; s < count; s++) {
    const words = banks[s % banks.length];
    const grid: string[][] = Array.from({ length: size }, () => Array(size).fill(''));
    const placements: WordPlacement[] = [];

    for (const word of words) {
      const chars = Array.from(word);
      if (chars.length > size) continue;
      let placed = false;

      for (let attempt = 0; attempt < 80 && !placed; attempt++) {
        const [dr, dc] = dirs[Math.floor(rng() * dirs.length)];
        const r0 = Math.floor(rng() * size);
        const c0 = Math.floor(rng() * size);
        const rEnd = r0 + dr * (chars.length - 1);
        const cEnd = c0 + dc * (chars.length - 1);
        if (rEnd < 0 || rEnd >= size || cEnd < 0 || cEnd >= size) continue;

        let ok = true;
        const cells: Array<{ r: number; c: number }> = [];
        for (let k = 0; k < chars.length; k++) {
          const r = r0 + dr * k;
          const c = c0 + dc * k;
          if (grid[r][c] !== '' && grid[r][c] !== chars[k]) {
            ok = false;
            break;
          }
          cells.push({ r, c });
        }
        if (ok) {
          cells.forEach(({ r, c }, idx) => {
            grid[r][c] = chars[idx];
          });
          placements.push({ word, cells });
          placed = true;
        }
      }
    }

    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (!grid[r][c]) {
          grid[r][c] = alpha[Math.floor(rng() * alpha.length)];
        }
      }
    }
    stages.push({ size, grid, placements });
  }
  return stages;
}

function getLineCells(a: { r: number; c: number }, b: { r: number; c: number }): Array<{ r: number; c: number }> | null {
  const dr = b.r - a.r;
  const dc = b.c - a.c;
  const steps = Math.max(Math.abs(dr), Math.abs(dc));
  if (steps === 0) return [a];
  if (dr !== 0 && dc !== 0 && Math.abs(dr) !== Math.abs(dc)) return null;
  const sr = dr === 0 ? 0 : dr / Math.abs(dr);
  const sc = dc === 0 ? 0 : dc / Math.abs(dc);
  const out: Array<{ r: number; c: number }> = [];
  for (let i = 0; i <= steps; i++) {
    out.push({ r: a.r + sr * i, c: a.c + sc * i });
  }
  return out;
}

export function WordSearchGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [foundWords, setFoundWords] = useState<string[]>([]);
  const [anchorCell, setAnchorCell] = useState<{ r: number; c: number } | null>(null);
  const [hintCell, setHintCell] = useState<{ r: number; c: number } | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () =>
      generateWordSearchStages(
        settings.stagesCount,
        settings.difficulty,
        settings.language,
        settings.seed || Date.now()
      ),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    setFoundWords([]);
    setAnchorCell(null);
    setHintCell(null);
  }, [stageIdx]);

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      finishStage(false);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const finishStage = (isCorrect: boolean) => {
    if (!current || feedback) return;
    const timeTakenMs = Math.max(400, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };
    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'word-search',
          category: 'words',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1200);
  };

  const handleCellTap = (r: number, c: number) => {
    if (!current || feedback) return;
    if (!anchorCell) {
      setAnchorCell({ r, c });
      return;
    }
    if (anchorCell.r === r && anchorCell.c === c) {
      setAnchorCell(null);
      return;
    }
    const line = getLineCells(anchorCell, { r, c });
    setAnchorCell(null);
    if (!line) {
      playErrorTone(soundEnabled);
      return;
    }
    const forward = line.map((p) => current.grid[p.r][p.c]).join('');
    const backward = [...line].reverse().map((p) => current.grid[p.r][p.c]).join('');
    const matched = current.placements.find(
      (p) => !foundWords.includes(p.word) && (p.word === forward || p.word === backward)
    );
    if (matched) {
      playSuccessChime(soundEnabled);
      setHintCell(null);
      const next = [...foundWords, matched.word];
      setFoundWords(next);
      if (next.length === current.placements.length) {
        finishStage(true);
      }
    } else {
      playErrorTone(soundEnabled);
    }
  };

  const handleUseHint = () => {
    if (hintsLeft <= 0 || !current || feedback) return;
    const missing = current.placements.find((p) => !foundWords.includes(p.word));
    if (!missing) return;
    setHintCell(missing.cells[0]);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  const foundCellKeys = new Set<string>();
  current.placements
    .filter((p) => foundWords.includes(p.word))
    .forEach((p) => p.cells.forEach((cell) => foundCellKeys.add(`${cell.r}-${cell.c}`)));

  const guide =
    settings.language === 'ru'
      ? 'Нажмите первую и последнюю букву каждого слова (по горизонтали, вертикали или диагонали):'
      : settings.language === 'en'
        ? 'Tap the first letter and last letter of each hidden word (horizontal, vertical, or diagonal):'
        : toNewUzbekAlphabet(
            "Har bir yashirilgan so'zning birinchi va oxirgi harfini bosing (gorizontal, vertikal yoki diagonal):"
          );

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-4 text-center">
        <p className="text-sm sm:text-base font-medium text-slate-600 dark:text-slate-300">{guide}</p>

        {/* Word list */}
        <div className="flex flex-wrap justify-center gap-2">
          {current.placements.map((p) => {
            const done = foundWords.includes(p.word);
            return (
              <span
                key={p.word}
                className={`rounded-xl border px-3 py-1 font-mono text-sm font-bold ${
                  done
                    ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 line-through'
                    : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100'
                }`}
              >
                {p.word}
              </span>
            );
          })}
        </div>

        {/* Letter Grid */}
        <div
          className="mx-auto grid gap-1 sm:gap-1.5"
          style={{
            maxWidth: `${current.size * 44}px`,
            gridTemplateColumns: `repeat(${current.size}, minmax(0, 1fr))`,
          }}
        >
          {current.grid.map((row, r) =>
            row.map((ch, c) => {
              const key = `${r}-${c}`;
              const isAnchor = anchorCell?.r === r && anchorCell?.c === c;
              const isFound = foundCellKeys.has(key);
              const isHinted = hintCell?.r === r && hintCell?.c === c;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => handleCellTap(r, c)}
                  className={`aspect-square flex items-center justify-center rounded-lg border font-mono text-base sm:text-lg font-bold transition-all cursor-pointer ${
                    isAnchor
                      ? 'border-rose-500 bg-rose-500 text-white'
                      : isFound
                        ? 'border-emerald-400 bg-emerald-100 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300'
                        : isHinted
                          ? 'border-amber-500 bg-amber-100 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300'
                          : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white hover:border-rose-400'
                  }`}
                >
                  {ch}
                </button>
              );
            })
          )}
        </div>
      </div>
    </GameShell>
  );
}
