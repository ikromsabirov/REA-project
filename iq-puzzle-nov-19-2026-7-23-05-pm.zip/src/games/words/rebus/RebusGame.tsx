import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Language } from '../../../types';

interface RebusItem {
  visualClues: string[];
  hint: string;
  answer: string;
  explanation: string;
}

const REBUS_BANK: Record<Language, RebusItem[]> = {
  uz: [
    {
      visualClues: ['☀️', '+', '🌱'],
      hint: toNewUzbekAlphabet('Quyosh nuri ostida o‘sadigan tabiat ne’mati (5 harf)'),
      answer: toNewUzbekAlphabet('GUL'),
      explanation: toNewUzbekAlphabet('Quyosh + nihol = GUL.'),
    },
    {
      visualClues: ['100', 'YUZ', '− Z', '+', 'UK'],
      hint: toNewUzbekAlphabet('Barmoqqa taqiladigan buyum'),
      answer: toNewUzbekAlphabet('UZUK'),
      explanation: toNewUzbekAlphabet('YUZ dan Y olib tashlansa UZ + UK = UZUK.'),
    },
    {
      visualClues: ['📖', '+', '🏛️'],
      hint: toNewUzbekAlphabet('Kitoblar saqlanadigan maskan'),
      answer: toNewUzbekAlphabet('KUTUBXONA'),
      explanation: toNewUzbekAlphabet('Kitob + bino = KUTUBXONA.'),
    },
    {
      visualClues: ['QOR', '+', '⛷️', 'BO‘RON'],
      hint: toNewUzbekAlphabet('Qish faslidagi qor odam nomi'),
      answer: toNewUzbekAlphabet('QORBOBO'),
      explanation: toNewUzbekAlphabet('Qor + Bobo = QORBOBO.'),
    },
    {
      visualClues: ['🕒', 'SOAT', '− AT', '+', 'CHIQ'],
      hint: toNewUzbekAlphabet('Vaqt o‘lchov birligi (6 harf)'),
      answer: toNewUzbekAlphabet('SONIYA'),
      explanation: toNewUzbekAlphabet('Soat bilan bog‘liq eng kichik asosiy birlik — SONIYA.'),
    },
  ],
  ru: [
    {
      visualClues: ['100', 'ЛИЦА'],
      hint: 'Главный город страны',
      answer: 'СТОЛИЦА',
      explanation: 'СТО + ЛИЦА = СТОЛИЦА.',
    },
    {
      visualClues: ['ВОД', '+', 'А', '+', 'ПАД ⬇'],
      hint: 'Падающая с высоты река',
      answer: 'ВОДОПАД',
      explanation: 'ВОДА + ПАДАЕТ = ВОДОПАД.',
    },
    {
      visualClues: ['СНЕГ', '+', '❄️', 'ЧЕЛОВЕК'],
      hint: 'Зимняя фигура из снега',
      answer: 'СНЕГОВИК',
      explanation: 'Фигура из снежных шаров — СНЕГОВИК.',
    },
    {
      visualClues: ['🌳', 'БОР', '− Б', '+', 'ОЗ'],
      hint: 'Звук дерева? Нет, колючее растение / ягода',
      answer: 'ОРЕХ',
      explanation: 'Лесной плод в твёрдой скорлупе — ОРЕХ.',
    },
    {
      visualClues: ['7', 'Я'],
      hint: 'Близкие люди вместе',
      answer: 'СЕМЬЯ',
      explanation: 'СЕМЬ + Я = СЕМЬЯ.',
    },
  ],
  en: [
    {
      visualClues: ['☀️', '+', '🌻'],
      hint: 'Bright yellow flower that follows the sun',
      answer: 'SUNFLOWER',
      explanation: 'SUN + FLOWER = SUNFLOWER.',
    },
    {
      visualClues: ['🌧️', '+', '🎀'],
      hint: 'Colorful arc seen after rain',
      answer: 'RAINBOW',
      explanation: 'RAIN + BOW = RAINBOW.',
    },
    {
      visualClues: ['🔑', '+', '⌨️'],
      hint: 'Device used for typing letters',
      answer: 'KEYBOARD',
      explanation: 'KEY + BOARD = KEYBOARD.',
    },
    {
      visualClues: ['⭐', '+', '🐟'],
      hint: 'Five-armed marine animal',
      answer: 'STARFISH',
      explanation: 'STAR + FISH = STARFISH.',
    },
    {
      visualClues: ['🔥', '+', '🪰'],
      hint: 'Glowing summer insect',
      answer: 'FIREFLY',
      explanation: 'FIRE + FLY = FIREFLY.',
    },
  ],
};

export function RebusGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [revealedPrefix, setRevealedPrefix] = useState(0);
  const [input, setInput] = useState('');
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(() => {
    const rng = createSeededRng(settings.seed || Date.now());
    const bank = [...(REBUS_BANK[settings.language] || REBUS_BANK.en)].sort(() => rng() - 0.5);
    return Array.from({ length: settings.stagesCount }, (_, i) => bank[i % bank.length]);
  }, [settings]);

  const current = stages[stageIdx];

  useEffect(() => {
    setInput('');
    setRevealedPrefix(0);
  }, [stageIdx]);

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      handleSubmit();
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const handleUseHint = () => {
    if (hintsLeft <= 0 || !current || feedback) return;
    const nextLen = Math.min(current.answer.length, revealedPrefix + 2);
    setRevealedPrefix(nextLen);
    setInput(current.answer.slice(0, nextLen));
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleSubmit = () => {
    if (!current || feedback) return;
    const normUser = toNewUzbekAlphabet(input.trim().toUpperCase());
    const normAns = toNewUzbekAlphabet(current.answer.trim().toUpperCase());
    const isCorrect = normUser === normAns;

    const timeTakenMs = Math.max(300, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: current.explanation,
    };
    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : `${ui.wrong} (${current.answer})`} ${
        settings.showExplanation ? `— ${current.explanation}` : ''
      }`,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'rebus',
          category: 'words',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1500);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setInput('');
          setRevealedPrefix(0);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-6 text-center max-w-2xl mx-auto">
        {/* Visual Rebus Cards */}
        <div className="flex flex-wrap items-center justify-center gap-3.5 rounded-2xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/40 dark:bg-rose-950/20 p-6 sm:p-8">
          {current.visualClues.map((clue, idx) => (
            <span
              key={idx}
              className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-5 py-4 font-display text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white"
            >
              {clue}
            </span>
          ))}
        </div>

        <p className="text-base text-slate-600 dark:text-slate-300">{current.hint}</p>

        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            disabled={feedback !== null}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && input.trim()) handleSubmit();
            }}
            placeholder="..."
            className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-center font-mono text-xl font-bold uppercase text-slate-900 dark:text-white focus:border-rose-500 focus:outline-none"
          />
          <button
            type="button"
            disabled={!input.trim() || feedback !== null}
            onClick={handleSubmit}
            className="rounded-xl bg-rose-600 px-6 py-3 text-base font-semibold text-white hover:bg-rose-700 disabled:opacity-40 cursor-pointer"
          >
            {ui.submit}
          </button>
        </div>
      </div>
    </GameShell>
  );
}
