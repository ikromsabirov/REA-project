import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

interface AnagramItem {
  word: string;
  clue: string;
}

const ANAGRAM_BANK: Record<Language, AnagramItem[]> = {
  uz: [
    { word: toNewUzbekAlphabet('MANTIQ'), clue: toNewUzbekAlphabet("To'g'ri fikrlash ilmi") },
    { word: toNewUzbekAlphabet('KITOB'), clue: toNewUzbekAlphabet('Bilim manbai') },
    { word: toNewUzbekAlphabet('XOTIRA'), clue: toNewUzbekAlphabet("Ma'lumotni saqlash qobiliyati") },
    { word: toNewUzbekAlphabet('SHAKL'), clue: toNewUzbekAlphabet('Geometrik tasvir') },
    { word: toNewUzbekAlphabet('ZAKOVAT'), clue: toNewUzbekAlphabet('Oliy aql va topqirlik') },
    { word: toNewUzbekAlphabet('OLIM'), clue: toNewUzbekAlphabet('Ilm bilan shug‘ullanuvchi inson') },
  ],
  ru: [
    { word: 'ЛОГИКА', clue: 'Наука о правильном мышлении' },
    { word: 'ПАМЯТЬ', clue: 'Способность сохранять информацию' },
    { word: 'ЧИСЛО', clue: 'Основное понятие математики' },
    { word: 'АНАЛИЗ', clue: 'Разбор целого на составные части' },
    { word: 'СИНТЕЗ', clue: 'Объединение элементов в единое целое' },
    { word: 'ТЕОРЕМА', clue: 'Утверждение, требующее доказательства' },
  ],
  en: [
    { word: 'LOGIC', clue: 'Reasoning conducted according to strict principles' },
    { word: 'MEMORY', clue: 'Faculty by which the mind stores information' },
    { word: 'MATRIX', clue: 'Rectangular array of numbers or symbols' },
    { word: 'PUZZLE', clue: 'Game or problem designed to test ingenuity' },
    { word: 'PATTERN', clue: 'Repeated decorative or logical arrangement' },
    { word: 'INSIGHT', clue: 'Deep accurate understanding of a problem' },
  ],
};

interface AnagramStage extends AnagramItem {
  scrambled: string[];
}

function generateAnagramStages(
  count: number,
  difficulty: Difficulty,
  lang: Language,
  seed: number
): AnagramStage[] {
  const rng = createSeededRng(seed);
  const bank = [...(ANAGRAM_BANK[lang] || ANAGRAM_BANK.en)].sort((a, b) =>
    difficulty === 'easy' ? a.word.length - b.word.length : b.word.length - a.word.length
  );

  return Array.from({ length: count }, (_, i) => {
    const item = bank[i % bank.length];
    const upper = item.word.toUpperCase();
    const chars = Array.from(upper);
    let scrambled = [...chars].sort(() => rng() - 0.5);
    if (scrambled.join('') === upper && chars.length > 1) {
      scrambled = [...chars.slice(1), chars[0]];
    }
    return { ...item, word: upper, scrambled };
  });
}

export function AnagramGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [pickedIndices, setPickedIndices] = useState<number[]>([]);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () =>
      generateAnagramStages(
        settings.stagesCount,
        settings.difficulty,
        settings.language,
        settings.seed || Date.now()
      ),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    setPickedIndices([]);
  }, [stageIdx]);

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      handleVerify();
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const assembled = current ? pickedIndices.map((idx) => current.scrambled[idx]).join('') : '';

  const handleUseHint = () => {
    if (hintsLeft <= 0 || !current || feedback) return;
    const targetChars = Array.from(current.word);
    const nextPos = pickedIndices.length;
    if (nextPos >= targetChars.length) return;
    const neededChar = targetChars[nextPos];
    const availIdx = current.scrambled.findIndex(
      (ch, idx) => ch === neededChar && !pickedIndices.includes(idx)
    );
    if (availIdx < 0) return;
    setPickedIndices((prev) => [...prev, availIdx]);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleVerify = () => {
    if (!current || feedback) return;
    const isCorrect = assembled === current.word;
    const timeTakenMs = Math.max(300, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: `${current.word} — ${current.clue}`,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : `${ui.wrong} (${current.word})`}`,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'anagram',
          category: 'words',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1200);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setPickedIndices([]);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-6 text-center max-w-lg mx-auto">
        <p className="text-base font-medium text-slate-600 dark:text-slate-300">{current.clue}</p>

        {/* Assembled Answer Slots */}
        <div className="flex flex-wrap justify-center gap-2 min-h-[56px]">
          {Array.from(current.word).map((_, pos) => {
            const tileIdx = pickedIndices[pos];
            const ch = tileIdx !== undefined ? current.scrambled[tileIdx] : '';
            return (
              <button
                key={pos}
                type="button"
                disabled={tileIdx === undefined || feedback !== null}
                onClick={() => setPickedIndices((prev) => prev.filter((_, i) => i !== pos))}
                className={`h-13 w-12 rounded-xl border-2 font-mono text-2xl font-extrabold cursor-pointer ${
                  ch
                    ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300'
                    : 'border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-400'
                }`}
              >
                {ch}
              </button>
            );
          })}
        </div>

        {/* Scrambled Letter Tiles */}
        <div className="flex flex-wrap justify-center gap-2.5">
          {current.scrambled.map((ch, idx) => {
            const used = pickedIndices.includes(idx);
            return (
              <button
                key={idx}
                type="button"
                disabled={used || feedback !== null}
                onClick={() => setPickedIndices((prev) => [...prev, idx])}
                className={`h-12 w-12 rounded-xl border font-mono text-xl font-bold transition-all cursor-pointer ${
                  used
                    ? 'opacity-20 border-slate-200 dark:border-slate-800'
                    : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white hover:border-rose-500'
                }`}
              >
                {ch}
              </button>
            );
          })}
        </div>

        <div className="flex justify-center gap-3">
          <button
            type="button"
            disabled={pickedIndices.length === 0 || feedback !== null}
            onClick={() => setPickedIndices([])}
            className="rounded-xl border border-slate-200 dark:border-slate-700 px-5 py-2.5 text-base font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
          >
            {ui.clear}
          </button>
          <button
            type="button"
            disabled={pickedIndices.length < Array.from(current.word).length || feedback !== null}
            onClick={handleVerify}
            className="rounded-xl bg-rose-600 px-8 py-2.5 text-base font-semibold text-white hover:bg-rose-700 disabled:opacity-40 cursor-pointer"
          >
            {ui.check}
          </button>
        </div>
      </div>
    </GameShell>
  );
}
