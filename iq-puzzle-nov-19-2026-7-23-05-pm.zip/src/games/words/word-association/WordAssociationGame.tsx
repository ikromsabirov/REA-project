import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Language } from '../../../types';

interface AssociationItem {
  prompt: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const ASSOCIATION_BANK: Record<Language, AssociationItem[]> = {
  uz: [
    {
      prompt: toNewUzbekAlphabet("Qaysi so'z qolganlaridan mantiqan ortiqcha?"),
      options: [
        toNewUzbekAlphabet('Uchburchak'),
        toNewUzbekAlphabet('Kvadrat'),
        toNewUzbekAlphabet('Doira'),
        toNewUzbekAlphabet('Metr'),
      ],
      correctIndex: 3,
      explanation: toNewUzbekAlphabet("Qolgan uchtasi geometrik shakl, 'Metr' esa uzunlik o'lchov birligi."),
    },
    {
      prompt: toNewUzbekAlphabet("Kitob : Sahifa :: Daraxt : ?"),
      options: [
        toNewUzbekAlphabet('Barg'),
        toNewUzbekAlphabet('Temir'),
        toNewUzbekAlphabet('Bulut'),
        toNewUzbekAlphabet('Soat'),
      ],
      correctIndex: 0,
      explanation: toNewUzbekAlphabet("Sahifa kitobning qismi bo'lganidek, barg ham daraxtning qismidir."),
    },
    {
      prompt: toNewUzbekAlphabet("Qaysi so'z 'Sayyoralar' guruhiga kirmaydi?"),
      options: [
        toNewUzbekAlphabet('Mars'),
        toNewUzbekAlphabet('Yupiter'),
        toNewUzbekAlphabet('Oy'),
        toNewUzbekAlphabet('Venera'),
      ],
      correctIndex: 2,
      explanation: toNewUzbekAlphabet("Oy — Yerning tabiiy yo'ldoshi, qolganlari esa sayyoralardir."),
    },
    {
      prompt: toNewUzbekAlphabet("Qalam : Chizish :: Mikroskop : ?"),
      options: [
        toNewUzbekAlphabet('Kuzatish'),
        toNewUzbekAlphabet('Chopish'),
        toNewUzbekAlphabet('Yugurish'),
        toNewUzbekAlphabet('Pishirish'),
      ],
      correctIndex: 0,
      explanation: toNewUzbekAlphabet('Qalam chizish asbobi, mikroskop esa kichik jismlarni kuzatish asbobidir.'),
    },
    {
      prompt: toNewUzbekAlphabet("Qaysi juftlik ma'nodosh (sinonim) hisoblanadi?"),
      options: [
        toNewUzbekAlphabet('Tez — Sekin'),
        toNewUzbekAlphabet('Donishmand — Aqlli'),
        toNewUzbekAlphabet('Issiq — Sovuq'),
        toNewUzbekAlphabet('Katta — Kichik'),
      ],
      correctIndex: 1,
      explanation: toNewUzbekAlphabet("Donishmand va aqlli so'zlari yaqin ma'noga ega, qolganlari antonim."),
    },
  ],
  ru: [
    {
      prompt: 'Какое слово логически лишнее в этом ряду?',
      options: ['Треугольник', 'Квадрат', 'Круг', 'Килограмм'],
      correctIndex: 3,
      explanation: 'Первые три — геометрические фигуры, а килограмм — единица массы.',
    },
    {
      prompt: 'Книга : Страница :: Дерево : ?',
      options: ['Лист', 'Металл', 'Облако', 'Секунда'],
      correctIndex: 0,
      explanation: 'Страница — часть книги, а лист — часть дерева.',
    },
    {
      prompt: 'Какой объект НЕ относится к планетам?',
      options: ['Марс', 'Юпитер', 'Луна', 'Венера'],
      correctIndex: 2,
      explanation: 'Луна — спутник Земли, а остальные — планеты Солнечной системы.',
    },
    {
      prompt: 'Компас : Ориентирование :: Термометр : ?',
      options: ['Температура', 'Давление', 'Скорость', 'Высота'],
      correctIndex: 0,
      explanation: 'Компас используют для ориентирования, термометр — для измерения температуры.',
    },
    {
      prompt: 'Какая пара слов является синонимами?',
      options: ['Смелый — Трусливый', 'Мудрый — Разумный', 'День — Ночь', 'Быстрый — Медленный'],
      correctIndex: 1,
      explanation: '«Мудрый» и «разумный» близки по смыслу, остальные пары — антонимы.',
    },
  ],
  en: [
    {
      prompt: 'Which word is the logical odd one out?',
      options: ['Triangle', 'Square', 'Circle', 'Kilogram'],
      correctIndex: 3,
      explanation: 'The first three are geometric shapes, whereas kilogram is a unit of mass.',
    },
    {
      prompt: 'Book : Page :: Tree : ?',
      options: ['Leaf', 'Iron', 'Cloud', 'Clock'],
      correctIndex: 0,
      explanation: 'A page is a component of a book, just as a leaf is part of a tree.',
    },
    {
      prompt: 'Which body does NOT belong to the Planets group?',
      options: ['Mars', 'Jupiter', 'Moon', 'Venus'],
      correctIndex: 2,
      explanation: 'The Moon is a natural satellite of Earth, while the others are planets.',
    },
    {
      prompt: 'Compass : Navigation :: Microscope : ?',
      options: ['Magnification', 'Cooking', 'Sailing', 'Weightlifting'],
      correctIndex: 0,
      explanation: 'A compass aids navigation, while a microscope provides magnification.',
    },
    {
      prompt: 'Which pair of words are synonyms?',
      options: ['Fast — Slow', 'Wise — Clever', 'Hot — Cold', 'High — Low'],
      correctIndex: 1,
      explanation: 'Wise and clever share a similar meaning; all other pairs are antonyms.',
    },
  ],
};

export function WordAssociationGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [eliminatedOpts, setEliminatedOpts] = useState<number[]>([]);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(() => {
    const rng = createSeededRng(settings.seed || Date.now());
    const bank = [...(ASSOCIATION_BANK[settings.language] || ASSOCIATION_BANK.en)].sort(() => rng() - 0.5);
    return Array.from({ length: settings.stagesCount }, (_, i) => bank[i % bank.length]);
  }, [settings]);

  const current = stages[stageIdx];

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || selectedOpt !== null) return;
    if (timeLeft <= 0) {
      handleChoose(-1);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, selectedOpt]);

  const handleUseHint = () => {
    if (hintsLeft <= 0 || selectedOpt !== null || !current) return;
    const wrong = [0, 1, 2, 3].filter((i) => i !== current.correctIndex && !eliminatedOpts.includes(i));
    if (wrong.length === 0) return;
    setEliminatedOpts((prev) => [...prev, wrong[0]]);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleChoose = (optIdx: number) => {
    if (selectedOpt !== null || !current) return;
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const isCorrect = optIdx === current.correctIndex;
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    setSelectedOpt(optIdx);
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: current.explanation,
    };

    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} ${
        settings.showExplanation ? `— ${current.explanation}` : ''
      }`,
    });

    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'word-association',
          category: 'words',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setSelectedOpt(null);
        setFeedback(null);
        setEliminatedOpts([]);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1400);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setSelectedOpt(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setEliminatedOpts([]);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-6 max-w-xl mx-auto">
        <h3 className="text-center font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          {current.prompt}
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {current.options.map((opt, idx) => {
            const isElim = eliminatedOpts.includes(idx);
            const isSelected = selectedOpt === idx;
            const isCorrect = selectedOpt !== null && idx === current.correctIndex;
            const isWrong = isSelected && idx !== current.correctIndex;

            return (
              <button
                key={idx}
                type="button"
                disabled={selectedOpt !== null || isElim}
                onClick={() => handleChoose(idx)}
                className={`rounded-xl border px-5 py-4 text-base sm:text-lg font-bold transition-all cursor-pointer disabled:cursor-default ${
                  isElim
                    ? 'opacity-20 border-slate-200 dark:border-slate-800'
                    : isCorrect
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                      : isWrong
                        ? 'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-200'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white hover:border-rose-500'
                }`}
              >
                {opt}
              </button>
            );
          })}
        </div>
      </div>
    </GameShell>
  );
}
