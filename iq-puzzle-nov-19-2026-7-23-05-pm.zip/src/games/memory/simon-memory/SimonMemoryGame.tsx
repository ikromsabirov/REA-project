import { useEffect, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
  playTone,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';

const PADS = [
  { id: 0, freq: 329.63, base: 'bg-indigo-600', glow: 'bg-indigo-400 ring-4 ring-indigo-300' },
  { id: 1, freq: 440.0, base: 'bg-emerald-600', glow: 'bg-emerald-400 ring-4 ring-emerald-300' },
  { id: 2, freq: 554.37, base: 'bg-amber-500', glow: 'bg-amber-300 ring-4 ring-amber-200' },
  { id: 3, freq: 659.25, base: 'bg-rose-600', glow: 'bg-rose-400 ring-4 ring-rose-300' },
];

export function SimonMemoryGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [sequence, setSequence] = useState<number[]>([]);
  const [userStep, setUserStep] = useState(0);
  const [activePad, setActivePad] = useState<number | null>(null);
  const [isShowing, setIsShowing] = useState(true);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const baseLength = settings.difficulty === 'easy' ? 3 : settings.difficulty === 'medium' ? 4 : 5;

  const generateSeq = (idx: number) => {
    const rng = createSeededRng((settings.seed || Date.now()) + idx * 31);
    const len = baseLength + idx;
    return Array.from({ length: len }, () => Math.floor(rng() * 4));
  };

  const playSequence = async (seq: number[]) => {
    setIsShowing(true);
    for (let i = 0; i < seq.length; i++) {
      await new Promise((r) => setTimeout(r, 260));
      const padId = seq[i];
      setActivePad(padId);
      playTone(PADS[padId].freq, 280, 'sine', soundEnabled);
      await new Promise((r) => setTimeout(r, 360));
      setActivePad(null);
    }
    setIsShowing(false);
    setStageStartedAt(Date.now());
  };

  useEffect(() => {
    const seq = generateSeq(0);
    setSequence(seq);
    playSequence(seq);
  }, []);

  const handlePadPress = (padId: number) => {
    if (isShowing || feedback || finalResult) return;
    setActivePad(padId);
    playTone(PADS[padId].freq, 180, 'sine', soundEnabled);
    setTimeout(() => setActivePad(null), 180);

    if (padId !== sequence[userStep]) {
      finishStage(false);
      return;
    }

    if (userStep + 1 === sequence.length) {
      finishStage(true);
    } else {
      setUserStep((s) => s + 1);
    }
  };

  const finishStage = (isCorrect: boolean) => {
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };
    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const next = [...outcomes, outcome];
    setOutcomes(next);

    setTimeout(() => {
      if (stageIdx + 1 >= settings.stagesCount) {
        const summary = buildResultSummary({
          gameType: 'simon-memory',
          category: 'memory',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: next,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        const nextIdx = stageIdx + 1;
        const nextSeq = generateSeq(nextIdx);
        setStageIdx(nextIdx);
        setSequence(nextSeq);
        setUserStep(0);
        setFeedback(null);
        setHintsUsedStage(0);
        playSequence(nextSeq);
      }
    }, 1200);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          const seq = generateSeq(0);
          setStageIdx(0);
          setOutcomes([]);
          setSequence(seq);
          setUserStep(0);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setFinalResult(null);
          playSequence(seq);
        }}
        onExit={onExit}
      />
    );
  }

  const statusPrompt = isShowing
    ? ui.memorize
    : settings.language === 'ru'
      ? `Повторите (${userStep}/${sequence.length})`
      : settings.language === 'en'
        ? `Repeat (${userStep}/${sequence.length})`
        : toNewUzbekAlphabet(`Takrorlang (${userStep}/${sequence.length})`);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={settings.stagesCount}
      score={outcomes.reduce((a, b) => a + b.pointsAwarded, 0)}
      hintsRemaining={hintsLeft}
      onUseHint={() => {
        if (hintsLeft <= 0 || isShowing || feedback) return;
        setHintsLeft((h) => h - 1);
        setHintsUsedStage((u) => u + 1);
        playSequence(sequence);
      }}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-6 text-center">
        <p className="font-display text-xl font-bold text-slate-900 dark:text-white">
          {statusPrompt}
        </p>

        <div className="mx-auto grid max-w-md grid-cols-2 gap-4">
          {PADS.map((pad) => (
            <button
              key={pad.id}
              type="button"
              disabled={isShowing || Boolean(feedback)}
              onClick={() => handlePadPress(pad.id)}
              className={`h-40 sm:h-48 rounded-2xl transition-all cursor-pointer ${
                activePad === pad.id ? `${pad.glow} scale-95` : `${pad.base} opacity-85 hover:opacity-100`
              }`}
            />
          ))}
        </div>
      </div>
    </GameShell>
  );
}
