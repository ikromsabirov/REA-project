import React, { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';

export function NumberMemoryGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [phase, setPhase] = useState<'show' | 'input'>('show');
  const [showSec, setShowSec] = useState(3);
  const [typed, setTyped] = useState('');
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const startLen = settings.difficulty === 'easy' ? 4 : settings.difficulty === 'medium' ? 5 : 6;
  const targets = useMemo(() => {
    const rng = createSeededRng(settings.seed || Date.now());
    return Array.from({ length: settings.stagesCount }, (_, idx) => {
      const len = startLen + idx;
      let str = '';
      for (let k = 0; k < len; k++) {
        str += String(Math.floor(rng() * 10));
      }
      return str;
    });
  }, [settings.stagesCount, settings.seed, startLen]);

  const currentTarget = targets[stageIdx] || '';

  useEffect(() => {
    if (phase !== 'show' || finalResult) return;
    if (showSec <= 0) {
      setPhase('input');
      setStageStartedAt(Date.now());
      return;
    }
    const timer = setTimeout(() => setShowSec((s) => s - 1), 1000);
    return () => clearTimeout(timer);
  }, [phase, showSec, finalResult]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (feedback || !typed.trim()) return;
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const isCorrect = typed.trim() === currentTarget;
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
    });

    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: 0,
    };
    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} (${currentTarget})`,
    });
    onStageComplete?.(outcome);
    const next = [...outcomes, outcome];
    setOutcomes(next);

    setTimeout(() => {
      if (stageIdx + 1 >= targets.length) {
        const summary = buildResultSummary({
          gameType: 'number-memory',
          category: 'memory',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: next,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setTyped('');
        setPhase('show');
        setShowSec(3);
        setFeedback(null);
      }
    }, 1300);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setTyped('');
          setPhase('show');
          setShowSec(3);
          setFeedback(null);
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={targets.length}
      score={outcomes.reduce((a, b) => a + b.pointsAwarded, 0)}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      {phase === 'show' ? (
        <div className="py-10 text-center space-y-4">
          <p className="text-base font-semibold text-slate-600 dark:text-slate-300">
            {ui.memorize} ({showSec}s)
          </p>
          <div className="font-mono text-4xl sm:text-6xl font-extrabold tracking-[0.2em] text-indigo-600 dark:text-indigo-400">
            {currentTarget}
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="max-w-md mx-auto py-4 space-y-5 text-center">
          <p className="text-base font-semibold text-slate-700 dark:text-slate-200">{ui.recall}</p>
          <input
            type="text"
            inputMode="numeric"
            autoFocus
            value={typed}
            onChange={(e) => setTyped(e.target.value.replace(/[^0-9]/g, ''))}
            className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3.5 text-center font-mono text-3xl font-bold tracking-[0.2em] text-slate-900 dark:text-white"
          />
          <button
            type="submit"
            disabled={!typed.trim() || Boolean(feedback)}
            className="w-full rounded-xl bg-indigo-600 px-6 py-3.5 text-base font-semibold text-white hover:bg-indigo-700 disabled:opacity-40 cursor-pointer"
          >
            {ui.submit}
          </button>
        </form>
      )}
    </GameShell>
  );
}
