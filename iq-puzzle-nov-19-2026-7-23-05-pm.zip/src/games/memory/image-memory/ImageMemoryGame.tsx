import { useEffect, useMemo, useState } from 'react';
import { ShapeSvg, type GeoShapeSpec, type GeoShapeType } from '../../shared/ShapeSvg';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty, Language } from '../../../types';

const SHAPES: GeoShapeType[] = ['circle', 'triangle', 'square', 'diamond', 'pentagon', 'hexagon', 'star', 'cross'];
const COLORS = ['#4f46e5', '#0284c7', '#059669', '#d97706', '#e11d48'];

interface SceneStage {
  items: GeoShapeSpec[];
  questionText: string;
  options: GeoShapeSpec[];
  correctIndex: number;
}

function specSignature(s: GeoShapeSpec): string {
  return `${s.shape}|${s.color}`;
}

function generateSceneStages(
  count: number,
  difficulty: Difficulty,
  lang: Language,
  seed: number
): SceneStage[] {
  const rng = createSeededRng(seed);
  const itemTotal = difficulty === 'easy' ? 6 : difficulty === 'medium' ? 9 : 12;

  const pool: GeoShapeSpec[] = [];
  SHAPES.forEach((shape) => {
    COLORS.forEach((color) => {
      pool.push({ shape, color, fill: 'solid' });
    });
  });

  const stages: SceneStage[] = [];
  for (let i = 0; i < count; i++) {
    const shuffled = [...pool].sort(() => rng() - 0.5);
    const items = shuffled.slice(0, itemTotal);
    const absent = shuffled.slice(itemTotal, itemTotal + 4);

    const qType = i % 3;
    if (qType === 0) {
      // Which item WAS present?
      const target = items[Math.floor(rng() * items.length)];
      const opts = [target, absent[0], absent[1], absent[2]].sort(() => rng() - 0.5);
      stages.push({
        items,
        questionText:
          lang === 'ru'
            ? 'Какая из этих фигур БЫЛА на экране?'
            : lang === 'en'
              ? 'Which of these figures WAS shown in the scene?'
              : toNewUzbekAlphabet('Quyidagi shakllardan qaysi biri ekranda BOR edi?'),
        options: opts,
        correctIndex: opts.findIndex((o) => specSignature(o) === specSignature(target)),
      });
    } else if (qType === 1) {
      // Which item was NOT present?
      const target = absent[0];
      const shown3 = [...items].sort(() => rng() - 0.5).slice(0, 3);
      const opts = [target, ...shown3].sort(() => rng() - 0.5);
      stages.push({
        items,
        questionText:
          lang === 'ru'
            ? 'Какой фигуры НЕ БЫЛО на экране?'
            : lang === 'en'
              ? 'Which figure was NOT present in the scene?'
              : toNewUzbekAlphabet("Qaysi shakl ekranda YO'Q edi?"),
        options: opts,
        correctIndex: opts.findIndex((o) => specSignature(o) === specSignature(target)),
      });
    } else {
      // Which item was at position #pos?
      const pos = Math.floor(rng() * items.length);
      const target = items[pos];
      const others = items.filter((_, idx) => idx !== pos).slice(0, 3);
      const opts = [target, ...others].sort(() => rng() - 0.5);
      stages.push({
        items,
        questionText:
          lang === 'ru'
            ? `Какая фигура находилась на позиции №${pos + 1}?`
            : lang === 'en'
              ? `Which figure was located at position #${pos + 1}?`
              : toNewUzbekAlphabet(`#${pos + 1}-o'rinda qaysi shakl joylashgan edi?`),
        options: opts,
        correctIndex: opts.findIndex((o) => specSignature(o) === specSignature(target)),
      });
    }
  }
  return stages;
}

export function ImageMemoryGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [phase, setPhase] = useState<'memorize' | 'recall'>('memorize');
  const [memSec, setMemSec] = useState(5);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () =>
      generateSceneStages(
        settings.stagesCount,
        settings.difficulty,
        settings.language,
        settings.seed || Date.now()
      ),
    [settings]
  );
  const current = stages[stageIdx];

  useEffect(() => {
    if (phase !== 'memorize' || finalResult) return;
    if (memSec <= 0) {
      setPhase('recall');
      setStageStartedAt(Date.now());
      return;
    }
    const timer = setTimeout(() => setMemSec((s) => s - 1), 1000);
    return () => clearTimeout(timer);
  }, [phase, memSec, finalResult]);

  const handleChoose = (idx: number) => {
    if (selectedOpt !== null || !current) return;
    const timeTakenMs = Math.max(250, Date.now() - stageStartedAt);
    const isCorrect = idx === current.correctIndex;
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
    });
    setSelectedOpt(idx);
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: 0,
    };
    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const next = [...outcomes, outcome];
    setOutcomes(next);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'image-memory',
          category: 'memory',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: next,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setPhase('memorize');
        setMemSec(5);
        setSelectedOpt(null);
        setFeedback(null);
      }
    }, 1300);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setPhase('memorize');
          setMemSec(5);
          setSelectedOpt(null);
          setFeedback(null);
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={outcomes.reduce((a, b) => a + b.pointsAwarded, 0)}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      {phase === 'memorize' ? (
        <div className="space-y-5 text-center">
          <div className="flex items-center justify-center gap-3">
            <span className="font-display text-xl font-bold text-slate-900 dark:text-white">
              {ui.memorize}
            </span>
            <span className="font-mono text-xl font-extrabold text-indigo-600 dark:text-indigo-400 tabular-nums">
              {memSec}s
            </span>
          </div>
          <div className="mx-auto grid max-w-3xl grid-cols-2 sm:grid-cols-4 gap-4">
            {current.items.map((item, idx) => (
              <div
                key={idx}
                className="relative flex flex-col items-center justify-center rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-5"
              >
                <span className="absolute left-2.5 top-2 font-mono text-xs font-bold text-slate-400">
                  #{idx + 1}
                </span>
                <ShapeSvg spec={item} size={98} />
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-6 text-center">
          <h3 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
            {current.questionText}
          </h3>
          <div className="mx-auto grid max-w-2xl grid-cols-2 gap-5">
            {current.options.map((opt, idx) => {
              const isCorrect = selectedOpt !== null && idx === current.correctIndex;
              const isWrong = selectedOpt === idx && idx !== current.correctIndex;
              return (
                <button
                  key={idx}
                  type="button"
                  disabled={selectedOpt !== null}
                  onClick={() => handleChoose(idx)}
                  className={`flex items-center justify-center rounded-2xl border p-6 cursor-pointer ${
                    isCorrect
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40'
                      : isWrong
                        ? 'border-red-500 bg-red-50 dark:bg-red-950/40'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:border-indigo-500'
                  }`}
                >
                  <ShapeSvg spec={opt} size={112} />
                </button>
              );
            })}
          </div>
        </div>
      )}
    </GameShell>
  );
}
