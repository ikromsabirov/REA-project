import { useEffect, useMemo, useState } from 'react';
import { ShapeSvg, type GeoShapeSpec, type GeoShapeType } from '../../shared/ShapeSvg';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty } from '../../../types';

const PAIRS_SHAPES: GeoShapeType[] = [
  'circle',
  'triangle',
  'square',
  'diamond',
  'pentagon',
  'hexagon',
  'star',
  'cross',
];
const PAIRS_COLORS = ['#4f46e5', '#0284c7', '#059669', '#d97706', '#e11d48', '#7c3aed'];

interface CardItem {
  uid: number;
  pairId: number;
  spec: GeoShapeSpec;
}

function buildDeck(pairCount: number, seed: number): CardItem[] {
  const rng = createSeededRng(seed);
  const specs: GeoShapeSpec[] = [];
  for (let i = 0; i < pairCount; i++) {
    specs.push({
      shape: PAIRS_SHAPES[i % PAIRS_SHAPES.length],
      color: PAIRS_COLORS[Math.floor(i / 2) % PAIRS_COLORS.length],
      fill: i >= 6 ? 'outline' : 'solid',
      innerDot: i >= 8,
    });
  }
  const doubled: CardItem[] = [];
  specs.forEach((spec, pairId) => {
    doubled.push({ uid: pairId * 2, pairId, spec });
    doubled.push({ uid: pairId * 2 + 1, pairId, spec });
  });
  return doubled.sort(() => rng() - 0.5);
}

function getPairCountForStage(difficulty: Difficulty, stageIdx: number): number {
  if (difficulty === 'easy') return stageIdx === 0 ? 4 : 6;
  if (difficulty === 'medium') return stageIdx === 0 ? 6 : 8;
  return stageIdx === 0 ? 8 : 12;
}

export function MemoryCardsGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [pairOverride, setPairOverride] = useState<number | null>(null);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [peekPair, setPeekPair] = useState<number[]>([]);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const pairCount = pairOverride ?? getPairCountForStage(settings.difficulty, stageIdx);
  const deck = useMemo(
    () => buildDeck(pairCount, (settings.seed || Date.now()) + stageIdx * 97),
    [pairCount, stageIdx, settings.seed]
  );

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      completeStage(false);
      return;
    }
    const t = setTimeout(() => setTimeLeft((v) => v - 1), 1000);
    return () => clearTimeout(t);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const completeStage = (isCorrect: boolean) => {
    const timeTakenMs = Math.max(500, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };
    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const next = [...outcomes, outcome];
    setOutcomes(next);

    setTimeout(() => {
      if (stageIdx + 1 >= settings.stagesCount) {
        const summary = buildResultSummary({
          gameType: 'memory-cards',
          category: 'memory',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: next,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFlipped([]);
        setMatched([]);
        setMoves(0);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1200);
  };

  const handleFlip = (index: number) => {
    if (feedback || flipped.length >= 2 || flipped.includes(index) || matched.includes(index)) return;
    const nextFlipped = [...flipped, index];
    setFlipped(nextFlipped);

    if (nextFlipped.length === 2) {
      setMoves((m) => m + 1);
      const [a, b] = nextFlipped;
      if (deck[a].pairId === deck[b].pairId) {
        playSuccessChime(soundEnabled);
        const nextMatched = [...matched, a, b];
        setMatched(nextMatched);
        setFlipped([]);
        if (nextMatched.length === deck.length) {
          completeStage(true);
        }
      } else {
        setTimeout(() => setFlipped([]), 650);
      }
    }
  };

  const handleHint = () => {
    if (hintsLeft <= 0 || feedback) return;
    const unmatchedIndices = deck.map((_, i) => i).filter((i) => !matched.includes(i));
    if (unmatchedIndices.length < 2) return;
    const first = unmatchedIndices[0];
    const partner = unmatchedIndices.find((i) => i !== first && deck[i].pairId === deck[first].pairId);
    if (partner === undefined) return;
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
    setPeekPair([first, partner]);
    setTimeout(() => setPeekPair([]), 1200);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setFlipped([]);
          setMatched([]);
          setMoves(0);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={settings.stagesCount}
      score={outcomes.reduce((a, b) => a + b.pointsAwarded, 0)}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5">
            {[4, 6, 8, 12].map((cnt) => (
              <button
                key={cnt}
                type="button"
                onClick={() => {
                  setPairOverride(cnt);
                  setFlipped([]);
                  setMatched([]);
                  setMoves(0);
                }}
                className={`rounded-lg px-3 py-1.5 font-mono text-xs font-bold cursor-pointer ${
                  pairCount === cnt
                    ? 'bg-indigo-600 text-white'
                    : 'border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {cnt}×2
              </button>
            ))}
          </div>
          <span className="font-mono text-sm font-semibold text-slate-600 dark:text-slate-300 tabular-nums">
            {matched.length / 2}/{pairCount} · {moves}
          </span>
        </div>

        <div
          className={`mx-auto grid gap-3.5 sm:gap-4 ${
            pairCount >= 12
              ? 'grid-cols-4 sm:grid-cols-6 max-w-4xl'
              : pairCount >= 8
                ? 'grid-cols-4 max-w-2xl'
                : 'grid-cols-4 max-w-2xl'
          }`}
        >
          {deck.map((card, idx) => {
            const isOpen = flipped.includes(idx) || matched.includes(idx) || peekPair.includes(idx);
            const isDone = matched.includes(idx);
            return (
              <button
                key={card.uid}
                type="button"
                onClick={() => handleFlip(idx)}
                className={`aspect-square flex items-center justify-center rounded-2xl border p-2 transition-transform duration-200 cursor-pointer ${
                  isDone
                    ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40'
                    : isOpen
                      ? 'border-indigo-500 bg-white dark:bg-slate-950'
                      : 'border-slate-300 dark:border-slate-700 bg-gradient-to-br from-indigo-600 to-sky-600 text-white hover:scale-[1.03]'
                }`}
              >
                {isOpen ? (
                  <ShapeSvg spec={card.spec} size={90} />
                ) : (
                  <span className="font-display text-3xl font-bold opacity-85">?</span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </GameShell>
  );
}
