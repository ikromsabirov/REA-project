import type { GamePlayProps } from './types';

// Category 1: Logic
import { IqMatrixGame } from './logic/iq-matrix/IqMatrixGame';
import { SequenceGame } from './logic/sequence/SequenceGame';
import { LogicGridGame } from './logic/logic-grid/LogicGridGame';
import { MatchstickGame } from './logic/matchstick/MatchstickGame';
import { OddOneOutGame } from './logic/odd-one-out/OddOneOutGame';

// Category 2: Memory
import { MemoryCardsGame } from './memory/memory-cards/MemoryCardsGame';
import { SimonMemoryGame } from './memory/simon-memory/SimonMemoryGame';
import { ImageMemoryGame } from './memory/image-memory/ImageMemoryGame';
import { NumberMemoryGame } from './memory/number-memory/NumberMemoryGame';

// Category 3: Spatial
import { Rotation3DGame } from './spatial/rotation-3d/Rotation3DGame';
import { PaperFoldingGame } from './spatial/paper-folding/PaperFoldingGame';
import { TangramGame } from './spatial/tangram/TangramGame';
import { CubeNetGame } from './spatial/cube-net/CubeNetGame';

// Category 4: Attention & Speed
import { FindDifferenceGame } from './attention/find-difference/FindDifferenceGame';
import { StroopGame } from './attention/stroop/StroopGame';
import { HiddenObjectsGame } from './attention/hidden-objects/HiddenObjectsGame';
import { NumberSearchGame } from './attention/number-search/NumberSearchGame';

// Category 5: Mathematical IQ
import { SudokuGame } from './math/sudoku/SudokuGame';
import { NumberCrosswordGame } from './math/number-crossword/NumberCrosswordGame';
import { Make24Game } from './math/make-24/Make24Game';
import { NumberPyramidGame } from './math/number-pyramid/NumberPyramidGame';

// Category 6: Verbal IQ
import { WordSearchGame } from './words/word-search/WordSearchGame';
import { AnagramGame } from './words/anagram/AnagramGame';
import { RebusGame } from './words/rebus/RebusGame';
import { WordAssociationGame } from './words/word-association/WordAssociationGame';

export function GameRunner(props: GamePlayProps) {
  switch (props.settings.gameType) {
    case 'iq-matrix':
      return <IqMatrixGame {...props} />;
    case 'sequence':
      return <SequenceGame {...props} />;
    case 'logic-grid':
      return <LogicGridGame {...props} />;
    case 'matchstick':
      return <MatchstickGame {...props} />;
    case 'odd-one-out':
      return <OddOneOutGame {...props} />;
    case 'memory-cards':
      return <MemoryCardsGame {...props} />;
    case 'simon-memory':
      return <SimonMemoryGame {...props} />;
    case 'image-memory':
      return <ImageMemoryGame {...props} />;
    case 'number-memory':
      return <NumberMemoryGame {...props} />;
    case 'rotation-3d':
      return <Rotation3DGame {...props} />;
    case 'paper-folding':
      return <PaperFoldingGame {...props} />;
    case 'tangram':
      return <TangramGame {...props} />;
    case 'cube-net':
      return <CubeNetGame {...props} />;
    case 'find-difference':
      return <FindDifferenceGame {...props} />;
    case 'stroop':
      return <StroopGame {...props} />;
    case 'hidden-objects':
      return <HiddenObjectsGame {...props} />;
    case 'number-search':
      return <NumberSearchGame {...props} />;
    case 'sudoku':
      return <SudokuGame {...props} />;
    case 'number-crossword':
      return <NumberCrosswordGame {...props} />;
    case 'make-24':
      return <Make24Game {...props} />;
    case 'number-pyramid':
      return <NumberPyramidGame {...props} />;
    case 'word-search':
      return <WordSearchGame {...props} />;
    case 'anagram':
      return <AnagramGame {...props} />;
    case 'rebus':
      return <RebusGame {...props} />;
    case 'word-association':
      return <WordAssociationGame {...props} />;
  }
}
