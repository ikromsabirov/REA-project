import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty } from '../../../types';

interface PyramidStage {
  rows: number[][]; // top (len 1) down to base (len 4 or 5)
  maskedKeys: Set<string>;
}

function generatePyramidStages(count: number, difficulty: Difficulty, seed: number): PyramidStage[] {
  const rng = createSeededRng(seed);
  const baseLen = difficulty === 'hard' ? 5 : 4;
  const stages: PyramidStage[] = [];

  for (let i = 0; i < count; i++) {
    const base = Array.from({ length: baseLen }, () => 2 + Math.floor(rng() * (difficulty === 'easy' ? 9 : 16)));
    const rows: number[][] = [base];
    while (rows[0].length > 1) {
      const prev = rows[0];
      const next: number[] = [];
      for (let k = 0; k < prev.length - 1; k++) {
        next.push(prev[k] + prev[k + 1]);
      }
      rows.unshift(next);
    }

    // Mask non-overlapping cells so puzzle stays uniquely solvable
    const maskedKeys = new Set<string>();
    const allCoords: string[] = [];
    rows.forEach((row, r) => row.forEach((_, c) => allCoords.push(`${r}-${c}`)));
    const maskCount = difficulty === 'easy' ? 4 : difficulty === 'medium' ? 5 : 7;
    // Always keep base mostly visible or mix rows cleanly
    const candidates = allCoords.filter((k) => !k.startsWith(`${rows.length - 1}-`) || rng() > 0.65);
    candidates.sort(() => rng() - 0.5).slice(0, maskCount).forEach((k) => maskedKeys.add(k));
    if (maskedKeys.size === 0) maskedKeys.add('0-0');

    stages.push({ rows, maskedKeys });
  }
  return stages;
}

export function NumberPyramidGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () => generatePyramidStages(settings.stagesCount, settings.difficulty, settings.seed || Date.now()),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    setInputs({});
  }, [stageIdx]);

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      handleVerify();
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const handleUseHint = () => {
    if (hintsLeft <= 0 || !current || feedback) return;
    const keys = Array.from(current.maskedKeys);
    const missingKey = keys.find((k) => {
      const [r, c] = k.split('-').map(Number);
      return Number(inputs[k]) !== current.rows[r][c];
    });
    if (!missingKey) return;
    const [r, c] = missingKey.split('-').map(Number);
    setInputs((prev) => ({ ...prev, [missingKey]: String(current.rows[r][c]) }));
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleVerify = () => {
    if (!current || feedback) return;
    const keys = Array.from(current.maskedKeys);
    const isCorrect = keys.every((k) => {
      const [r, c] = k.split('-').map(Number);
      return Number(inputs[k]) === current.rows[r][c];
    });

    const timeTakenMs = Math.max(400, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };

    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'number-pyramid',
          category: 'math',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1200);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setInputs({});
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  const prompt =
    settings.language === 'ru'
      ? 'Каждый блок равен сумме двух блоков под ним. Восстановите пропущенные числа:'
      : settings.language === 'en'
        ? 'Each block equals the sum of the two blocks beneath it. Fill in the missing cells:'
        : toNewUzbekAlphabet(
            "Har bir blok ostidagi ikki blok yig'indisiga teng. Bo'sh kataklarni to'ldiring:"
          );

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-6 text-center">
        <p className="text-base font-medium text-slate-700 dark:text-slate-200">{prompt}</p>

        <div className="space-y-2.5">
          {current.rows.map((row, r) => (
            <div key={r} className="flex justify-center gap-2 sm:gap-2.5">
              {row.map((val, c) => {
                const key = `${r}-${c}`;
                const masked = current.maskedKeys.has(key);
                if (!masked) {
                  return (
                    <div
                      key={key}
                      className="flex h-12 w-14 sm:h-14 sm:w-16 items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 font-mono text-lg sm:text-xl font-bold text-slate-900 dark:text-white"
                    >
                      {val}
                    </div>
                  );
                }
                return (
                  <input
                    key={key}
                    type="number"
                    value={inputs[key] ?? ''}
                    disabled={feedback !== null}
                    onChange={(e) => setInputs((prev) => ({ ...prev, [key]: e.target.value }))}
                    className="h-12 w-14 sm:h-14 sm:w-16 rounded-xl border-2 border-violet-500 bg-white dark:bg-slate-950 text-center font-mono text-lg sm:text-xl font-bold text-violet-700 dark:text-violet-300 focus:outline-none"
                  />
                );
              })}
            </div>
          ))}
        </div>

        <button
          type="button"
          disabled={feedback !== null}
          onClick={handleVerify}
          className="rounded-xl bg-violet-600 px-8 py-3 text-base font-semibold text-white hover:bg-violet-700 disabled:opacity-40 cursor-pointer"
        >
          {ui.check}
        </button>
      </div>
    </GameShell>
  );
}
