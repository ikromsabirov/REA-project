import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty } from '../../../types';

interface SudokuStage {
  size: 4 | 6 | 9;
  boxRows: number;
  boxCols: number;
  puzzle: Array<number | null>;
  solution: number[];
}

function generateValidSudoku(
  size: 4 | 6 | 9,
  boxRows: number,
  boxCols: number,
  rng: () => number,
  holes: number
): SudokuStage {
  // Base cyclic shifted valid Sudoku solution
  const digits = Array.from({ length: size }, (_, i) => i + 1).sort(() => rng() - 0.5);
  const grid: number[] = Array(size * size).fill(0);

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const shift = (r * boxCols + Math.floor(r / boxRows) + c) % size;
      grid[r * size + c] = digits[shift];
    }
  }

  // Shuffle rows within bands & cols within stacks
  const rowBands = size / boxRows;
  for (let b = 0; b < rowBands; b++) {
    const r1 = b * boxRows + Math.floor(rng() * boxRows);
    const r2 = b * boxRows + Math.floor(rng() * boxRows);
    for (let c = 0; c < size; c++) {
      const tmp = grid[r1 * size + c];
      grid[r1 * size + c] = grid[r2 * size + c];
      grid[r2 * size + c] = tmp;
    }
  }

  const indices = Array.from({ length: size * size }, (_, i) => i).sort(() => rng() - 0.5);
  const holeSet = new Set(indices.slice(0, holes));
  const puzzle = grid.map((v, idx) => (holeSet.has(idx) ? null : v));

  return { size, boxRows, boxCols, puzzle, solution: grid };
}

function generateSudokuStages(count: number, difficulty: Difficulty, seed: number): SudokuStage[] {
  const rng = createSeededRng(seed);
  const stages: SudokuStage[] = [];
  for (let i = 0; i < count; i++) {
    if (difficulty === 'easy') {
      stages.push(generateValidSudoku(4, 2, 2, rng, 6));
    } else if (difficulty === 'medium') {
      stages.push(generateValidSudoku(6, 2, 3, rng, 15));
    } else {
      stages.push(generateValidSudoku(9, 3, 3, rng, 34));
    }
  }
  return stages;
}

export function SudokuGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () => generateSudokuStages(settings.stagesCount, settings.difficulty, settings.seed || Date.now()),
    [settings]
  );

  const current = stages[stageIdx];
  const [board, setBoard] = useState<Array<number | null>>(() => current?.puzzle ?? []);
  const [selectedCell, setSelectedCell] = useState<number | null>(null);
  const [errorsCount, setErrorsCount] = useState(0);

  useEffect(() => {
    if (current) {
      setBoard([...current.puzzle]);
      setSelectedCell(current.puzzle.findIndex((v) => v === null));
      setErrorsCount(0);
    }
  }, [stageIdx, current]);

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      finishStage(false);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const finishStage = (isCorrect: boolean) => {
    if (feedback || !current) return;
    const timeTakenMs = Math.max(500, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };

    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'sudoku',
          category: 'math',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1200);
  };

  const handlePlaceDigit = (digit: number | null) => {
    if (selectedCell === null || !current || feedback) return;
    if (current.puzzle[selectedCell] !== null) return; // locked given

    const next = [...board];
    next[selectedCell] = digit;
    setBoard(next);

    if (digit !== null && digit !== current.solution[selectedCell]) {
      playErrorTone(soundEnabled);
      setErrorsCount((e) => e + 1);
    } else if (digit !== null) {
      playSuccessChime(soundEnabled);
      if (next.every((v, idx) => v === current.solution[idx])) {
        finishStage(true);
      }
    }
  };

  const handleUseHint = () => {
    if (hintsLeft <= 0 || !current || feedback) return;
    const idx =
      selectedCell !== null && board[selectedCell] !== current.solution[selectedCell]
        ? selectedCell
        : board.findIndex((v, i) => v !== current.solution[i]);
    if (idx < 0) return;

    const next = [...board];
    next[idx] = current.solution[idx];
    setBoard(next);
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
    if (next.every((v, i) => v === current.solution[i])) {
      finishStage(true);
    }
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-4">
        <div className="flex items-center justify-center gap-4 text-sm font-mono tabular-nums text-slate-500 dark:text-slate-400">
          <span>{current.size}×{current.size}</span>
          <span>·</span>
          <span>
            {settings.language === 'ru'
              ? `Ошибки: ${errorsCount}`
              : settings.language === 'en'
                ? `Errors: ${errorsCount}`
                : toNewUzbekAlphabet(`Xatolar: ${errorsCount}`)}
          </span>
        </div>

        {/* Sudoku Grid */}
        <div
          className="mx-auto grid border-2 border-slate-700 dark:border-slate-400 rounded-xl overflow-hidden bg-white dark:bg-slate-950"
          style={{
            maxWidth: current.size === 9 ? '390px' : '320px',
            gridTemplateColumns: `repeat(${current.size}, minmax(0, 1fr))`,
          }}
        >
          {board.map((val, idx) => {
            const r = Math.floor(idx / current.size);
            const c = idx % current.size;
            const isGiven = current.puzzle[idx] !== null;
            const isSelected = selectedCell === idx;
            const isWrong = val !== null && val !== current.solution[idx];
            const rightBoxEdge = (c + 1) % current.boxCols === 0 && c < current.size - 1;
            const bottomBoxEdge = (r + 1) % current.boxRows === 0 && r < current.size - 1;

            return (
              <button
                key={idx}
                type="button"
                onClick={() => setSelectedCell(idx)}
                className={`aspect-square flex items-center justify-center border border-slate-200 dark:border-slate-800 font-mono font-bold tabular-nums cursor-pointer ${
                  current.size === 9 ? 'text-base sm:text-lg' : 'text-xl'
                } ${rightBoxEdge ? 'border-r-2 border-r-slate-600 dark:border-r-slate-400' : ''} ${
                  bottomBoxEdge ? 'border-b-2 border-b-slate-600 dark:border-b-slate-400' : ''
                } ${
                  isSelected
                    ? 'bg-violet-100 dark:bg-violet-950/60 ring-2 ring-inset ring-violet-500'
                    : isGiven
                      ? 'bg-slate-100 dark:bg-slate-900 text-slate-900 dark:text-white'
                      : 'bg-white dark:bg-slate-950 text-violet-700 dark:text-violet-300'
                } ${isWrong ? 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40' : ''}`}
              >
                {val ?? ''}
              </button>
            );
          })}
        </div>

        {/* Digit Pad */}
        <div className="flex flex-wrap justify-center gap-2">
          {Array.from({ length: current.size }, (_, i) => i + 1).map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => handlePlaceDigit(d)}
              className="h-11 w-11 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-lg font-bold text-slate-900 dark:text-white hover:border-violet-500 cursor-pointer"
            >
              {d}
            </button>
          ))}
          <button
            type="button"
            onClick={() => handlePlaceDigit(null)}
            className="h-11 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 text-sm font-semibold text-slate-600 dark:text-slate-300 cursor-pointer"
          >
            {ui.clear}
          </button>
        </div>
      </div>
    </GameShell>
  );
}
