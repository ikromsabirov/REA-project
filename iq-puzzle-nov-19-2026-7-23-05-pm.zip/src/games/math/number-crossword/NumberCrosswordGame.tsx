import { useEffect, useMemo, useState } from 'react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty } from '../../../types';

/**
 * 5x5 Intersecting Math Crossword:
 * Row 0: A + B = C
 *        +   -   +
 * Row 2: D * E = F
 *        =   =   =
 * Row 4: G + H = I
 * Where:
 * A + D = G
 * B - E = H
 * C + F = I
 */
interface CrosswordStage {
  solutions: Record<'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H' | 'I', number>;
  hiddenKeys: Array<'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H' | 'I'>;
}

function generateCrosswordStages(count: number, difficulty: Difficulty, seed: number): CrosswordStage[] {
  const rng = createSeededRng(seed);
  const stages: CrosswordStage[] = [];
  const allKeys: Array<'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H' | 'I'> = [
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
  ];

  for (let i = 0; i < count; i++) {
    const E = 2 + Math.floor(rng() * 5);
    const B = E + 2 + Math.floor(rng() * 8);
    const A = 3 + Math.floor(rng() * 10);
    const D = 2 + Math.floor(rng() * 6);
    const C = A + B;
    const F = D * E;
    const G = A + D;
    const H = B - E;
    const I = C + F; // equals G + H? Wait: A+D + B-E = A+B + D-E, whereas C+F = A+B + D*E.
    // Let's keep third column independent or ensure exact balance:
    // Use col 2: C - F = I? No: let's enforce G + H = I AND C - F = I?
    // Actually if Row 4 is G + H = I: (A+D) + (B-E) = (A+B) + (D-E) = C + (D-E).
    // If Col 2 uses C + D - E = I, let's make Row 2: D + E = F? No, if Row 2 is D + E = F and Col 2 is C + D + E? Wait:
    // Simpler algebraic identity:
    // Row 0: A + B = C
    // Row 2: D + E = F
    // Col 0: A + D = G
    // Col 1: B + E = H
    // Row 4: G + H = I  => (A+D)+(B+E) = (A+B)+(D+E) = C + F = I!
    // Exact identity holds ALWAYS: Row 4 and Col 2 both equal I!
    const Fsum = D + E;
    const Hsum = B + E;
    const Isum = C + Fsum;

    const hideCount = difficulty === 'easy' ? 3 : difficulty === 'medium' ? 5 : 6;
    const hiddenKeys = [...allKeys].sort(() => rng() - 0.5).slice(0, hideCount);

    stages.push({
      solutions: { A, B, C, D, E, F: Fsum, G, H: Hsum, I: Isum },
      hiddenKeys,
    });
  }
  return stages;
}

export function NumberCrosswordGame({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () => generateCrosswordStages(settings.stagesCount, settings.difficulty, settings.seed || Date.now()),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    setInputs({});
  }, [stageIdx]);

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      handleVerify();
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const handleUseHint = () => {
    if (hintsLeft <= 0 || !current || feedback) return;
    const missing = current.hiddenKeys.find((k) => Number(inputs[k]) !== current.solutions[k]);
    if (!missing) return;
    setInputs((prev) => ({ ...prev, [missing]: String(current.solutions[missing]) }));
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  const handleVerify = () => {
    if (!current || feedback) return;
    const isCorrect = current.hiddenKeys.every((k) => Number(inputs[k]) === current.solutions[k]);
    const timeTakenMs = Math.max(400, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });

    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
    };

    setFeedback({
      isCorrect,
      message: isCorrect ? `${ui.correct} (+${points})` : ui.wrong,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'number-crossword',
          category: 'math',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1200);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setInputs({});
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  const renderVar = (key: keyof CrosswordStage['solutions']) => {
    const isHidden = current.hiddenKeys.includes(key);
    if (!isHidden) {
      return (
        <div className="flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 font-mono text-xl font-bold text-slate-900 dark:text-white">
          {current.solutions[key]}
        </div>
      );
    }
    return (
      <input
        type="number"
        value={inputs[key] ?? ''}
        disabled={feedback !== null}
        onChange={(e) => setInputs((prev) => ({ ...prev, [key]: e.target.value }))}
        aria-label={key}
        className="h-12 w-12 sm:h-14 sm:w-14 rounded-xl border-2 border-violet-500 bg-white dark:bg-slate-950 text-center font-mono text-xl font-bold text-violet-700 dark:text-violet-300 focus:outline-none"
      />
    );
  };

  const opCell = (op: string) => (
    <div className="flex h-10 w-10 items-center justify-center font-mono text-xl font-black text-slate-500 dark:text-slate-400">
      {op}
    </div>
  );

  const prompt =
    settings.language === 'ru'
      ? 'Заполните пропущенные числа так, чтобы все строки и столбцы стали верными:'
      : settings.language === 'en'
        ? 'Fill the missing numbers so every horizontal and vertical equation balances:'
        : toNewUzbekAlphabet(
            "Gorizontal va vertikal tengliklarning barchasi to'g'ri chiqishi uchun bo'sh kataklarni to'ldiring:"
          );

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-6 text-center">
        <p className="text-base font-medium text-slate-700 dark:text-slate-200">{prompt}</p>

        <div className="inline-grid grid-cols-5 place-items-center gap-1.5 sm:gap-2 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-4">
          {renderVar('A')} {opCell('+')} {renderVar('B')} {opCell('=')} {renderVar('C')}
          {opCell('+')} <div /> {opCell('+')} <div /> {opCell('+')}
          {renderVar('D')} {opCell('+')} {renderVar('E')} {opCell('=')} {renderVar('F')}
          {opCell('=')} <div /> {opCell('=')} <div /> {opCell('=')}
          {renderVar('G')} {opCell('+')} {renderVar('H')} {opCell('=')} {renderVar('I')}
        </div>

        <div>
          <button
            type="button"
            disabled={feedback !== null}
            onClick={handleVerify}
            className="rounded-xl bg-violet-600 px-8 py-3 text-base font-semibold text-white hover:bg-violet-700 disabled:opacity-40 cursor-pointer"
          >
            {ui.check}
          </button>
        </div>
      </div>
    </GameShell>
  );
}
