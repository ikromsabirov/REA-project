import { useEffect, useMemo, useState } from 'react';
import { Delete } from 'lucide-react';
import { GameShell, GameResultView, getGameUiText } from '../../shared/GameShell';
import {
  buildResultSummary,
  calculateStagePoints,
  createSeededRng,
  evaluateSafeArithmetic,
  playErrorTone,
  playSuccessChime,
} from '../../scoring';
import { toNewUzbekAlphabet } from '../../../utils/uzbekAlphabet';
import type { GamePlayProps, GameResultSummary, StageOutcome } from '../../types';
import type { Difficulty } from '../../../types';

interface Make24Puzzle {
  numbers: [number, number, number, number];
  sampleSolution: string;
}

const EASY_SETS: Make24Puzzle[] = [
  { numbers: [1, 2, 3, 4], sampleSolution: '1 * 2 * 3 * 4' },
  { numbers: [2, 3, 4, 6], sampleSolution: '4 * 6 * (3 - 2)' },
  { numbers: [3, 4, 5, 6], sampleSolution: '6 * (5 - 4 + 3)' },
  { numbers: [2, 4, 8, 10], sampleSolution: '10 + 8 + 4 + 2' },
  { numbers: [1, 5, 5, 5], sampleSolution: '5 * 5 - 1' },
];

const MEDIUM_SETS: Make24Puzzle[] = [
  { numbers: [3, 3, 8, 8], sampleSolution: '8 / (3 - 8 / 3)' },
  { numbers: [4, 4, 7, 7], sampleSolution: '(4 - 4 / 7) * 7' },
  { numbers: [2, 5, 5, 10], sampleSolution: '(5 - 2 / 10) * 5' },
  { numbers: [1, 3, 4, 6], sampleSolution: '6 / (1 - 3 / 4)' },
  { numbers: [5, 6, 7, 8], sampleSolution: '(5 + 7) * (8 - 6)' },
];

const HARD_SETS: Make24Puzzle[] = [
  { numbers: [1, 5, 5, 5], sampleSolution: '(5 - 1 / 5) * 5' },
  { numbers: [3, 3, 7, 7], sampleSolution: '(3 + 3 / 7) * 7' },
  { numbers: [1, 4, 5, 6], sampleSolution: '4 / (1 - 5 / 6)' },
  { numbers: [2, 7, 7, 10], sampleSolution: '(7 + 10) + 7' },
  { numbers: [6, 9, 9, 10], sampleSolution: '(10 - 6) * 9 - 12' },
];

const VALIDATED_POOL: Make24Puzzle[] = [
  { numbers: [2, 3, 4, 6], sampleSolution: '4 * 6 * (3 - 2)' },
  { numbers: [5, 6, 7, 8], sampleSolution: '(5 + 7) * (8 - 6)' },
  { numbers: [1, 2, 3, 4], sampleSolution: '1 * 2 * 3 * 4' },
  { numbers: [2, 4, 8, 10], sampleSolution: '10 + 8 + 4 + 2' },
  { numbers: [1, 3, 4, 6], sampleSolution: '6 / (1 - 3 / 4)' },
  { numbers: [3, 3, 8, 8], sampleSolution: '8 / (3 - 8 / 3)' },
  { numbers: [4, 4, 7, 7], sampleSolution: '(4 - 4 / 7) * 7' },
  { numbers: [3, 3, 7, 7], sampleSolution: '(3 + 3 / 7) * 7' },
  { numbers: [1, 4, 5, 6], sampleSolution: '4 / (1 - 5 / 6)' },
  { numbers: [1, 5, 5, 5], sampleSolution: '(5 - 1 / 5) * 5' },
];

function generateMake24Stages(count: number, difficulty: Difficulty, seed: number): Make24Puzzle[] {
  const rng = createSeededRng(seed);
  const src =
    difficulty === 'easy'
      ? EASY_SETS
      : difficulty === 'medium'
        ? MEDIUM_SETS
        : VALIDATED_POOL.slice(4);
  const pool = [...src].sort(() => rng() - 0.5);
  return Array.from({ length: count }, (_, i) => pool[i % pool.length]);
}

function sameMultiset(a: number[], b: number[]): boolean {
  if (a.length !== b.length) return false;
  const sa = [...a].sort((x, y) => x - y);
  const sb = [...b].sort((x, y) => x - y);
  return sa.every((v, idx) => v === sb[idx]);
}

export function Make24Game({ settings, onStageComplete, onGameComplete, onExit }: GamePlayProps) {
  const ui = getGameUiText(settings.language);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [stageIdx, setStageIdx] = useState(0);
  const [outcomes, setOutcomes] = useState<StageOutcome[]>([]);
  const [hintsLeft, setHintsLeft] = useState(settings.hintsLimit);
  const [hintsUsedStage, setHintsUsedStage] = useState(0);
  const [expr, setExpr] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [timeLeft, setTimeLeft] = useState(settings.timePerTaskSec);
  const [stageStartedAt, setStageStartedAt] = useState(Date.now());
  const [finalResult, setFinalResult] = useState<GameResultSummary | null>(null);

  const stages = useMemo(
    () => generateMake24Stages(settings.stagesCount, settings.difficulty, settings.seed || Date.now()),
    [settings]
  );

  const current = stages[stageIdx];

  useEffect(() => {
    setExpr('');
    setErrorMsg(null);
  }, [stageIdx]);

  useEffect(() => {
    if (!settings.timerEnabled || finalResult || feedback) return;
    if (timeLeft <= 0) {
      finishStage(false);
      return;
    }
    const timer = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, settings.timerEnabled, finalResult, feedback]);

  const finishStage = (isCorrect: boolean) => {
    if (!current || feedback) return;
    const timeTakenMs = Math.max(400, Date.now() - stageStartedAt);
    const points = calculateStagePoints({
      isCorrect,
      timeTakenMs,
      timeLimitSec: settings.timePerTaskSec,
      hintsUsed: hintsUsedStage,
    });
    if (isCorrect) playSuccessChime(soundEnabled);
    else playErrorTone(soundEnabled);

    const outcome: StageOutcome = {
      stageIndex: stageIdx,
      isCorrect,
      pointsAwarded: points,
      timeTakenMs,
      hintsUsed: hintsUsedStage,
      explanation: `${current.sampleSolution} = 24`,
    };
    setFeedback({
      isCorrect,
      message: `${isCorrect ? `${ui.correct} (+${points})` : ui.wrong} · ${current.sampleSolution} = 24`,
    });
    onStageComplete?.(outcome);
    const nextOutcomes = [...outcomes, outcome];
    setOutcomes(nextOutcomes);

    setTimeout(() => {
      if (stageIdx + 1 >= stages.length) {
        const summary = buildResultSummary({
          gameType: 'make-24',
          category: 'math',
          difficulty: settings.difficulty,
          language: settings.language,
          stages: nextOutcomes,
        });
        setFinalResult(summary);
        onGameComplete(summary);
      } else {
        setStageIdx((s) => s + 1);
        setFeedback(null);
        setHintsUsedStage(0);
        setTimeLeft(settings.timePerTaskSec);
        setStageStartedAt(Date.now());
      }
    }, 1400);
  };

  const handleEvaluate = () => {
    if (!current || feedback) return;
    const parsed = evaluateSafeArithmetic(expr);
    if (!parsed.valid) {
      setErrorMsg(parsed.error || 'Invalid expression');
      playErrorTone(soundEnabled);
      return;
    }
    if (!sameMultiset(parsed.usedNumbers, current.numbers)) {
      setErrorMsg(
        settings.language === 'ru'
          ? 'Используйте каждое из 4 чисел ровно один раз'
          : settings.language === 'en'
            ? 'Use each of the 4 given numbers exactly once'
            : toNewUzbekAlphabet('Berilgan 4 ta raqamning har biridan aynan bir marta foydalaning')
      );
      playErrorTone(soundEnabled);
      return;
    }
    if (Math.abs(parsed.value - 24) < 1e-6) {
      setErrorMsg(null);
      finishStage(true);
    } else {
      setErrorMsg(`= ${Number(parsed.value.toFixed(2))} (≠ 24)`);
      playErrorTone(soundEnabled);
    }
  };

  const handleUseHint = () => {
    if (hintsLeft <= 0 || !current || feedback) return;
    setExpr(current.sampleSolution.slice(0, Math.ceil(current.sampleSolution.length / 2)));
    setHintsLeft((h) => h - 1);
    setHintsUsedStage((u) => u + 1);
  };

  if (finalResult) {
    return (
      <GameResultView
        result={finalResult}
        language={settings.language}
        onReplay={() => {
          setStageIdx(0);
          setOutcomes([]);
          setExpr('');
          setErrorMsg(null);
          setFeedback(null);
          setHintsLeft(settings.hintsLimit);
          setTimeLeft(settings.timePerTaskSec);
          setStageStartedAt(Date.now());
          setFinalResult(null);
        }}
        onExit={onExit}
      />
    );
  }

  if (!current) return null;
  const totalScore = outcomes.reduce((acc, o) => acc + o.pointsAwarded, 0);

  return (
    <GameShell
      title={settings.title}
      language={settings.language}
      stageIndex={stageIdx}
      totalStages={stages.length}
      score={totalScore}
      timeRemainingSec={timeLeft}
      timerEnabled={settings.timerEnabled}
      hintsRemaining={hintsLeft}
      onUseHint={handleUseHint}
      soundEnabled={soundEnabled}
      onToggleSound={() => setSoundEnabled((s) => !s)}
      onExit={onExit}
      feedback={feedback}
    >
      <div className="space-y-6 text-center max-w-lg mx-auto">
        <div className="flex justify-center gap-3">
          {current.numbers.map((num, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => setExpr((e) => `${e}${e && !e.endsWith(' ') ? ' ' : ''}${num}`)}
              className="flex h-16 w-16 items-center justify-center rounded-2xl border-2 border-violet-300 dark:border-violet-800 bg-violet-50 dark:bg-violet-950/40 font-mono text-3xl font-extrabold text-violet-700 dark:text-violet-300 hover:border-violet-500 cursor-pointer"
            >
              {num}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <input
            type="text"
            value={expr}
            disabled={feedback !== null}
            onChange={(e) => {
              setExpr(e.target.value);
              setErrorMsg(null);
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleEvaluate();
            }}
            placeholder="(8 - 4) * 6"
            className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 font-mono text-xl font-bold text-slate-900 dark:text-white focus:border-violet-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={() => setExpr((e) => e.slice(0, -1))}
            aria-label="Backspace"
            className="rounded-xl border border-slate-200 dark:border-slate-700 p-3 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <Delete className="h-5 w-5" />
          </button>
        </div>

        {errorMsg && <p className="text-sm font-semibold text-red-600 dark:text-red-400">{errorMsg}</p>}

        {/* Operator Pads */}
        <div className="flex flex-wrap justify-center gap-2">
          {['+', '-', '*', '/', '(', ')'].map((op) => (
            <button
              key={op}
              type="button"
              onClick={() => setExpr((e) => `${e} ${op} `)}
              className="h-11 w-11 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono text-lg font-bold text-slate-800 dark:text-slate-100 hover:border-violet-500 cursor-pointer"
            >
              {op === '*' ? '×' : op === '/' ? '÷' : op}
            </button>
          ))}
        </div>

        <div className="flex justify-center gap-3">
          <button
            type="button"
            onClick={() => {
              setExpr('');
              setErrorMsg(null);
            }}
            className="rounded-xl border border-slate-200 dark:border-slate-700 px-5 py-3 text-base font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
          >
            {ui.clear}
          </button>
          <button
            type="button"
            disabled={!expr.trim() || feedback !== null}
            onClick={handleEvaluate}
            className="rounded-xl bg-violet-600 px-8 py-3 text-base font-semibold text-white hover:bg-violet-700 disabled:opacity-40 cursor-pointer"
          >
            = 24 · {ui.check}
          </button>
        </div>
      </div>
    </GameShell>
  );
}
