import React from 'react';
import {
  Clock,
  Lightbulb,
  Volume2,
  VolumeX,
  RotateCcw,
  ArrowLeft,
  Trophy,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { toNewUzbekAlphabet } from '../../utils/uzbekAlphabet';
import type { Language } from '../../types';
import type { GameResultSummary } from '../types';

export function getGameUiText(lang: Language) {
  if (lang === 'ru') {
    return {
      stage: 'Этап',
      score: 'Баллы',
      time: 'Время',
      hint: 'Подсказка',
      hintsLeft: 'осталось',
      correct: 'Верно!',
      wrong: 'Неверно',
      next: 'Далее',
      finish: 'Завершить',
      check: 'Проверить',
      clear: 'Очистить',
      replay: 'Играть снова',
      exit: 'Выйти',
      completedTitle: 'Тренировка завершена!',
      accuracy: 'Точность',
      correctCount: 'Верных',
      wrongCount: 'Ошибок',
      totalTime: 'Время',
      hintsUsed: 'Подсказки',
      submit: 'Отправить',
      memorize: 'Запомните!',
      recall: 'Воспроизведите!',
    };
  }
  if (lang === 'en') {
    return {
      stage: 'Stage',
      score: 'Score',
      time: 'Time',
      hint: 'Hint',
      hintsLeft: 'left',
      correct: 'Correct!',
      wrong: 'Incorrect',
      next: 'Next',
      finish: 'Finish',
      check: 'Check',
      clear: 'Clear',
      replay: 'Play Again',
      exit: 'Exit',
      completedTitle: 'Session Complete!',
      accuracy: 'Accuracy',
      correctCount: 'Correct',
      wrongCount: 'Errors',
      totalTime: 'Time',
      hintsUsed: 'Hints',
      submit: 'Submit',
      memorize: 'Memorize!',
      recall: 'Recall now!',
    };
  }
  return {
    stage: toNewUzbekAlphabet('Bosqich'),
    score: toNewUzbekAlphabet('Ball'),
    time: toNewUzbekAlphabet('Vaqt'),
    hint: toNewUzbekAlphabet('Maslahat'),
    hintsLeft: toNewUzbekAlphabet('qoldi'),
    correct: toNewUzbekAlphabet("To'g'ri!"),
    wrong: toNewUzbekAlphabet("Noto'g'ri"),
    next: toNewUzbekAlphabet('Keyingi'),
    finish: toNewUzbekAlphabet('Yakunlash'),
    check: toNewUzbekAlphabet('Tekshirish'),
    clear: toNewUzbekAlphabet('Tozalash'),
    replay: toNewUzbekAlphabet("Qayta o'ynash"),
    exit: toNewUzbekAlphabet('Chiqish'),
    completedTitle: toNewUzbekAlphabet("O'yin yakunlandi!"),
    accuracy: toNewUzbekAlphabet('Aniqlik'),
    correctCount: toNewUzbekAlphabet("To'g'ri"),
    wrongCount: toNewUzbekAlphabet('Xato'),
    totalTime: toNewUzbekAlphabet('Sarflangan vaqt'),
    hintsUsed: toNewUzbekAlphabet('Maslahatlar'),
    submit: toNewUzbekAlphabet('Tasdiqlash'),
    memorize: toNewUzbekAlphabet('Eslab qoling!'),
    recall: toNewUzbekAlphabet('Endi javob bering!'),
  };
}

interface GameShellProps {
  title: string;
  language: Language;
  stageIndex: number;
  totalStages: number;
  score: number;
  timeRemainingSec?: number;
  timerEnabled?: boolean;
  hintsRemaining?: number;
  onUseHint?: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onExit?: () => void;
  feedback?: { isCorrect: boolean; message: string } | null;
  children: React.ReactNode;
}

export function GameShell({
  title,
  language,
  stageIndex,
  totalStages,
  score,
  timeRemainingSec,
  timerEnabled,
  hintsRemaining = 0,
  onUseHint,
  soundEnabled,
  onToggleSound,
  onExit,
  feedback,
  children,
}: GameShellProps) {
  const ui = getGameUiText(language);
  const pct = Math.min(100, Math.round(((stageIndex + 1) / Math.max(1, totalStages)) * 100));

  return (
    <div className="space-y-4">
      {/* HUD Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 px-4 py-3.5 sm:px-6">
        <div className="flex items-center gap-3 min-w-0">
          {onExit && (
            <button
              type="button"
              onClick={onExit}
              aria-label={ui.exit}
              className="rounded-xl border border-slate-200 dark:border-slate-700 p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer shrink-0"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
          )}
          <div className="min-w-0">
            <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white truncate">
              {title}
            </h2>
            <p className="font-mono text-xs sm:text-sm text-slate-500 dark:text-slate-400 tabular-nums">
              {ui.stage} {Math.min(stageIndex + 1, totalStages)} / {totalStages}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
          {timerEnabled && typeof timeRemainingSec === 'number' && (
            <div
              className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 font-mono text-sm font-bold tabular-nums ${
                timeRemainingSec <= 10
                  ? 'border-red-300 bg-red-50 text-red-700 dark:border-red-900 dark:bg-red-950/50 dark:text-red-300'
                  : 'border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
              }`}
            >
              <Clock className="h-4 w-4" />
              <span>{timeRemainingSec}s</span>
            </div>
          )}

          <div className="rounded-xl border border-indigo-200 dark:border-indigo-900/70 bg-indigo-50/70 dark:bg-indigo-950/40 px-3.5 py-1.5 font-mono text-sm font-bold text-indigo-700 dark:text-indigo-300 tabular-nums">
            {ui.score}: {score}
          </div>

          {onUseHint && (
            <button
              type="button"
              disabled={hintsRemaining <= 0}
              onClick={onUseHint}
              className="inline-flex items-center gap-1.5 rounded-xl border border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/40 px-3 py-1.5 text-sm font-semibold text-amber-800 dark:text-amber-300 hover:bg-amber-100 disabled:opacity-40 cursor-pointer"
            >
              <Lightbulb className="h-4 w-4" />
              <span className="hidden sm:inline">{ui.hint}</span>
              <span className="font-mono tabular-nums">({hintsRemaining})</span>
            </button>
          )}

          <button
            type="button"
            onClick={onToggleSound}
            aria-label="Toggle sound"
            className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
          >
            {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
        <div
          className="h-full bg-indigo-600 transition-all duration-300"
          style={{ width: `${pct}%` }}
        />
      </div>

      {/* Active Game Surface */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-5 sm:p-8 shadow-sm">
        {children}

        {feedback && (
          <div
            className={`mt-5 flex items-start gap-2.5 rounded-xl border p-4 text-lg ${
              feedback.isCorrect
                ? 'border-emerald-200 dark:border-emerald-900 bg-emerald-50/90 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-100'
                : 'border-red-200 dark:border-red-900 bg-red-50/90 dark:bg-red-950/40 text-red-900 dark:text-red-100'
            }`}
          >
            {feedback.isCorrect ? (
              <CheckCircle2 className="h-5 w-5 shrink-0 mt-0.5 text-emerald-600" />
            ) : (
              <XCircle className="h-5 w-5 shrink-0 mt-0.5 text-red-600" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}
      </div>
    </div>
  );
}

export function GameResultView({
  result,
  language,
  onReplay,
  onExit,
}: {
  result: GameResultSummary;
  language: Language;
  onReplay?: () => void;
  onExit?: () => void;
}) {
  const ui = getGameUiText(language);

  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-10 text-center space-y-6 shadow-sm">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-amber-100 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400">
        <Trophy className="h-9 w-9" />
      </div>

      <div>
        <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          {ui.completedTitle}
        </h2>
        <p className="mt-1 font-mono text-4xl font-extrabold text-indigo-600 dark:text-indigo-400 tabular-nums">
          {result.score} <span className="text-lg font-medium text-slate-400">/ {result.maxScore}</span>
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 border-y border-slate-200 dark:border-slate-800 py-5 font-mono tabular-nums">
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">{ui.accuracy}</div>
          <div className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">
            {result.accuracy}%
          </div>
        </div>
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">{ui.correctCount}</div>
          <div className="mt-1 text-2xl font-bold text-emerald-600 dark:text-emerald-400">
            {result.correctCount}
          </div>
        </div>
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">{ui.wrongCount}</div>
          <div className="mt-1 text-2xl font-bold text-red-600 dark:text-red-400">
            {result.wrongCount}
          </div>
        </div>
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">{ui.totalTime}</div>
          <div className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">
            {(result.timeSpentMs / 1000).toFixed(1)}s
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-3">
        {onReplay && (
          <button
            type="button"
            onClick={onReplay}
            className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-3 text-base font-semibold text-white hover:bg-indigo-700 cursor-pointer"
          >
            <RotateCcw className="h-5 w-5" />
            <span>{ui.replay}</span>
          </button>
        )}
        {onExit && (
          <button
            type="button"
            onClick={onExit}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-6 py-3 text-base font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>{ui.exit}</span>
          </button>
        )}
      </div>
    </div>
  );
}
