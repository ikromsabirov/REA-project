export type GeoShapeType =
  | 'circle'
  | 'triangle'
  | 'square'
  | 'diamond'
  | 'pentagon'
  | 'hexagon'
  | 'star'
  | 'cross';

export interface GeoShapeSpec {
  shape: GeoShapeType;
  color: string;
  rotation?: number; // degrees
  scale?: number; // 0.5 - 1.15
  fill?: 'solid' | 'outline' | 'tinted';
  count?: number; // 1 - 4
  innerDot?: boolean;
}

function renderSingleShape(
  spec: GeoShapeSpec,
  cx: number,
  cy: number,
  radius: number,
  key: number
) {
  const fill =
    spec.fill === 'outline'
      ? 'none'
      : spec.fill === 'tinted'
        ? `${spec.color}33`
        : spec.color;
  const stroke = spec.color;
  const strokeWidth = spec.fill === 'outline' ? 4.2 : 3;
  const transform = `translate(${cx}, ${cy}) rotate(${spec.rotation || 0}) scale(${spec.scale || 1})`;

  let shapeEl = null;
  switch (spec.shape) {
    case 'circle':
      shapeEl = <circle cx={0} cy={0} r={radius} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
      break;
    case 'square':
      shapeEl = (
        <rect
          x={-radius}
          y={-radius}
          width={radius * 2}
          height={radius * 2}
          rx={5}
          fill={fill}
          stroke={stroke}
          strokeWidth={strokeWidth}
        />
      );
      break;
    case 'diamond':
      shapeEl = (
        <polygon
          points={`0,${-radius * 1.15} ${radius * 1.15},0 0,${radius * 1.15} ${-radius * 1.15},0`}
          fill={fill}
          stroke={stroke}
          strokeWidth={strokeWidth}
        />
      );
      break;
    case 'triangle':
      shapeEl = (
        <polygon
          points={`0,${-radius * 1.15} ${radius * 1.05},${radius * 0.85} ${-radius * 1.05},${radius * 0.85}`}
          fill={fill}
          stroke={stroke}
          strokeWidth={strokeWidth}
        />
      );
      break;
    case 'pentagon': {
      const pts = Array.from({ length: 5 }, (_, i) => {
        const a = ((i * 72 - 90) * Math.PI) / 180;
        return `${(Math.cos(a) * radius * 1.05).toFixed(1)},${(Math.sin(a) * radius * 1.05).toFixed(1)}`;
      }).join(' ');
      shapeEl = <polygon points={pts} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
      break;
    }
    case 'hexagon': {
      const pts = Array.from({ length: 6 }, (_, i) => {
        const a = ((i * 60 - 30) * Math.PI) / 180;
        return `${(Math.cos(a) * radius * 1.05).toFixed(1)},${(Math.sin(a) * radius * 1.05).toFixed(1)}`;
      }).join(' ');
      shapeEl = <polygon points={pts} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
      break;
    }
    case 'star': {
      const pts = Array.from({ length: 10 }, (_, i) => {
        const r = i % 2 === 0 ? radius * 1.15 : radius * 0.5;
        const a = ((i * 36 - 90) * Math.PI) / 180;
        return `${(Math.cos(a) * r).toFixed(1)},${(Math.sin(a) * r).toFixed(1)}`;
      }).join(' ');
      shapeEl = <polygon points={pts} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
      break;
    }
    case 'cross': {
      const t = radius * 0.36;
      const l = radius * 1.05;
      const d = `M${-t},${-l} H${t} V${-t} H${l} V${t} H${t} V${l} H${-t} V${t} H${-l} V${-t} H${-t} Z`;
      shapeEl = <path d={d} fill={fill} stroke={stroke} strokeWidth={strokeWidth} />;
      break;
    }
  }

  return (
    <g key={key} transform={transform}>
      {shapeEl}
      {spec.innerDot && (
        <circle
          cx={0}
          cy={0}
          r={Math.max(4, radius * 0.27)}
          fill={spec.fill === 'solid' ? '#ffffff' : stroke}
        />
      )}
    </g>
  );
}

export function ShapeSvg({
  spec,
  size = 108,
  className = '',
}: {
  spec: GeoShapeSpec;
  size?: number;
  className?: string;
}) {
  const count = Math.min(4, Math.max(1, spec.count ?? 1));
  const positions: Array<[number, number, number]> =
    count === 1
      ? [[50, 50, 35]]
      : count === 2
        ? [
            [27, 50, 19.5],
            [73, 50, 19.5],
          ]
        : count === 3
          ? [
              [50, 27, 17],
              [27, 72, 17],
              [73, 72, 17],
            ]
          : [
              [27, 27, 17.5],
              [73, 27, 17.5],
              [27, 73, 17.5],
              [73, 73, 17.5],
            ];

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={`max-w-full h-auto ${className}`}
      aria-label={`${spec.shape}`}
    >
      {positions.map(([cx, cy, r], idx) => renderSingleShape(spec, cx, cy, r, idx))}
    </svg>
  );
}
