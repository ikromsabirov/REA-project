import { useEffect, useState } from 'react';
import { Info, Trophy, Play, Target, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiRequest } from '../lib/api';
import { getCatalogEntry } from '../games/registry';
import { getStoredStudentKey } from './PracticePage';
import { toNewUzbekAlphabet } from '../utils/uzbekAlphabet';
import type { GameCategoryId } from '../games/types';
import type { Language } from '../types';

interface ProfileData {
  studentKey: string;
  totalSessions: number;
  totalScore: number;
  avgAccuracy: number;
  dimensions: {
    logic: number;
    memory: number;
    spatial: number;
    attention: number;
    math: number;
    words: number;
    speed: number;
  };
  history: Array<{
    id: string;
    source: 'practice' | 'competition';
    gameType: string;
    category: GameCategoryId;
    score: number;
    maxScore: number;
    accuracy: number;
    timeSpentMs: number;
    createdAt: string;
  }>;
  disclaimer: Record<Language, string>;
}

function SevenAxisRadarChart({
  dimensions,
  labels,
}: {
  dimensions: ProfileData['dimensions'];
  labels: Array<{ key: keyof ProfileData['dimensions']; label: string }>;
}) {
  const cx = 160;
  const cy = 160;
  const radius = 102;
  const count = labels.length;

  const pointAt = (idx: number, ratio: number) => {
    const angle = -Math.PI / 2 + (idx * 2 * Math.PI) / count;
    return {
      x: cx + Math.cos(angle) * radius * ratio,
      y: cy + Math.sin(angle) * radius * ratio,
    };
  };

  const dataPoints = labels.map((item, idx) => {
    const val = Math.max(0.08, Math.min(1, dimensions[item.key] / 100));
    return pointAt(idx, val);
  });

  const polyStr = dataPoints.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');

  return (
    <svg viewBox="0 0 320 320" className="mx-auto w-full max-w-[330px]">
      {[0.25, 0.5, 0.75, 1].map((ring) => {
        const pts = labels.map((_, idx) => pointAt(idx, ring));
        return (
          <polygon
            key={ring}
            points={pts.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ')}
            fill="none"
            stroke="#94a3b8"
            strokeOpacity={0.3}
            strokeWidth={1}
          />
        );
      })}

      {labels.map((item, idx) => {
        const edge = pointAt(idx, 1);
        const labelPt = pointAt(idx, 1.24);
        return (
          <g key={item.key}>
            <line x1={cx} y1={cy} x2={edge.x} y2={edge.y} stroke="#94a3b8" strokeOpacity={0.35} />
            <text
              x={labelPt.x}
              y={labelPt.y}
              textAnchor="middle"
              dominantBaseline="central"
              className="fill-slate-700 dark:fill-slate-200 text-[11px] font-bold"
            >
              {item.label} ({dimensions[item.key]})
            </text>
          </g>
        );
      })}

      <polygon
        points={polyStr}
        fill="#4f46e5"
        fillOpacity={0.28}
        stroke="#4f46e5"
        strokeWidth={2.5}
      />

      {dataPoints.map((p, idx) => (
        <circle key={idx} cx={p.x} cy={p.y} r={4.5} fill="#4f46e5" stroke="#ffffff" strokeWidth={1.5} />
      ))}
    </svg>
  );
}

export function ProfilePage() {
  const { lang, user, studentSession, navigate } = useApp();
  const stored = getStoredStudentKey();
  const [nameQuery, setNameQuery] = useState(
    studentSession?.displayName || user?.fullName || stored.name || ''
  );
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (targetName: string) => {
    setLoading(true);
    try {
      const q = new URLSearchParams({ studentKey: stored.key });
      if (targetName.trim()) q.set('studentName', targetName.trim());
      const res = await apiRequest<ProfileData>(`/api/profile?${q.toString()}`);
      setProfile(res);
    } catch {
      // handled cleanly
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile(nameQuery);
  }, []);

  const t =
    lang === 'ru'
      ? {
          title: 'Интеллектуальный профиль ученика',
          subtitle: 'Анализ результатов по 7 направлениям тренировок и соревнований.',
          searchName: 'Имя ученика (для истории соревнований)',
          updateBtn: 'Обновить',
          sessions: 'Всего игр',
          totalScore: 'Общие баллы',
          avgAcc: 'Средняя точность',
          radarTitle: 'Радар-профиль по 7 показателям',
          trendTitle: 'Динамика последних сессий (%)',
          historyTitle: 'История игр',
          noHistory: 'Пока нет сыгранных сессий. Выберите игру в каталоге!',
          goCatalog: 'Открыть каталог игр',
          axes: [
            { key: 'logic' as const, label: 'Логика' },
            { key: 'memory' as const, label: 'Память' },
            { key: 'spatial' as const, label: 'Пространство' },
            { key: 'attention' as const, label: 'Внимание' },
            { key: 'math' as const, label: 'Математика' },
            { key: 'words' as const, label: 'Слова' },
            { key: 'speed' as const, label: 'Скорость' },
          ],
        }
      : lang === 'en'
        ? {
            title: 'Student Intellectual Profile',
            subtitle: 'Performance breakdown across all 7 cognitive and speed dimensions.',
            searchName: 'Student Name (syncs competition history)',
            updateBtn: 'Refresh',
            sessions: 'Total Sessions',
            totalScore: 'Total Points',
            avgAcc: 'Avg Accuracy',
            radarTitle: '7-Dimension Performance Radar',
            trendTitle: 'Recent Session Accuracy Trend',
            historyTitle: 'Session History',
            noHistory: 'No completed games yet. Start practicing from the catalog!',
            goCatalog: 'Browse Game Catalog',
            axes: [
              { key: 'logic' as const, label: 'Logic' },
              { key: 'memory' as const, label: 'Memory' },
              { key: 'spatial' as const, label: 'Spatial' },
              { key: 'attention' as const, label: 'Attention' },
              { key: 'math' as const, label: 'Math' },
              { key: 'words' as const, label: 'Words' },
              { key: 'speed' as const, label: 'Speed' },
            ],
          }
        : {
            title: toNewUzbekAlphabet("O'quvchining intellektual profili"),
            subtitle: toNewUzbekAlphabet(
              "Mashq va musobaqa natijalari asosida 7 ta ko'rsatkich bo'yicha tahlil."
            ),
            searchName: toNewUzbekAlphabet("O'quvchi ismi (musobaqa tarixini bog'lash uchun)"),
            updateBtn: toNewUzbekAlphabet('Yangilash'),
            sessions: toNewUzbekAlphabet("Jami o'yinlar"),
            totalScore: toNewUzbekAlphabet('Umumiy ball'),
            avgAcc: toNewUzbekAlphabet("O'rtacha aniqlik"),
            radarTitle: toNewUzbekAlphabet("7 yo'nalish bo'yicha radar grafik"),
            trendTitle: toNewUzbekAlphabet("So'nggi natijalar dinamikasi"),
            historyTitle: toNewUzbekAlphabet("O'yinlar tarixi"),
            noHistory: toNewUzbekAlphabet(
              "Hali o'yin natijalari mavjud emas. Katalogdan birinchi o'yinni boshlang!"
            ),
            goCatalog: toNewUzbekAlphabet("O'yinlar katalogini ochish"),
            axes: [
              { key: 'logic' as const, label: toNewUzbekAlphabet('Mantiq') },
              { key: 'memory' as const, label: toNewUzbekAlphabet('Xotira') },
              { key: 'spatial' as const, label: toNewUzbekAlphabet('Fazo') },
              { key: 'attention' as const, label: toNewUzbekAlphabet('Diqqat') },
              { key: 'math' as const, label: toNewUzbekAlphabet('Matematika') },
              { key: 'words' as const, label: toNewUzbekAlphabet("So'z") },
              { key: 'speed' as const, label: toNewUzbekAlphabet('Tezlik') },
            ],
          };

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 space-y-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            {t.title}
          </h1>
          <p className="mt-1 text-base text-slate-600 dark:text-slate-300">{t.subtitle}</p>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="text"
            value={nameQuery}
            onChange={(e) => setNameQuery(e.target.value)}
            placeholder={t.searchName}
            className="rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2.5 text-sm text-slate-900 dark:text-white"
          />
          <button
            type="button"
            onClick={() => fetchProfile(nameQuery)}
            className="rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 cursor-pointer"
          >
            {t.updateBtn}
          </button>
        </div>
      </div>

      {/* Non-clinical transparent educational disclaimer */}
      {profile && (
        <div className="flex items-start gap-3 rounded-2xl border border-sky-200 dark:border-sky-900/60 bg-sky-50/80 dark:bg-sky-950/30 p-4 text-sm text-sky-900 dark:text-sky-200">
          <Info className="h-5 w-5 shrink-0 mt-0.5 text-sky-600 dark:text-sky-400" />
          <span>{profile.disclaimer[lang]}</span>
        </div>
      )}

      {loading ? (
        <p className="text-base text-slate-500 dark:text-slate-400">Loading...</p>
      ) : !profile || profile.totalSessions === 0 ? (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-10 text-center space-y-4">
          <p className="text-base text-slate-600 dark:text-slate-300">{t.noHistory}</p>
          <button
            type="button"
            onClick={() => navigate('/catalog')}
            className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-3 text-base font-semibold text-white hover:bg-indigo-700 cursor-pointer"
          >
            <Play className="h-5 w-5" />
            <span>{t.goCatalog}</span>
          </button>
        </div>
      ) : (
        <>
          {/* KPI Summary */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-5">
              <div className="text-sm text-slate-500 dark:text-slate-400">{t.sessions}</div>
              <div className="mt-1 font-mono text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                {profile.totalSessions}
              </div>
            </div>
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-5">
              <div className="text-sm text-slate-500 dark:text-slate-400">{t.totalScore}</div>
              <div className="mt-1 font-mono text-3xl font-extrabold text-indigo-600 dark:text-indigo-400 tabular-nums">
                {profile.totalScore}
              </div>
            </div>
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-5">
              <div className="text-sm text-slate-500 dark:text-slate-400">{t.avgAcc}</div>
              <div className="mt-1 font-mono text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">
                {profile.avgAccuracy}%
              </div>
            </div>
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-4">
                {t.radarTitle}
              </h2>
              <SevenAxisRadarChart dimensions={profile.dimensions} labels={t.axes} />
            </div>

            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 flex flex-col justify-between">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-4">
                {t.trendTitle}
              </h2>
              <div className="flex items-end gap-2.5 h-56 pt-4 border-b border-slate-200 dark:border-slate-800">
                {profile.history
                  .slice(0, 10)
                  .reverse()
                  .map((h) => (
                    <div key={h.id} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                      <span className="font-mono text-xs font-bold text-slate-500 dark:text-slate-400 tabular-nums">
                        {h.accuracy}%
                      </span>
                      <div
                        className="w-full max-w-[32px] rounded-t-lg bg-indigo-600 transition-all"
                        style={{ height: `${Math.max(8, h.accuracy)}%` }}
                      />
                    </div>
                  ))}
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-xs text-slate-500 dark:text-slate-400">
                {t.axes.map((a) => (
                  <div key={a.key} className="flex justify-between">
                    <span>{a.label}</span>
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                      {profile.dimensions[a.key]}/100
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* History Table */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                {t.historyTitle}
              </h2>
            </div>
            <div className="divide-y divide-slate-200 dark:divide-slate-800">
              {profile.history.map((h) => {
                const entry = getCatalogEntry(h.gameType);
                return (
                  <div
                    key={h.id}
                    className="flex flex-wrap items-center justify-between gap-4 px-6 py-3.5 text-sm sm:text-base"
                  >
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-white">
                        {entry ? entry.name[lang] : h.gameType}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        {h.source === 'competition' ? (
                          <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-semibold">
                            <Trophy className="h-3.5 w-3.5" /> Competition
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-400 font-semibold">
                            <Target className="h-3.5 w-3.5" /> Practice
                          </span>
                        )}{' '}
                        · {new Date(h.createdAt).toLocaleDateString()}
                      </div>
                    </div>

                    <div className="flex items-center gap-4 font-mono text-sm font-bold tabular-nums">
                      <span className="inline-flex items-center gap-1 text-slate-500">
                        <Clock className="h-3.5 w-3.5" />
                        {(h.timeSpentMs / 1000).toFixed(1)}s
                      </span>
                      <span className="text-emerald-600 dark:text-emerald-400">{h.accuracy}%</span>
                      <span className="text-indigo-600 dark:text-indigo-400">
                        {h.score}/{h.maxScore}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </main>
  );
}
