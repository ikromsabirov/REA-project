import { useEffect, useState } from 'react';
import { Trophy } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiRequest } from '../lib/api';
import type { LeaderboardEntry } from '../types';

type PeriodFilter = 'daily' | 'weekly' | 'monthly' | 'all' | 'competition' | 'class';

export function LeaderboardPage() {
  const { t } = useApp();
  const [period, setPeriod] = useState<PeriodFilter>('all');
  const [competitionId, setCompetitionId] = useState('');
  const [className, setClassName] = useState('');

  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [competitions, setCompetitions] = useState<
    Array<{ id: string; title: string; code: string }>
  >([]);
  const [classes, setClasses] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams({ period });
    if (period === 'competition' && competitionId) params.set('competitionId', competitionId);
    if (period === 'class' && className) params.set('className', className);

    apiRequest<{
      entries: LeaderboardEntry[];
      competitions: Array<{ id: string; title: string; code: string }>;
      classes: string[];
    }>(`/api/leaderboard?${params.toString()}`)
      .then((res) => {
        setEntries(res.entries);
        setCompetitions(res.competitions);
        setClasses(res.classes);
        if (!competitionId && res.competitions.length > 0) {
          setCompetitionId(res.competitions[0].id);
        }
        if (!className && res.classes.length > 0) {
          setClassName(res.classes[0]);
        }
      })
      .finally(() => setLoading(false));
  }, [period, competitionId, className]);

  const filterTabs: Array<{ id: PeriodFilter; label: string }> = [
    { id: 'daily', label: t.periodDaily },
    { id: 'weekly', label: t.periodWeekly },
    { id: 'monthly', label: t.periodMonthly },
    { id: 'all', label: t.periodAll },
    { id: 'competition', label: t.periodByCompetition },
    { id: 'class', label: t.periodByClass },
  ];

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 space-y-6">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
          <Trophy className="h-7 w-7 text-amber-500" />
          <span>{t.leaderboardTitle}</span>
        </h1>
        <p className="mt-1.5 text-base text-slate-600 dark:text-slate-300">
          {t.leaderboardSubtitle}
        </p>
      </div>

      {/* Filter Segmented Tabs */}
      <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 p-2">
        {filterTabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setPeriod(tab.id)}
            className={`rounded-xl px-4 py-2 text-sm sm:text-base font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              period === tab.id
                ? 'bg-indigo-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Contextual Selector for Competition or Class */}
      {period === 'competition' && competitions.length > 0 && (
        <div className="max-w-md">
          <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
            {t.selectCompetition}
          </label>
          <select
            value={competitionId}
            onChange={(e) => setCompetitionId(e.target.value)}
            className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2.5 text-base text-slate-900 dark:text-white"
          >
            {competitions.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title} ({c.code})
              </option>
            ))}
          </select>
        </div>
      )}

      {period === 'class' && classes.length > 0 && (
        <div className="max-w-xs">
          <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
            {t.selectClass}
          </label>
          <select
            value={className}
            onChange={(e) => setClassName(e.target.value)}
            className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2.5 text-base text-slate-900 dark:text-white"
          >
            {classes.map((cls) => (
              <option key={cls} value={cls}>
                {cls}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Standings Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95">
        {loading ? (
          <p className="p-8 text-base text-slate-500 dark:text-slate-400">{t.loadingText}</p>
        ) : entries.length === 0 ? (
          <p className="p-8 text-base text-slate-500 dark:text-slate-400">
            {t.noLeaderboardData}
          </p>
        ) : (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-sm font-semibold text-slate-600 dark:text-slate-300">
                <th className="px-5 py-3.5">{t.rankCol}</th>
                <th className="px-5 py-3.5">{t.nameCol}</th>
                <th className="px-5 py-3.5">{t.classCol}</th>
                <th className="px-5 py-3.5">{t.periodByCompetition}</th>
                <th className="px-5 py-3.5 text-right">{t.scoreCol}</th>
                <th className="px-5 py-3.5 text-right">{t.correctCol}</th>
                <th className="px-5 py-3.5 text-right">{t.timeCol}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-base">
              {entries.map((row) => (
                <tr key={row.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                  <td className="px-5 py-3.5 font-mono font-bold tabular-nums text-indigo-600 dark:text-indigo-400">
                    #{row.rank}
                  </td>
                  <td className="px-5 py-3.5 font-semibold text-slate-900 dark:text-white">
                    {row.displayName}
                  </td>
                  <td className="px-5 py-3.5 text-slate-600 dark:text-slate-300">
                    {row.className}
                  </td>
                  <td className="px-5 py-3.5 text-slate-600 dark:text-slate-300">
                    {row.competitionTitle}{' '}
                    <span className="font-mono text-xs text-slate-400">
                      ({row.competitionCode})
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-right font-mono font-bold tabular-nums text-slate-900 dark:text-white">
                    {row.score}
                  </td>
                  <td className="px-5 py-3.5 text-right font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
                    {row.correctCount}
                  </td>
                  <td className="px-5 py-3.5 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                    {(row.totalTimeMs / 1000).toFixed(1)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </main>
  );
}
