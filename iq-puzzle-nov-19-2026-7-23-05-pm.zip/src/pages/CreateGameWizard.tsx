import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Plus,
  Sparkles,
  Trash2,
  AlertCircle,
  Save,
  Image as ImageIcon,
  Upload,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiRequest } from '../lib/api';
import { formatByLanguage } from '../utils/uzbekAlphabet';
import { GAME_CATALOG, GAME_CATEGORIES, getCatalogEntry, isGameTypeId } from '../games/registry';
import type { GameTypeId } from '../games/types';
import type {
  AIProvider,
  Difficulty,
  Language,
  QuestionItem,
  ResultDisplayMode,
} from '../types';

interface MediaAssetItem {
  id: string;
  owner_id: string | null;
  title: string;
  mime_type: string;
  byte_size: number;
  data_url: string;
  is_builtin: number;
}

const emptyQuestion = (): QuestionItem => ({
  prompt: '',
  options: ['', '', '', ''],
  correctIndex: 0,
  explanation: '',
});

export function CreateGameWizard({ editGameId }: { editGameId?: string }) {
  const { t, lang, user, navigate } = useApp();

  const [step, setStep] = useState<1 | 2 | 3>(editGameId ? 2 : 1);
  const [gameId, setGameId] = useState<string | null>(editGameId || null);

  // Step 1: Game Language (immutable once created)
  const [gameLang, setGameLang] = useState<Language>(lang);

  // Step 2: Game Parameters
  const [gameType, setGameType] = useState<'quiz' | GameTypeId>('quiz');
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [questionCount, setQuestionCount] = useState(5);
  const [timePerQuestion, setTimePerQuestion] = useState(30);
  const [pointsPerQuestion, setPointsPerQuestion] = useState(100);
  const [hintsLimit, setHintsLimit] = useState(3);
  const [totalDurationMinutes, setTotalDurationMinutes] = useState(10);
  const [maxStudents, setMaxStudents] = useState(50);
  const [scheduledAt, setScheduledAt] = useState('');
  const [resultDisplayMode, setResultDisplayMode] = useState<ResultDisplayMode>('after_each');

  // Step 3: Manual or AI & Media Library
  const [method, setMethod] = useState<'manual' | 'ai'>('manual');
  const [questions, setQuestions] = useState<QuestionItem[]>([emptyQuestion()]);
  const [aiTopic, setAiTopic] = useState('');
  const [aiAgeGrade, setAiAgeGrade] = useState('10-14');
  const [aiCustomInstructions, setAiCustomInstructions] = useState('');
  const [aiProvider, setAiProvider] = useState<'' | AIProvider>('');
  const [hasDraftAI, setHasDraftAI] = useState(false);

  const [mediaAssets, setMediaAssets] = useState<MediaAssetItem[]>([]);
  const [uploadingMedia, setUploadingMedia] = useState(false);

  const [loading, setLoading] = useState(Boolean(editGameId));
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    apiRequest<{ assets: MediaAssetItem[] }>('/api/media')
      .then((res) => setMediaAssets(res.assets))
      .catch(() => {});

    if (!editGameId) return;

    setLoading(true);
    apiRequest<{
      game: {
        id: string;
        title: string;
        language: Language;
        subject: string;
        difficulty: Difficulty;
        question_count: number;
        time_per_question: number;
        points_per_question: number;
        total_duration_minutes: number;
        max_students: number;
        scheduled_at: string | null;
        result_display_mode: ResultDisplayMode;
        creation_method: 'manual' | 'ai';
        ai_topic: string | null;
        game_type?: string;
        hints_limit?: number;
        status: string;
      };
      questions: QuestionItem[];
    }>(`/api/games/${editGameId}`)
      .then((res) => {
        const g = res.game;
        setGameLang(g.language);
        setGameType(g.game_type && isGameTypeId(g.game_type) ? g.game_type : 'quiz');
        setTitle(g.title);
        setSubject(g.subject);
        setDifficulty(g.difficulty);
        setQuestionCount(g.question_count);
        setTimePerQuestion(g.time_per_question);
        setPointsPerQuestion(g.points_per_question);
        setHintsLimit(g.hints_limit ?? 3);
        setTotalDurationMinutes(g.total_duration_minutes);
        setMaxStudents(g.max_students);
        setScheduledAt(g.scheduled_at || '');
        setResultDisplayMode(g.result_display_mode);
        setMethod(g.creation_method);
        setAiTopic(g.ai_topic || '');
        if (res.questions.length > 0) {
          setQuestions(res.questions);
          setHasDraftAI(res.questions.some((q) => !q.isApproved));
        }
      })
      .catch((err) => {
        setError(err instanceof Error ? err.message : 'Failed to load game');
      })
      .finally(() => setLoading(false));
  }, [editGameId, user]);

  const handleGameTypeChange = (nextType: 'quiz' | GameTypeId) => {
    setGameType(nextType);
    if (nextType !== 'quiz') {
      const entry = getCatalogEntry(nextType);
      if (!entry) return;
      setQuestionCount(entry.defaultStages);
      setTimePerQuestion(entry.defaultTimeSec);
      if (!title.trim()) {
        setTitle(entry.name[gameLang]);
      }
      if (!subject.trim()) {
        const cat = GAME_CATEGORIES.find((c) => c.id === entry.category);
        if (cat) setSubject(cat.label[gameLang]);
      }
    }
  };

  const ensureGameCreatedOrUpdated = async (
    creationMethod: 'manual' | 'ai',
    forcedStatus?: 'published'
  ): Promise<string> => {
    const cleanTitle = formatByLanguage(title.trim(), gameLang);
    const cleanSubject = formatByLanguage(subject.trim() || 'IQ', gameLang);
    if (!cleanTitle) {
      throw new Error('Please enter a game title.');
    }

    const payload = {
      title: cleanTitle,
      language: gameLang,
      subject: cleanSubject,
      gameType,
      difficulty,
      questionCount,
      timePerQuestion,
      pointsPerQuestion,
      hintsLimit,
      totalDurationMinutes,
      maxStudents,
      scheduledAt: scheduledAt || null,
      resultDisplayMode,
      creationMethod,
      aiTopic: aiTopic || null,
      ...(forcedStatus ? { status: forcedStatus } : {}),
    };

    if (!gameId) {
      const res = await apiRequest<{ game: { id: string } }>('/api/games', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      setGameId(res.game.id);
      return res.game.id;
    } else {
      await apiRequest(`/api/games/${gameId}`, {
        method: 'PUT',
        body: JSON.stringify(payload),
      });
      return gameId;
    }
  };

  const handlePublishInteractiveGame = async () => {
    setError('');
    if (!title.trim()) {
      setError('Game title is required.');
      return;
    }
    setSaving(true);
    try {
      await ensureGameCreatedOrUpdated('manual', 'published');
      navigate('/teacher');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not publish game');
    } finally {
      setSaving(false);
    }
  };

  const handleStep2Next = async () => {
    setError('');
    if (!title.trim()) {
      setError('Game title is required.');
      return;
    }
    setSaving(true);
    try {
      await ensureGameCreatedOrUpdated(method);
      setStep(3);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save game parameters');
    } finally {
      setSaving(false);
    }
  };

  const handleGenerateAI = async () => {
    setError('');
    setNotice('');
    if (!aiTopic.trim()) {
      setError('Please enter a topic for AI question generation.');
      return;
    }
    setGenerating(true);
    try {
      const id = await ensureGameCreatedOrUpdated('ai');
      const res = await apiRequest<{
        provider: AIProvider;
        questions: QuestionItem[];
      }>(`/api/games/${id}/ai-generate`, {
        method: 'POST',
        body: JSON.stringify({
          topic: aiTopic.trim(),
          count: questionCount,
          gameType,
          ageGrade: aiAgeGrade.trim() || undefined,
          customInstructions: aiCustomInstructions.trim() || undefined,
          provider: aiProvider || undefined,
        }),
      });
      setQuestions(res.questions);
      setHasDraftAI(true);
      setNotice(`${t.aiApprovalNotice} (${res.provider.toUpperCase()})`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'AI generation failed');
    } finally {
      setGenerating(false);
    }
  };

  const handleUploadMedia = async (file: File | undefined) => {
    if (!file) return;
    setError('');
    if (file.size > 1_100_000) {
      setError('File size must be under 1 MB.');
      return;
    }
    setUploadingMedia(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsDataURL(file);
      });
      const res = await apiRequest<{ asset: MediaAssetItem }>('/api/media', {
        method: 'POST',
        body: JSON.stringify({
          title: file.name.slice(0, 60),
          mimeType: file.type,
          dataUrl,
        }),
      });
      setMediaAssets((prev) => [res.asset, ...prev]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Media upload failed');
    } finally {
      setUploadingMedia(false);
    }
  };

  const handleDeleteMedia = async (assetId: string) => {
    try {
      await apiRequest(`/api/media/${assetId}`, { method: 'DELETE' });
      setMediaAssets((prev) => prev.filter((a) => a.id !== assetId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete asset');
    }
  };

  const handleSaveQuestionEdit = async (idx: number) => {
    const q = questions[idx];
    if (!gameId || !q.id) return;
    setError('');
    try {
      const res = await apiRequest<{ question: QuestionItem }>(
        `/api/games/${gameId}/questions/${q.id}`,
        {
          method: 'PUT',
          body: JSON.stringify({
            prompt: q.prompt,
            options: q.options,
            correctIndex: q.correctIndex,
            explanation: q.explanation,
          }),
        }
      );
      setQuestions((prev) =>
        prev.map((item, i) => (i === idx ? { ...item, ...res.question } : item))
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update question');
    }
  };

  const handleDeleteQuestion = async (idx: number) => {
    const q = questions[idx];
    if (gameId && q.id) {
      try {
        await apiRequest(`/api/games/${gameId}/questions/${q.id}`, { method: 'DELETE' });
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to delete question');
        return;
      }
    }
    setQuestions((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSaveManualQuestions = async () => {
    setError('');
    const valid = questions.filter(
      (q) => q.prompt.trim() && q.options.every((o) => o.trim().length > 0)
    );
    if (valid.length === 0) {
      setError('Please complete at least 1 question with 4 options.');
      return;
    }

    setSaving(true);
    try {
      const id = await ensureGameCreatedOrUpdated('manual');
      await apiRequest(`/api/games/${id}/questions`, {
        method: 'POST',
        body: JSON.stringify({
          replaceAll: true,
          questions: valid,
        }),
      });
      navigate('/teacher');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save questions');
    } finally {
      setSaving(false);
    }
  };

  const handleApproveAndPublish = async () => {
    if (!gameId) return;
    setError('');
    setSaving(true);
    try {
      // Persist any local edits to AI-generated questions first
      for (let i = 0; i < questions.length; i++) {
        const q = questions[i];
        if (q.id) {
          await apiRequest(`/api/games/${gameId}/questions/${q.id}`, {
            method: 'PUT',
            body: JSON.stringify({
              prompt: q.prompt,
              options: q.options,
              correctIndex: q.correctIndex,
              explanation: q.explanation,
            }),
          });
        }
      }
      await apiRequest(`/api/games/${gameId}/approve`, { method: 'POST' });
      navigate('/teacher');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Approval failed');
    } finally {
      setSaving(false);
    }
  };

  if (!user) return null;
  if (loading) {
    return (
      <main className="mx-auto max-w-4xl px-4 py-12 text-base text-slate-600 dark:text-slate-300">
        {t.loadingText}
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-4xl px-4 py-8 sm:px-6 space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <button
            type="button"
            onClick={() => navigate('/teacher')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>{t.backBtn}</span>
          </button>
          <h1 className="mt-2 font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            {t.wizardTitle}
          </h1>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center gap-2 text-sm font-semibold">
          {([1, 2, 3] as const).map((s) => (
            <button
              key={s}
              type="button"
              disabled={s === 1 && Boolean(gameId)}
              onClick={() => {
                if (s === 1 && gameId) return;
                if (s === 3 && !gameId) return;
                setStep(s);
              }}
              className={`rounded-lg px-3 py-1.5 transition-colors cursor-pointer ${
                step === s
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              0{s}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="flex items-start gap-2.5 rounded-xl border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/40 px-4 py-3 text-base text-red-700 dark:text-red-300"
        >
          <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {notice && (
        <div className="flex items-start gap-2.5 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50 dark:bg-amber-950/40 px-4 py-3 text-base text-amber-800 dark:text-amber-200">
          <Sparkles className="h-5 w-5 shrink-0 mt-0.5" />
          <span>{notice}</span>
        </div>
      )}

      {/* STEP 1: LANGUAGE SELECTION */}
      {step === 1 && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 space-y-6">
          <div>
            <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {t.step1Label}
            </h2>
            <p className="mt-1.5 text-base text-slate-600 dark:text-slate-300">{t.step1Desc}</p>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            {(
              [
                { code: 'uz', title: 'Özbekça', sub: 'Yangi lotin alifbosi (Ö, Ğ, Ş, Ç)' },
                { code: 'ru', title: 'Русский', sub: 'Кириллица / Академический язык' },
                { code: 'en', title: 'English', sub: 'International Academic English' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.code}
                type="button"
                onClick={() => setGameLang(opt.code)}
                className={`rounded-2xl border p-5 text-left transition-colors cursor-pointer ${
                  gameLang === opt.code
                    ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/40'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400">
                  {opt.code.toUpperCase()}
                </div>
                <div className="mt-1 font-display text-xl font-bold text-slate-900 dark:text-white">
                  {opt.title}
                </div>
                <div className="mt-1 text-sm text-slate-600 dark:text-slate-400">{opt.sub}</div>
              </button>
            ))}
          </div>

          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-3 text-base font-semibold text-white hover:bg-indigo-700 cursor-pointer"
            >
              <span>{t.nextStep}</span>
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </section>
      )}

      {/* STEP 2: GAME PARAMETERS */}
      {step === 2 && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {t.step2Label}
            </h2>
            <span className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400">
              {gameLang.toUpperCase()}
            </span>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.gameTypeLabel}
              </label>
              <select
                value={gameType}
                onChange={(e) => handleGameTypeChange(e.target.value as 'quiz' | GameTypeId)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
              >
                <option value="quiz">{t.quizTypeOption}</option>
                {GAME_CATEGORIES.map((cat) => (
                  <optgroup key={cat.id} label={cat.label[gameLang]}>
                    {GAME_CATALOG.filter((g) => g.category === cat.id).map((entry) => (
                      <option key={entry.id} value={entry.id}>
                        #{String(entry.number).padStart(2, '0')} · {entry.name[gameLang]}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.gameTitleLabel}
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.gameSubjectLabel}
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Matematika / Mantiq / Fizika / IT"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.difficultyLabel}
              </label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as Difficulty)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
              >
                <option value="easy">{t.diffEasy}</option>
                <option value="medium">{t.diffMedium}</option>
                <option value="hard">{t.diffHard}</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.questionCountLabel}
              </label>
              <input
                type="number"
                min={1}
                max={30}
                value={questionCount}
                onChange={(e) => setQuestionCount(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 font-mono text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.timePerQuestionLabel}
              </label>
              <input
                type="number"
                min={10}
                max={180}
                value={timePerQuestion}
                onChange={(e) => setTimePerQuestion(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 font-mono text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.pointsPerQuestionLabel}
              </label>
              <input
                type="number"
                min={10}
                max={1000}
                step={10}
                value={pointsPerQuestion}
                onChange={(e) => setPointsPerQuestion(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 font-mono text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.totalDurationLabel}
              </label>
              <input
                type="number"
                min={1}
                max={180}
                value={totalDurationMinutes}
                onChange={(e) => setTotalDurationMinutes(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 font-mono text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.maxStudentsLabel}
              </label>
              <input
                type="number"
                min={2}
                max={500}
                value={maxStudents}
                onChange={(e) => setMaxStudents(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 font-mono text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.scheduledAtLabel}
              </label>
              <input
                type="datetime-local"
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.hintsLimitLabel}
              </label>
              <input
                type="number"
                min={0}
                max={10}
                value={hintsLimit}
                onChange={(e) => setHintsLimit(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 font-mono text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.resultDisplayLabel}
              </label>
              <select
                value={resultDisplayMode}
                onChange={(e) => setResultDisplayMode(e.target.value as ResultDisplayMode)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
              >
                <option value="after_each">{t.modeAfterEach}</option>
                <option value="after_finish">{t.modeAfterFinish}</option>
                <option value="live_leaderboard">{t.modeLiveLeaderboard}</option>
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            {!editGameId ? (
              <button
                type="button"
                onClick={() => setStep(1)}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 px-5 py-3 text-base font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>{t.prevStep}</span>
              </button>
            ) : (
              <div />
            )}

            <div className="flex flex-wrap items-center gap-3">
              {gameType !== 'quiz' && (
                <button
                  type="button"
                  disabled={saving}
                  onClick={handlePublishInteractiveGame}
                  className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-3 text-base font-semibold text-white hover:bg-emerald-700 disabled:opacity-60 cursor-pointer"
                >
                  <CheckCircle2 className="h-5 w-5" />
                  <span>{saving ? t.loadingText : t.publishInteractiveBtn}</span>
                </button>
              )}
              <button
                type="button"
                disabled={saving}
                onClick={handleStep2Next}
                className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-3 text-base font-semibold text-white hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
              >
                <span>{saving ? t.loadingText : t.nextStep}</span>
                <ArrowRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </section>
      )}

      {/* STEP 3: MANUAL OR AI QUESTION BUILDER */}
      {step === 3 && (
        <section className="space-y-6">
          {/* Creation Method Tabs */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <button
              type="button"
              onClick={() => setMethod('manual')}
              className={`rounded-2xl border p-5 text-left transition-colors cursor-pointer ${
                method === 'manual'
                  ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/40'
                  : 'border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90'
              }`}
            >
              <div className="font-display text-lg font-bold text-slate-900 dark:text-white">
                {t.methodManual}
              </div>
              <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
                {t.methodManualDesc}
              </p>
            </button>

            <button
              type="button"
              onClick={() => setMethod('ai')}
              className={`rounded-2xl border p-5 text-left transition-colors cursor-pointer ${
                method === 'ai'
                  ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/40'
                  : 'border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90'
              }`}
            >
              <div className="flex items-center gap-2 font-display text-lg font-bold text-slate-900 dark:text-white">
                <Sparkles className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                <span>{t.methodAI}</span>
              </div>
              <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{t.methodAIDesc}</p>
            </button>
          </div>

          {/* AI Generation Panel */}
          {method === 'ai' && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="sm:col-span-2">
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                    {t.aiTopicLabel}
                  </label>
                  <input
                    type="text"
                    value={aiTopic}
                    onChange={(e) => setAiTopic(e.target.value)}
                    placeholder={t.aiTopicPlaceholder}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                    {t.aiProviderLabel}
                  </label>
                  <select
                    value={aiProvider}
                    onChange={(e) => setAiProvider(e.target.value as '' | AIProvider)}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
                  >
                    <option value="">{t.aiProviderDefault}</option>
                    <option value="gemini">Gemini</option>
                    <option value="openai">OpenAI</option>
                    <option value="anthropic">Anthropic</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                    {t.aiAgeGradeLabel}
                  </label>
                  <input
                    type="text"
                    value={aiAgeGrade}
                    onChange={(e) => setAiAgeGrade(e.target.value)}
                    placeholder="10-14 / 7-sinf"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                    {t.aiCustomPromptLabel}
                  </label>
                  <input
                    type="text"
                    value={aiCustomInstructions}
                    onChange={(e) => setAiCustomInstructions(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  {gameLang.toUpperCase()} · {questionCount} {t.questionsCount}
                </p>
                <button
                  type="button"
                  disabled={generating}
                  onClick={handleGenerateAI}
                  className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-base font-semibold text-white hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
                >
                  <Sparkles className="h-5 w-5" />
                  <span>{generating ? t.generatingAI : t.generateWithAIBtn}</span>
                </button>
              </div>
            </div>
          )}

          {/* Media Assets Library */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <ImageIcon className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  {t.mediaLibraryTitle}
                </h3>
              </div>
              <label className="inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3.5 py-2 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">
                <Upload className="h-4 w-4" />
                <span>{uploadingMedia ? t.loadingText : t.uploadMediaBtn}</span>
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml,audio/mpeg,audio/ogg,audio/wav"
                  className="hidden"
                  onChange={(e) => {
                    handleUploadMedia(e.target.files?.[0]);
                    e.currentTarget.value = '';
                  }}
                />
              </label>
            </div>

            {mediaAssets.length > 0 && (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {mediaAssets.slice(0, 8).map((asset) => (
                  <div
                    key={asset.id}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-2.5 space-y-1.5"
                  >
                    {asset.mime_type.startsWith('image/') ? (
                      <img
                        src={asset.data_url}
                        alt={asset.title}
                        className="h-16 w-full rounded-lg object-contain bg-white dark:bg-slate-900 p-1"
                      />
                    ) : (
                      <audio controls src={asset.data_url} className="w-full h-10" />
                    )}
                    <div className="flex items-center justify-between gap-1">
                      <span className="truncate text-xs font-medium text-slate-700 dark:text-slate-300">
                        {asset.title}
                      </span>
                      {!asset.is_builtin && (
                        <button
                          type="button"
                          onClick={() => handleDeleteMedia(asset.id)}
                          className="text-red-500 hover:text-red-700 p-0.5 cursor-pointer"
                          aria-label={t.deleteGame}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Question List (Editable for both Manual & AI Review) */}
          <div className="space-y-4">
            {questions.map((q, idx) => (
              <div
                key={q.id || idx}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 space-y-4"
              >
                <div className="flex items-center justify-between gap-4">
                  <span className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400">
                    #{idx + 1} {q.aiGenerated ? '· AI' : ''}
                  </span>
                  <div className="flex items-center gap-2">
                    {q.id && (
                      <button
                        type="button"
                        onClick={() => handleSaveQuestionEdit(idx)}
                        className="inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-slate-700 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <Save className="h-3.5 w-3.5" />
                        <span>{t.saveQuestionsBtn}</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleDeleteQuestion(idx)}
                      className="inline-flex items-center gap-1 rounded-lg border border-red-200 dark:border-red-900/60 px-3 py-1.5 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>{t.deleteGame}</span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                    {t.questionPromptLabel}
                  </label>
                  <textarea
                    rows={2}
                    value={q.prompt}
                    onChange={(e) =>
                      setQuestions((prev) =>
                        prev.map((item, i) =>
                          i === idx ? { ...item, prompt: e.target.value } : item
                        )
                      )
                    }
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-2.5 text-base text-slate-900 dark:text-white"
                  />
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {q.options.map((opt, optIdx) => (
                    <div key={optIdx} className="flex items-center gap-2">
                      <input
                        type="radio"
                        name={`correct-${idx}`}
                        checked={q.correctIndex === optIdx}
                        onChange={() =>
                          setQuestions((prev) =>
                            prev.map((item, i) =>
                              i === idx ? { ...item, correctIndex: optIdx } : item
                            )
                          )
                        }
                        aria-label={`${t.correctAnswerLabel} ${optIdx + 1}`}
                        className="h-4 w-4 accent-indigo-600 cursor-pointer shrink-0"
                      />
                      <input
                        type="text"
                        value={opt}
                        placeholder={`${t.optionLabel} ${String.fromCharCode(65 + optIdx)}`}
                        onChange={(e) =>
                          setQuestions((prev) =>
                            prev.map((item, i) => {
                              if (i !== idx) return item;
                              const nextOpts = [...item.options] as [
                                string,
                                string,
                                string,
                                string,
                              ];
                              nextOpts[optIdx] = e.target.value;
                              return { ...item, options: nextOpts };
                            })
                          )
                        }
                        className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3.5 py-2.5 text-base text-slate-900 dark:text-white"
                      />
                    </div>
                  ))}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                    {t.explanationLabel}
                  </label>
                  <input
                    type="text"
                    value={q.explanation}
                    onChange={(e) =>
                      setQuestions((prev) =>
                        prev.map((item, i) =>
                          i === idx ? { ...item, explanation: e.target.value } : item
                        )
                      )
                    }
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-2.5 text-base text-slate-900 dark:text-white"
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-3 text-base font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>{t.prevStep}</span>
              </button>
              <button
                type="button"
                onClick={() => setQuestions((prev) => [...prev, emptyQuestion()])}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-3 text-base font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <Plus className="h-4 w-4" />
                <span>{t.addQuestionBtn}</span>
              </button>
            </div>

            {hasDraftAI || method === 'ai' ? (
              <button
                type="button"
                disabled={saving || questions.length === 0}
                onClick={handleApproveAndPublish}
                className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-3 text-base font-semibold text-white hover:bg-emerald-700 disabled:opacity-50 cursor-pointer"
              >
                <CheckCircle2 className="h-5 w-5" />
                <span>{saving ? t.loadingText : t.approvePublishBtn}</span>
              </button>
            ) : (
              <button
                type="button"
                disabled={saving}
                onClick={handleSaveManualQuestions}
                className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-3 text-base font-semibold text-white hover:bg-indigo-700 disabled:opacity-50 cursor-pointer"
              >
                <CheckCircle2 className="h-5 w-5" />
                <span>{saving ? t.loadingText : t.saveQuestionsBtn}</span>
              </button>
            )}
          </div>
        </section>
      )}
    </main>
  );
}
