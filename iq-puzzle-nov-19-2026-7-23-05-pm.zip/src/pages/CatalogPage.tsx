import { useState } from 'react';
import {
  Play,
  Trophy,
  Search,
  Box,
  Volume2,
  Clock,
  Sparkles,
  X,
  AlertCircle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GAME_CATALOG, GAME_CATEGORIES } from '../games/registry';
import { apiRequest } from '../lib/api';
import { normalizeUzbekSearch, toNewUzbekAlphabet } from '../utils/uzbekAlphabet';
import type { GameCatalogEntry, GameCategoryId } from '../games/types';
import type { Difficulty } from '../types';

function GameThumbnail({ entry }: { entry: GameCatalogEntry }) {
  return (
    <div
      className="relative flex h-24 w-full items-center justify-center overflow-hidden rounded-xl border border-slate-200/80 dark:border-slate-800"
      style={{
        background: `linear-gradient(135deg, ${entry.accentColor}16 0%, ${entry.accentColor}05 100%)`,
      }}
    >
      <svg viewBox="0 0 200 84" className="h-full w-full opacity-90">
        <circle cx={34} cy={42} r={22} fill={entry.accentColor} fillOpacity={0.14} />
        <rect x={144} y={14} width={38} height={38} rx={10} fill={entry.accentColor} fillOpacity={0.12} transform="rotate(14 163 33)" />
        <polygon points="100,16 122,58 78,58" fill="none" stroke={entry.accentColor} strokeWidth={2.5} strokeOpacity={0.45} />
        <circle cx={100} cy={43} r={6} fill={entry.accentColor} />
      </svg>
      <span
        className="absolute left-3 top-2.5 font-mono text-xs font-extrabold tracking-wider"
        style={{ color: entry.accentColor }}
      >
        #{String(entry.number).padStart(2, '0')}
      </span>
      <div className="absolute right-3 top-2.5 flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
        {entry.has3D && <Box className="h-4 w-4" />}
        {entry.hasAudio && <Volume2 className="h-4 w-4" />}
      </div>
    </div>
  );
}

export function CatalogPage() {
  const { lang, user, navigate } = useApp();
  const [activeCategory, setActiveCategory] = useState<'all' | GameCategoryId>('all');
  const [search, setSearch] = useState('');

  // Quick organize competition modal for teachers
  const [compGame, setCompGame] = useState<GameCatalogEntry | null>(null);
  const [compClass, setCompClass] = useState('9-A');
  const [compDiff, setCompDiff] = useState<Difficulty>('medium');
  const [launching, setLaunching] = useState(false);
  const [error, setError] = useState('');

  const labels =
    lang === 'ru'
      ? {
          heading: 'Каталог из 25 интеллектуальных игр',
          sub: 'Выберите категорию: практикуйтесь в одиночку или организуйте соревнование для класса.',
          all: 'Все категории (25)',
          searchPlaceholder: 'Поиск игры по названию...',
          practice: 'Тренироваться',
          compete: 'Создать соревнование',
          min: 'мин',
          pts: 'баллов',
          stages: 'этапов',
          easy: 'Лёгкий',
          medium: 'Средний',
          hard: 'Сложный',
          modalTitle: 'Быстрый запуск соревнования',
          classLabel: 'Класс или группа',
          diffLabel: 'Сложность',
          launchBtn: 'Открыть комнату ожидания',
          cancel: 'Отмена',
        }
      : lang === 'en'
        ? {
            heading: '25 Intellectual Games Catalog',
            sub: 'Explore all 6 cognitive categories: train solo in Practice Mode or launch a live classroom competition.',
            all: 'All Categories (25)',
            searchPlaceholder: 'Search games...',
            practice: 'Practice',
            compete: 'Organize Competition',
            min: 'min',
            pts: 'pts',
            stages: 'stages',
            easy: 'Easy',
            medium: 'Medium',
            hard: 'Hard',
            modalTitle: 'Launch Interactive Competition',
            classLabel: 'Class or Group',
            diffLabel: 'Difficulty',
            launchBtn: 'Open Waiting Room',
            cancel: 'Cancel',
          }
        : {
            heading: toNewUzbekAlphabet("25 ta intellektual o'yinlar katalogi"),
            sub: toNewUzbekAlphabet(
              "6 ta yo'nalishdan birini tanlang: yakka tartibda mashq qiling yoki sinf uchun jonli musobaqa tashkil eting."
            ),
            all: toNewUzbekAlphabet("Barcha yo'nalishlar (25)"),
            searchPlaceholder: toNewUzbekAlphabet("O'yin nomi bo'yicha qidirish..."),
            practice: toNewUzbekAlphabet('Mashq qilish'),
            compete: toNewUzbekAlphabet('Musobaqa tashkil qilish'),
            min: toNewUzbekAlphabet('daq'),
            pts: toNewUzbekAlphabet('ball'),
            stages: toNewUzbekAlphabet('bosqich'),
            easy: toNewUzbekAlphabet('Oson'),
            medium: toNewUzbekAlphabet("O'rta"),
            hard: toNewUzbekAlphabet('Murakkab'),
            modalTitle: toNewUzbekAlphabet('Tezkor musobaqa tashkil qilish'),
            classLabel: toNewUzbekAlphabet('Sinf yoki guruh'),
            diffLabel: toNewUzbekAlphabet('Qiyinlik darajasi'),
            launchBtn: toNewUzbekAlphabet('Kutish xonasini ochish'),
            cancel: toNewUzbekAlphabet('Bekor qilish'),
          };

  const normQ = normalizeUzbekSearch(search);
  const filteredGames = GAME_CATALOG.filter((g) => {
    if (activeCategory !== 'all' && g.category !== activeCategory) return false;
    if (!normQ) return true;
    return normalizeUzbekSearch(
      `${g.name[lang]} ${g.description[lang]} ${g.typeLabel[lang]}`
    ).includes(normQ);
  });

  const handleOrganizeClick = (entry: GameCatalogEntry) => {
    if (!user) {
      navigate('/login');
      return;
    }
    setError('');
    setCompGame(entry);
  };

  const handleQuickLaunch = async () => {
    if (!compGame) return;
    setLaunching(true);
    setError('');
    try {
      const created = await apiRequest<{ game: { id: string } }>('/api/games', {
        method: 'POST',
        body: JSON.stringify({
          title: compGame.name[lang],
          language: lang,
          subject: compGame.typeLabel[lang],
          difficulty: compDiff,
          questionCount: compGame.defaultStages,
          timePerQuestion: compGame.defaultTimeSec,
          pointsPerQuestion: 100,
          totalDurationMinutes: Math.max(3, compGame.avgDurationMin + 2),
          maxStudents: 60,
          resultDisplayMode: 'live_leaderboard',
          creationMethod: 'manual',
          gameType: compGame.id,
          hintsLimit: 3,
        }),
      });

      const comp = await apiRequest<{ competition: { id: string } }>('/api/competitions', {
        method: 'POST',
        body: JSON.stringify({
          gameId: created.game.id,
          title: compGame.name[lang],
          className: compClass.trim() || 'Umumiy',
        }),
      });
      setCompGame(null);
      navigate(`/competition/${comp.competition.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create competition');
    } finally {
      setLaunching(false);
    }
  };

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 space-y-8">
      {/* Header & Search */}
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div className="max-w-2xl">
          <h1 className="font-display text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
            {labels.heading}
          </h1>
          <p className="mt-2 text-base text-slate-600 dark:text-slate-300">{labels.sub}</p>
        </div>

        <div className="relative w-full md:w-80">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={labels.searchPlaceholder}
            className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white/95 dark:bg-slate-900/95 pl-10 pr-4 py-2.5 text-base text-slate-900 dark:text-white focus:border-indigo-600 focus:outline-none"
          />
        </div>
      </div>

      {/* Category Filter Strip */}
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setActiveCategory('all')}
          className={`rounded-xl border px-4 py-2 text-sm font-semibold transition-colors cursor-pointer ${
            activeCategory === 'all'
              ? 'border-indigo-600 bg-indigo-600 text-white'
              : 'border-slate-200 dark:border-slate-700 bg-white/90 dark:bg-slate-900/90 text-slate-700 dark:text-slate-200 hover:border-indigo-400'
          }`}
        >
          {labels.all}
        </button>

        {GAME_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setActiveCategory(cat.id)}
            className={`rounded-xl border px-4 py-2 text-sm font-semibold transition-colors cursor-pointer ${
              activeCategory === cat.id
                ? 'border-indigo-600 bg-indigo-600 text-white'
                : 'border-slate-200 dark:border-slate-700 bg-white/90 dark:bg-slate-900/90 text-slate-700 dark:text-slate-200 hover:border-indigo-400'
            }`}
          >
            {cat.label[lang]}
          </button>
        ))}
      </div>

      {/* Games Grid */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
        {filteredGames.map((entry) => {
          const catMeta = GAME_CATEGORIES.find((c) => c.id === entry.category);
          return (
            <article
              key={entry.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-5 shadow-xs transition-shadow hover:shadow-md"
            >
              <div className="space-y-3.5">
                <GameThumbnail entry={entry} />

                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    {catMeta?.label[lang]} · {entry.typeLabel[lang]}
                  </p>
                  <h2 className="mt-1 font-display text-xl font-bold text-slate-900 dark:text-white">
                    {entry.name[lang]}
                  </h2>
                  <p className="mt-1.5 text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
                    {entry.description[lang]}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 font-mono text-xs sm:text-sm text-slate-500 dark:text-slate-400 tabular-nums">
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" />
                    {entry.avgDurationMin} {labels.min}
                  </span>
                  <span>·</span>
                  <span>
                    {entry.defaultStages} {labels.stages}
                  </span>
                  <span>·</span>
                  <span className="font-bold text-indigo-600 dark:text-indigo-400">
                    {entry.maxScore} {labels.pts}
                  </span>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap gap-2.5">
                <button
                  type="button"
                  onClick={() => navigate(`/practice/${entry.id}`)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 cursor-pointer whitespace-nowrap"
                >
                  <Play className="h-4 w-4" />
                  <span>{labels.practice}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleOrganizeClick(entry)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer whitespace-nowrap"
                >
                  <Trophy className="h-4 w-4 text-amber-500" />
                  <span>{labels.compete}</span>
                </button>
              </div>
            </article>
          );
        })}
      </div>

      {/* Organize Competition Modal */}
      {compGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-indigo-600" />
                <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  {labels.modalTitle}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setCompGame(null)}
                className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="font-semibold text-indigo-600 dark:text-indigo-400">
              {compGame.name[lang]}
            </p>

            {error && (
              <div className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {labels.classLabel}
              </label>
              <input
                type="text"
                value={compClass}
                onChange={(e) => setCompClass(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-2.5 text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {labels.diffLabel}
              </label>
              <select
                value={compDiff}
                onChange={(e) => setCompDiff(e.target.value as Difficulty)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-2.5 text-base text-slate-900 dark:text-white"
              >
                <option value="easy">{labels.easy}</option>
                <option value="medium">{labels.medium}</option>
                <option value="hard">{labels.hard}</option>
              </select>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setCompGame(null)}
                className="rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                {labels.cancel}
              </button>
              <button
                type="button"
                disabled={launching}
                onClick={handleQuickLaunch}
                className="rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
              >
                {labels.launchBtn}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
