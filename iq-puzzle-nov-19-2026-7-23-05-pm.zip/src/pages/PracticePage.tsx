import { useState } from 'react';
import { ArrowLeft, BarChart3, Play } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { GameRunner } from '../games/GameRunner';
import { getCatalogEntry, isGameTypeId } from '../games/registry';
import { apiRequest } from '../lib/api';
import { toNewUzbekAlphabet } from '../utils/uzbekAlphabet';
import type { CommonGameSettings, GameResultSummary } from '../games/types';
import type { Difficulty } from '../types';

export function getStoredStudentKey(): { key: string; name: string } {
  const existingKey = localStorage.getItem('iq_puzzle_student_key');
  const existingName = localStorage.getItem('iq_puzzle_student_name') || '';
  if (existingKey) return { key: existingKey, name: existingName };
  const newKey = `stu_${Math.random().toString(36).slice(2, 10)}`;
  localStorage.setItem('iq_puzzle_student_key', newKey);
  return { key: newKey, name: existingName };
}

export function PracticePage({ gameType }: { gameType: string }) {
  const { lang, user, navigate } = useApp();
  const entry = isGameTypeId(gameType) ? getCatalogEntry(gameType) : undefined;
  const stored = getStoredStudentKey();

  const [studentName, setStudentName] = useState(user?.fullName || stored.name || '');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [timerEnabled, setTimerEnabled] = useState(true);
  const [started, setStarted] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);

  if (!entry) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-12 text-center space-y-4">
        <p className="text-lg font-semibold text-slate-700 dark:text-slate-200">
          Game not found.
        </p>
        <button
          type="button"
          onClick={() => navigate('/catalog')}
          className="rounded-xl bg-indigo-600 px-5 py-2.5 text-base font-semibold text-white cursor-pointer"
        >
          Back to Catalog
        </button>
      </main>
    );
  }

  const labels =
    lang === 'ru'
      ? {
          back: 'К каталогу',
          setupTitle: 'Настройка тренировки',
          nameLabel: 'Ваше имя (для профиля результатов)',
          namePlaceholder: 'Например: Азизбек',
          diffLabel: 'Уровень сложности',
          easy: 'Лёгкий',
          medium: 'Средний',
          hard: 'Сложный',
          timerLabel: 'Таймер на этап',
          startBtn: 'Начать тренировку',
          saved: 'Результат сохранён в вашем интеллектуальном профиле!',
          openProfile: 'Открыть профиль',
        }
      : lang === 'en'
        ? {
            back: 'Back to Catalog',
            setupTitle: 'Practice Session Setup',
            nameLabel: 'Your Name (saved to your Intellectual Profile)',
            namePlaceholder: 'e.g. Azizbek',
            diffLabel: 'Difficulty Level',
            easy: 'Easy',
            medium: 'Medium',
            hard: 'Hard',
            timerLabel: 'Stage Countdown Timer',
            startBtn: 'Start Practice',
            saved: 'Result saved to your Intellectual Profile!',
            openProfile: 'Open Intellectual Profile',
          }
        : {
            back: toNewUzbekAlphabet('Katalogga qaytish'),
            setupTitle: toNewUzbekAlphabet("Mashq rejimini sozlash"),
            nameLabel: toNewUzbekAlphabet("Ismingiz (intellektual profilga saqlanadi)"),
            namePlaceholder: toNewUzbekAlphabet('Masalan: Azizbek'),
            diffLabel: toNewUzbekAlphabet('Qiyinlik darajasi'),
            easy: toNewUzbekAlphabet('Oson'),
            medium: toNewUzbekAlphabet("O'rta"),
            hard: toNewUzbekAlphabet('Murakkab'),
            timerLabel: toNewUzbekAlphabet('Bosqich taymeri'),
            startBtn: toNewUzbekAlphabet('Mashqni boshlash'),
            saved: toNewUzbekAlphabet('Natija intellektual profilingizga saqlandi!'),
            openProfile: toNewUzbekAlphabet('Profilni ochish'),
          };

  const settings: CommonGameSettings = {
    gameType: entry.id,
    title: entry.name[lang],
    language: lang,
    difficulty,
    stagesCount: entry.defaultStages,
    timePerTaskSec: entry.defaultTimeSec,
    timerEnabled,
    maxScore: entry.maxScore,
    hintsLimit: 3,
    showExplanation: true,
    seed: Date.now(),
  };

  const handleStart = () => {
    if (studentName.trim()) {
      localStorage.setItem('iq_puzzle_student_name', studentName.trim());
    }
    setSavedNotice(false);
    setStarted(true);
  };

  const handleComplete = async (result: GameResultSummary) => {
    try {
      await apiRequest('/api/practice/submit', {
        method: 'POST',
        body: JSON.stringify({
          studentKey: stored.key,
          studentName: studentName.trim() || user?.fullName || 'Guest',
          gameType: result.gameType,
          difficulty: result.difficulty,
          language: result.language,
          stagesCount: result.stages.length,
          score: result.score,
          correctCount: result.correctCount,
          wrongCount: result.wrongCount,
          hintsUsed: result.hintsUsed,
          timeSpentMs: result.timeSpentMs,
        }),
      });
      setSavedNotice(true);
    } catch {
      // non-fatal if offline
    }
  };

  if (!started) {
    return (
      <main className="mx-auto max-w-xl px-4 py-10 sm:px-6 space-y-6">
        <button
          type="button"
          onClick={() => navigate('/catalog')}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>{labels.back}</span>
        </button>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 space-y-6 shadow-sm">
          <div>
            <p className="font-mono text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              #{String(entry.number).padStart(2, '0')} · {entry.typeLabel[lang]}
            </p>
            <h1 className="mt-1 font-display text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              {entry.name[lang]}
            </h1>
            <p className="mt-2 text-base text-slate-600 dark:text-slate-300">
              {entry.description[lang]}
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {labels.nameLabel}
              </label>
              <input
                type="text"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                placeholder={labels.namePlaceholder}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {labels.diffLabel}
              </label>
              <div className="grid grid-cols-3 gap-2.5">
                {(
                  [
                    { id: 'easy', label: labels.easy },
                    { id: 'medium', label: labels.medium },
                    { id: 'hard', label: labels.hard },
                  ] as const
                ).map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => setDifficulty(d.id)}
                    className={`rounded-xl border py-2.5 text-sm font-semibold cursor-pointer ${
                      difficulty === d.id
                        ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            </div>

            <label className="flex items-center justify-between rounded-xl border border-slate-200 dark:border-slate-800 px-4 py-3 cursor-pointer">
              <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                {labels.timerLabel} ({entry.defaultTimeSec}s)
              </span>
              <input
                type="checkbox"
                checked={timerEnabled}
                onChange={(e) => setTimerEnabled(e.target.checked)}
                className="h-5 w-5 accent-indigo-600 cursor-pointer"
              />
            </label>
          </div>

          <button
            type="button"
            onClick={handleStart}
            className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-6 py-3.5 text-base font-semibold text-white hover:bg-indigo-700 cursor-pointer"
          >
            <Play className="h-5 w-5" />
            <span>{labels.startBtn}</span>
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 space-y-5">
      <GameRunner
        settings={settings}
        mode="practice"
        onGameComplete={handleComplete}
        onExit={() => navigate('/catalog')}
      />

      {savedNotice && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/40 px-5 py-4">
          <span className="text-base font-medium text-emerald-900 dark:text-emerald-100">
            {labels.saved}
          </span>
          <button
            type="button"
            onClick={() => navigate('/profile')}
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 cursor-pointer"
          >
            <BarChart3 className="h-4 w-4" />
            <span>{labels.openProfile}</span>
          </button>
        </div>
      )}
    </main>
  );
}
