import { useEffect, useState } from 'react';
import { Award, FileSpreadsheet, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiRequest, getStoredToken } from '../lib/api';
import type { CompetitionSnapshot } from '../types';

export function ResultsPage({ competitionId }: { competitionId: string }) {
  const { t, user, navigate } = useApp();
  const [snapshot, setSnapshot] = useState<CompetitionSnapshot | null>(null);
  const [error, setError] = useState('');
  const [podiumImgFailed, setPodiumImgFailed] = useState(false);

  useEffect(() => {
    apiRequest<CompetitionSnapshot>(`/api/competitions/${competitionId}/results`)
      .then(setSnapshot)
      .catch((err) => setError(err instanceof Error ? err.message : 'Unable to load results'));
  }, [competitionId]);

  const handleDownloadExcel = async () => {
    if (!snapshot) return;
    try {
      const token = getStoredToken();
      const res = await fetch(`/api/competitions/${competitionId}/export`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) throw new Error('Excel export failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `IQ_PUZZLE_${snapshot.competition.code}_results.xlsx`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Export failed');
    }
  };

  if (error) {
    return (
      <main className="mx-auto max-w-5xl px-4 py-12">
        <div className="rounded-2xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/40 p-6 text-red-700 dark:text-red-300">
          {error}
        </div>
      </main>
    );
  }

  if (!snapshot) {
    return (
      <main className="mx-auto max-w-5xl px-4 py-12 text-base text-slate-600 dark:text-slate-300">
        {t.loadingText}
      </main>
    );
  }

  const { competition, game, participants, questionsReview } = snapshot;
  const top3 = [participants[0], participants[1], participants[2]];

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 space-y-10">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <button
            type="button"
            onClick={() => navigate(user ? '/teacher' : '/')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600 cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>{t.backBtn}</span>
          </button>
          <h1 className="mt-2 font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            {competition.title}
          </h1>
          <p className="mt-1 text-base text-slate-600 dark:text-slate-300">
            {t.resultsTitle} · {game.subject} · {competition.code}
          </p>
        </div>

        {user && (
          <button
            type="button"
            onClick={handleDownloadExcel}
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-3 text-base font-semibold text-white hover:bg-emerald-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            <FileSpreadsheet className="h-5 w-5" />
            <span>{t.downloadExcel}</span>
          </button>
        )}
      </div>

      {/* Podium Banner & Top 3 */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-stretch">
        <div className="lg:col-span-5 overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-900">
          {!podiumImgFailed ? (
            <img
              src="/src/assets/images/arena_podium_art_1795032355102.jpg"
              alt="Competition Podium"
              referrerPolicy="no-referrer"
              onError={() => setPodiumImgFailed(true)}
              className="h-full min-h-[240px] w-full object-cover"
            />
          ) : (
            <div className="flex h-full min-h-[240px] items-center justify-center bg-gradient-to-br from-slate-800 to-indigo-950 p-8 text-white">
              <Award className="h-14 w-14 text-amber-400" />
            </div>
          )}
        </div>

        <div className="lg:col-span-7 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {[
            { label: t.firstPlace, p: top3[0], accent: 'border-amber-400 dark:border-amber-500/70' },
            { label: t.secondPlace, p: top3[1], accent: 'border-slate-300 dark:border-slate-600' },
            { label: t.thirdPlace, p: top3[2], accent: 'border-orange-300 dark:border-orange-700' },
          ].map((slot, i) => (
            <div
              key={i}
              className={`flex flex-col justify-between rounded-2xl border ${slot.accent} bg-white/95 dark:bg-slate-900/95 p-5 shadow-xs`}
            >
              <div>
                <p className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400">
                  {slot.label}
                </p>
                <h2 className="mt-2 font-display text-xl font-bold text-slate-900 dark:text-white truncate">
                  {slot.p ? slot.p.displayName : '—'}
                </h2>
                {slot.p && (
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                    {slot.p.className}
                  </p>
                )}
              </div>

              {slot.p && (
                <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800 font-mono tabular-nums">
                  <div className="text-2xl font-extrabold text-slate-900 dark:text-white">
                    {slot.p.score} <span className="text-sm font-normal">{t.pointsShort}</span>
                  </div>
                  <div className="mt-1 text-sm text-slate-600 dark:text-slate-300">
                    {slot.p.correctCount} {t.correctCol} · {(slot.p.totalTimeMs / 1000).toFixed(1)}s
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Full Results Table */}
      <section className="space-y-4">
        <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          {t.allParticipantsTitle}
        </h2>
        <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-sm font-semibold text-slate-600 dark:text-slate-300">
                <th className="px-5 py-3.5">{t.rankCol}</th>
                <th className="px-5 py-3.5">{t.nameCol}</th>
                <th className="px-5 py-3.5">{t.classCol}</th>
                <th className="px-5 py-3.5 text-right">{t.scoreCol}</th>
                <th className="px-5 py-3.5 text-right">{t.correctCol}</th>
                <th className="px-5 py-3.5 text-right">{t.wrongCol}</th>
                <th className="px-5 py-3.5 text-right">{t.timeCol}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-base">
              {participants.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                  <td className="px-5 py-3.5 font-mono font-bold tabular-nums text-indigo-600 dark:text-indigo-400">
                    #{p.rank}
                  </td>
                  <td className="px-5 py-3.5 font-semibold text-slate-900 dark:text-white">
                    {p.displayName}
                  </td>
                  <td className="px-5 py-3.5 text-slate-600 dark:text-slate-300">{p.className}</td>
                  <td className="px-5 py-3.5 text-right font-mono font-bold tabular-nums text-slate-900 dark:text-white">
                    {p.score}
                  </td>
                  <td className="px-5 py-3.5 text-right font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
                    {p.correctCount}
                  </td>
                  <td className="px-5 py-3.5 text-right font-mono tabular-nums text-red-600 dark:text-red-400">
                    {p.wrongCount}
                  </td>
                  <td className="px-5 py-3.5 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                    {(p.totalTimeMs / 1000).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Questions Review */}
      {questionsReview && questionsReview.length > 0 && (
        <section className="space-y-4">
          <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            {t.questionsReviewTitle}
          </h2>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {questionsReview.map((q, idx) => (
              <div
                key={q.id}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-5 space-y-3"
              >
                <p className="font-mono text-xs font-bold text-indigo-600 dark:text-indigo-400">
                  #{idx + 1}
                </p>
                <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  {q.prompt}
                </h3>
                <div className="flex items-start gap-2 text-base font-semibold text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="h-5 w-5 shrink-0 mt-0.5" />
                  <span>{q.options[q.correctIndex]}</span>
                </div>
                {q.explanation && (
                  <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300">
                    {q.explanation}
                  </p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}
    </main>
  );
}
