import { useEffect, useState } from 'react';
import { io, type Socket } from 'socket.io-client';
import { CheckCircle2, XCircle, Clock, Trophy, Users } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiRequest } from '../lib/api';
import { translations } from '../i18n/translations';
import { GameRunner } from '../games/GameRunner';
import { isGameTypeId } from '../games/registry';
import type { GameResultSummary, StageOutcome } from '../games/types';
import type { CompetitionSnapshot } from '../types';

interface AnswerAck {
  questionId: string;
  selectedIndex: number;
  isCorrect: boolean;
  pointsAwarded: number;
  correctIndex?: number;
  explanation?: string;
}

export function StudentArenaPage({ competitionId }: { competitionId: string }) {
  const { studentSession, navigate } = useApp();
  const [snapshot, setSnapshot] = useState<CompetitionSnapshot | null>(null);
  const [socketRef, setSocketRef] = useState<Socket | null>(null);
  const [remainingSec, setRemainingSec] = useState(0);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [ack, setAck] = useState<AnswerAck | null>(null);
  const [interactiveDone, setInteractiveDone] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!studentSession || studentSession.competitionId !== competitionId) {
      navigate('/');
      return;
    }

    let active = true;
    apiRequest<CompetitionSnapshot>(`/api/student/competition/${competitionId}`)
      .then((res) => {
        if (!active) return;
        setSnapshot(res);
        setRemainingSec(res.competition.remainingSec);
      })
      .catch((err) => {
        if (!active) return;
        setError(err instanceof Error ? err.message : 'Unable to load competition');
      });

    const socket = io({ path: '/socket.io' });
    setSocketRef(socket);

    socket.on('connect', () => {
      socket.emit('competition:join', {
        competitionId,
        participantId: studentSession.participantId,
      });
    });

    socket.on('competition:state', (nextSnap: CompetitionSnapshot) => {
      setSnapshot((prev) => {
        if (prev?.currentQuestion?.id !== nextSnap.currentQuestion?.id) {
          setSelectedIdx(null);
          setAck(null);
        }
        return nextSnap;
      });
      setRemainingSec(nextSnap.competition.remainingSec);
    });

    socket.on('answer:ack', (payload: AnswerAck) => {
      setAck(payload);
    });

    socket.on('competition:error', (payload: { message: string }) => {
      setError(payload.message);
    });

    return () => {
      active = false;
      socket.disconnect();
    };
  }, [competitionId, studentSession]);

  useEffect(() => {
    if (!snapshot || snapshot.competition.status !== 'active') return;
    const startedAt = snapshot.competition.questionStartedAt;
    const totalMs = snapshot.game.timePerQuestion * 1000;
    if (!startedAt) return;

    const timer = setInterval(() => {
      const left = Math.max(0, Math.ceil((totalMs - (Date.now() - startedAt)) / 1000));
      setRemainingSec(left);
    }, 250);
    return () => clearInterval(timer);
  }, [
    snapshot?.competition.status,
    snapshot?.competition.currentQuestionIndex,
    snapshot?.competition.questionStartedAt,
  ]);

  const handleAnswer = (index: number) => {
    if (
      !socketRef ||
      !snapshot?.currentQuestion ||
      !studentSession ||
      selectedIdx !== null ||
      remainingSec <= 0
    ) {
      return;
    }
    setSelectedIdx(index);
    socketRef.emit('competition:answer', {
      competitionId,
      participantId: studentSession.participantId,
      questionId: snapshot.currentQuestion.id,
      selectedIndex: index,
    });
  };

  if (error) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-12">
        <div className="rounded-2xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/40 p-6 text-red-700 dark:text-red-300">
          {error}
        </div>
      </main>
    );
  }

  if (!snapshot || !studentSession) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-12 text-center text-base text-slate-600 dark:text-slate-300">
        Loading...
      </main>
    );
  }

  // Strictly display the game UI in the game's own configured language
  const gt = translations[snapshot.game.language];
  const { competition, game, participants, currentQuestion } = snapshot;
  const me = participants.find((p) => p.id === studentSession.participantId);

  /* 1. WAITING ROOM */
  if (competition.status === 'waiting') {
    return (
      <main className="mx-auto max-w-2xl px-4 py-10 sm:px-6 space-y-6">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 text-center space-y-4 shadow-sm">
          <p className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400">
            {competition.code} · {game.subject} · {game.language.toUpperCase()}
          </p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            {gt.studentWaitingTitle}
          </h1>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300">
            {gt.studentWaitingSubtitle}
          </p>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-4 py-3 text-base">
            <span className="text-slate-500 dark:text-slate-400">{gt.yourName}: </span>
            <span className="font-bold text-slate-900 dark:text-white">
              {studentSession.displayName}
            </span>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
              {gt.participantsJoined}
            </h2>
            <span className="inline-flex items-center gap-1.5 font-mono font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
              <Users className="h-4 w-4" />
              {participants.length}
            </span>
          </div>
          <div className="mt-4 flex flex-wrap gap-2.5">
            {participants.map((p) => (
              <span
                key={p.id}
                className={`rounded-lg border px-3 py-1.5 text-sm font-medium ${
                  p.id === studentSession.participantId
                    ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-800 dark:text-indigo-200 font-semibold'
                    : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {p.displayName}
              </span>
            ))}
          </div>
        </div>
      </main>
    );
  }

  /* 2A. ACTIVE INTERACTIVE 25-GAME MATCH */
  if (
    competition.status === 'active' &&
    game.gameType &&
    game.gameType !== 'quiz' &&
    isGameTypeId(game.gameType)
  ) {
    const isFinishedParticipant = interactiveDone || Boolean(me?.finishedAt);

    if (isFinishedParticipant) {
      return (
        <main className="mx-auto max-w-2xl px-4 py-10 sm:px-6 space-y-6">
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 text-center space-y-4">
            <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-500" />
            <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
              {gt.waitingOthersNote}
            </h1>
            {me && (
              <div className="grid grid-cols-3 gap-4 pt-3 border-t border-slate-200 dark:border-slate-800 font-mono tabular-nums">
                <div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{gt.rankCol}</div>
                  <div className="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400">
                    #{me.rank}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{gt.scoreCol}</div>
                  <div className="text-2xl font-extrabold text-slate-900 dark:text-white">
                    {me.score}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{gt.correctCol}</div>
                  <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
                    {me.correctCount}
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      );
    }

    const stagesCount = game.questionCount || 5;
    return (
      <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 px-5 py-3.5">
          <div className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">
            {competition.title} · <span className="font-mono text-indigo-600 dark:text-indigo-400">{competition.code}</span>
          </div>
          <div className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
            {gt.yourScore}: {me?.score ?? 0}
          </div>
        </div>

        <GameRunner
          mode="competition"
          settings={{
            gameType: game.gameType,
            title: competition.title,
            language: game.language,
            difficulty: game.difficulty,
            stagesCount,
            timePerTaskSec: game.timePerQuestion || 30,
            timerEnabled: true,
            maxScore: stagesCount * 150,
            hintsLimit: game.hintsLimit ?? 3,
            showExplanation: game.resultDisplayMode === 'after_each',
            seed: game.seed,
          }}
          onStageComplete={(outcome: StageOutcome) => {
            socketRef?.emit('competition:game_progress', {
              competitionId,
              participantId: studentSession.participantId,
              pointsAwarded: outcome.pointsAwarded,
              isCorrect: outcome.isCorrect,
              timeTakenMs: outcome.timeTakenMs,
            });
          }}
          onGameComplete={(result: GameResultSummary) => {
            setInteractiveDone(true);
            socketRef?.emit('competition:game_complete', {
              competitionId,
              participantId: studentSession.participantId,
              stagesCount,
              score: result.score,
              correctCount: result.correctCount,
              wrongCount: result.wrongCount,
              hintsUsed: result.hintsUsed,
              timeSpentMs: result.timeSpentMs,
            });
          }}
        />
      </main>
    );
  }

  /* 2B. ACTIVE SYNCHRONIZED QUIZ */
  if (competition.status === 'active' && currentQuestion) {
    const progressPct = Math.min(
      100,
      Math.max(0, (remainingSec / Math.max(1, game.timePerQuestion)) * 100)
    );

    return (
      <main className="mx-auto max-w-3xl px-4 py-6 sm:px-6 space-y-6">
        {/* Top Metrics Strip */}
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 px-5 py-4">
          <div className="font-mono text-base font-bold text-slate-900 dark:text-white tabular-nums">
            {gt.questionNumber} {currentQuestion.index + 1} / {competition.totalQuestions}
          </div>

          <div className="flex items-center gap-5 font-mono text-base font-bold tabular-nums">
            <span className="inline-flex items-center gap-1.5 text-amber-600 dark:text-amber-400">
              <Clock className="h-5 w-5" />
              {remainingSec}s
            </span>
            <span className="text-indigo-600 dark:text-indigo-400">
              {gt.yourScore}: {me?.score ?? 0}
            </span>
          </div>
        </div>

        {/* Countdown progress bar */}
        <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
          <div
            className="h-full bg-indigo-600 transition-all duration-200"
            style={{ width: `${progressPct}%` }}
          />
        </div>

        {/* Question Card */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 space-y-6 shadow-sm">
          <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white leading-snug">
            {currentQuestion.prompt}
          </h1>

          <div className="grid grid-cols-1 gap-3.5">
            {currentQuestion.options.map((opt, idx) => {
              const isSelected = selectedIdx === idx;
              const isConfirmedCorrect = ack?.correctIndex === idx;
              const isConfirmedWrong = ack && isSelected && !ack.isCorrect;

              let btnStyle =
                'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white hover:border-indigo-500 hover:bg-indigo-50/40 dark:hover:bg-indigo-950/30';
              if (isConfirmedCorrect) {
                btnStyle =
                  'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-100';
              } else if (isConfirmedWrong) {
                btnStyle =
                  'border-red-500 bg-red-50 dark:bg-red-950/50 text-red-900 dark:text-red-100';
              } else if (isSelected) {
                btnStyle =
                  'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-950 dark:text-indigo-100';
              }

              return (
                <button
                  key={idx}
                  type="button"
                  disabled={selectedIdx !== null || remainingSec <= 0}
                  onClick={() => handleAnswer(idx)}
                  className={`flex min-h-[58px] w-full items-center gap-4 rounded-xl border px-5 py-3.5 text-left text-base sm:text-lg font-medium transition-colors cursor-pointer disabled:cursor-default ${btnStyle}`}
                >
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 font-mono text-sm font-bold text-slate-700 dark:text-slate-200">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="flex-1">{opt}</span>
                </button>
              );
            })}
          </div>

          {ack && (
            <div
              className={`rounded-xl border p-4 space-y-1.5 ${
                ack.isCorrect
                  ? 'border-emerald-200 dark:border-emerald-900 bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-100'
                  : 'border-red-200 dark:border-red-900 bg-red-50/80 dark:bg-red-950/40 text-red-900 dark:text-red-100'
              }`}
            >
              <div className="flex items-center gap-2 font-bold text-base">
                {ack.isCorrect ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-600" />
                )}
                <span>
                  {ack.isCorrect ? `${gt.correctFeedback} (+${ack.pointsAwarded})` : gt.wrongFeedback}
                </span>
              </div>
              {ack.explanation && <p className="text-sm sm:text-base">{ack.explanation}</p>}
              <p className="text-sm opacity-80 pt-1">{gt.answerSubmitted}</p>
            </div>
          )}
        </div>

        {/* Optional Live Leaderboard during play */}
        {game.resultDisplayMode === 'live_leaderboard' && (
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 p-5">
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-3">
              {gt.modeLiveLeaderboard}
            </h2>
            <div className="space-y-2">
              {participants.slice(0, 5).map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between text-base font-medium"
                >
                  <span className="text-slate-800 dark:text-slate-200">
                    #{p.rank} {p.displayName}
                  </span>
                  <span className="font-mono font-bold tabular-nums text-indigo-600 dark:text-indigo-400">
                    {p.score}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    );
  }

  /* 3. FINISHED — PERSONAL PODIUM & LINK TO FULL RESULTS */
  return (
    <main className="mx-auto max-w-3xl px-4 py-10 sm:px-6 space-y-6">
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 text-center space-y-4">
        <Trophy className="mx-auto h-12 w-12 text-amber-500" />
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
          {gt.resultsTitle}
        </h1>
        {me && (
          <div className="grid grid-cols-3 gap-4 pt-3 border-t border-slate-200 dark:border-slate-800 font-mono tabular-nums">
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{gt.rankCol}</div>
              <div className="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400">
                #{me.rank}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{gt.scoreCol}</div>
              <div className="text-2xl font-extrabold text-slate-900 dark:text-white">
                {me.score}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{gt.correctCol}</div>
              <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
                {me.correctCount}/{me.correctCount + me.wrongCount}
              </div>
            </div>
          </div>
        )}

        <div className="pt-4">
          <button
            type="button"
            onClick={() => navigate(`/results/${competition.id}`)}
            className="rounded-xl bg-indigo-600 px-6 py-3 text-base font-semibold text-white hover:bg-indigo-700 cursor-pointer"
          >
            {gt.viewResults}
          </button>
        </div>
      </div>
    </main>
  );
}
