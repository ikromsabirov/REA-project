import { useEffect, useState } from 'react';
import {
  Plus,
  Search,
  Play,
  Pencil,
  Trash2,
  FileSpreadsheet,
  Trophy,
  Users,
  AlertCircle,
  X,
  Copy,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiRequest, getStoredToken } from '../lib/api';
import { getCatalogEntry, isGameTypeId } from '../games/registry';
import { normalizeUzbekSearch } from '../utils/uzbekAlphabet';
import type { CompetitionSummary, GameRecord } from '../types';

export function TeacherDashboard() {
  const { t, lang, user, navigate } = useApp();
  const [games, setGames] = useState<GameRecord[]>([]);
  const [competitions, setCompetitions] = useState<CompetitionSummary[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Launch competition modal state
  const [launchGame, setLaunchGame] = useState<GameRecord | null>(null);
  const [compTitle, setCompTitle] = useState('');
  const [compClass, setCompClass] = useState('9-A');
  const [launching, setLaunching] = useState(false);

  // Delete confirmation modal state
  const [deleteTarget, setDeleteTarget] = useState<GameRecord | null>(null);

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      const [gRes, cRes] = await Promise.all([
        apiRequest<{ games: GameRecord[] }>('/api/games'),
        apiRequest<{ competitions: CompetitionSummary[] }>('/api/competitions'),
      ]);
      setGames(gRes.games);
      setCompetitions(cRes.competitions);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadData();
  }, [user]);

  const filteredGames = games.filter((g) => {
    const q = normalizeUzbekSearch(search);
    if (!q) return true;
    return normalizeUzbekSearch(`${g.title} ${g.subject} ${g.ai_topic || ''} ${g.game_type || ''}`).includes(q);
  });

  const handleDuplicateGame = async (gameId: string) => {
    setError('');
    try {
      const res = await apiRequest<{ game: GameRecord }>(`/api/games/${gameId}/duplicate`, {
        method: 'POST',
      });
      setGames((prev) => [res.game, ...prev]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Duplicate failed');
    }
  };

  const handleLaunchCompetition = async () => {
    if (!launchGame) return;
    setLaunching(true);
    setError('');
    try {
      const res = await apiRequest<{ competition: { id: string } }>('/api/competitions', {
        method: 'POST',
        body: JSON.stringify({
          gameId: launchGame.id,
          title: compTitle.trim() || launchGame.title,
          className: compClass.trim() || 'Umumiy',
        }),
      });
      setLaunchGame(null);
      navigate(`/competition/${res.competition.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not launch competition');
    } finally {
      setLaunching(false);
    }
  };

  const handleDeleteGame = async () => {
    if (!deleteTarget) return;
    try {
      await apiRequest(`/api/games/${deleteTarget.id}`, { method: 'DELETE' });
      setGames((prev) => prev.filter((g) => g.id !== deleteTarget.id));
      setDeleteTarget(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Delete failed');
    }
  };

  const handleDownloadExcel = async (comp: CompetitionSummary) => {
    try {
      const token = getStoredToken();
      const res = await fetch(`/api/competitions/${comp.id}/export`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) throw new Error('Excel export failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `IQ_PUZZLE_${comp.code}_results.xlsx`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Export failed');
    }
  };

  if (!user) return null;

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 space-y-10">
      {/* Header Row */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-semibold text-indigo-600 dark:text-indigo-400">
            {user.fullName}
          </p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white mt-0.5">
            {t.teacherCabinet}
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => navigate('/create')}
            className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-base font-semibold text-white hover:bg-indigo-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Plus className="h-5 w-5" />
            <span>{t.createGameBtn}</span>
          </button>
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="flex items-start gap-2.5 rounded-xl border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/40 px-4 py-3 text-base text-red-700 dark:text-red-300"
        >
          <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Search & Games Section */}
      <section className="space-y-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            {t.myGames}
          </h2>
          <div className="relative w-full sm:w-80">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t.searchGamesPlaceholder}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 pl-10 pr-4 py-2.5 text-base text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-600 focus:outline-none"
            />
          </div>
        </div>

        {loading ? (
          <p className="text-base text-slate-500 dark:text-slate-400">{t.loadingText}</p>
        ) : filteredGames.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 p-8 text-center">
            <p className="text-base text-slate-600 dark:text-slate-300">{t.noGamesYet}</p>
            <button
              type="button"
              onClick={() => navigate('/create')}
              className="mt-4 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-base font-semibold text-white hover:bg-indigo-700 cursor-pointer"
            >
              <Plus className="h-5 w-5" />
              <span>{t.createGameBtn}</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            {filteredGames.map((game) => (
              <div
                key={game.id}
                className="flex flex-col justify-between rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 shadow-xs"
              >
                <div>
                  <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
                    {game.language.toUpperCase()} ·{' '}
                    {(game.game_type && isGameTypeId(game.game_type)
                      ? getCatalogEntry(game.game_type)?.name[lang]
                      : undefined) || 'Quiz'}{' '}
                    · {game.subject} · {game.difficulty} ·{' '}
                    <span
                      className={
                        game.status === 'published'
                          ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                          : 'text-amber-600 dark:text-amber-400 font-semibold'
                      }
                    >
                      {game.status === 'published' ? t.statusPublished : t.statusDraft}
                    </span>
                  </p>
                  <h3 className="mt-1.5 font-display text-xl font-bold text-slate-900 dark:text-white">
                    {game.title}
                  </h3>
                  <p className="mt-2 font-mono text-sm text-slate-600 dark:text-slate-300 tabular-nums">
                    {game.game_type && game.game_type !== 'quiz'
                      ? game.question_count
                      : game.actual_question_count ?? game.question_count}{' '}
                    {t.questionsCount} · {game.time_per_question} {t.secondsShort} ·{' '}
                    {game.points_per_question} {t.pointsShort}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    disabled={game.status !== 'published'}
                    onClick={() => {
                      setLaunchGame(game);
                      setCompTitle(game.title);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-40 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Play className="h-4 w-4" />
                    <span>{t.organizeCompetition}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => navigate(`/edit/${game.id}`)}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Pencil className="h-4 w-4" />
                    <span>{t.editGame}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDuplicateGame(game.id)}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Copy className="h-4 w-4" />
                    <span>{t.duplicateGame}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeleteTarget(game)}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-red-200 dark:border-red-900/60 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-sm font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Trash2 className="h-4 w-4" />
                    <span>{t.deleteGame}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Competitions History */}
      <section className="space-y-4">
        <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
          {t.competitionsHistory}
        </h2>

        {competitions.length > 0 && (
          <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-sm font-semibold text-slate-600 dark:text-slate-300">
                  <th className="px-5 py-3.5">{t.gameTitleLabel}</th>
                  <th className="px-5 py-3.5">{t.competitionCodeLabel}</th>
                  <th className="px-5 py-3.5">{t.classCol}</th>
                  <th className="px-5 py-3.5 text-right">{t.totalParticipants}</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-base">
                {competitions.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="px-5 py-4 font-medium text-slate-900 dark:text-white">
                      <div>{c.title}</div>
                      <div className="text-sm text-slate-500 dark:text-slate-400">
                        {c.subject} · {c.status}
                      </div>
                    </td>
                    <td className="px-5 py-4 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                      {c.code}
                    </td>
                    <td className="px-5 py-4 text-slate-600 dark:text-slate-300">{c.class_name}</td>
                    <td className="px-5 py-4 text-right font-mono tabular-nums text-slate-700 dark:text-slate-200">
                      <span className="inline-flex items-center gap-1.5">
                        <Users className="h-4 w-4 text-slate-400" />
                        {c.participant_count ?? 0}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="inline-flex flex-wrap items-center justify-end gap-2">
                        {c.status !== 'finished' ? (
                          <button
                            type="button"
                            onClick={() => navigate(`/competition/${c.id}`)}
                            className="rounded-lg bg-indigo-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-indigo-700 cursor-pointer whitespace-nowrap"
                          >
                            {t.openLobby}
                          </button>
                        ) : (
                          <>
                            <button
                              type="button"
                              onClick={() => navigate(`/results/${c.id}`)}
                              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 px-3 py-2 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                            >
                              <Trophy className="h-4 w-4 text-amber-500" />
                              <span>{t.viewResults}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDownloadExcel(c)}
                              className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700 cursor-pointer whitespace-nowrap"
                            >
                              <FileSpreadsheet className="h-4 w-4" />
                              <span>Excel</span>
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Launch Competition Modal */}
      {launchGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                {t.organizeCompetition}
              </h3>
              <button
                type="button"
                onClick={() => setLaunchGame(null)}
                className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                  {t.gameTitleLabel}
                </label>
                <input
                  type="text"
                  value={compTitle}
                  onChange={(e) => setCompTitle(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-2.5 text-base text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                  {t.classInputPrompt}
                </label>
                <input
                  type="text"
                  value={compClass}
                  onChange={(e) => setCompClass(e.target.value)}
                  placeholder="9-A"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-2.5 text-base text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setLaunchGame(null)}
                  className="rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  {t.closeBtn}
                </button>
                <button
                  type="button"
                  disabled={launching}
                  onClick={handleLaunchCompetition}
                  className="rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
                >
                  {launching ? t.loadingText : t.organizeCompetition}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl">
            <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              {t.deleteGame}
            </h3>
            <p className="mt-2 text-base text-slate-600 dark:text-slate-300">
              {t.confirmDeleteGame} ({deleteTarget.title})
            </p>
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                {t.closeBtn}
              </button>
              <button
                type="button"
                onClick={handleDeleteGame}
                className="rounded-xl bg-red-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-red-700 cursor-pointer"
              >
                {t.deleteGame}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
