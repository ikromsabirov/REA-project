import React, { useEffect, useState } from 'react';
import { ArrowRight, QrCode, BrainCircuit, Trophy, Sparkles, AlertCircle, LayoutGrid, Radar } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiRequest } from '../lib/api';
import type { CompetitionSnapshot } from '../types';

export function HomePage({ prefillCode = '' }: { prefillCode?: string }) {
  const { t, navigate, setStudentSession, user } = useApp();

  const [name, setName] = useState('');
  const [className, setClassName] = useState('');
  const [code, setCode] = useState(prefillCode.toUpperCase());
  const [preview, setPreview] = useState<{
    title: string;
    subject: string;
    language: string;
    participantCount: number;
    maxStudents: number;
    status: string;
  } | null>(null);
  const [joining, setJoining] = useState(false);
  const [error, setError] = useState('');
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  useEffect(() => {
    if (prefillCode) {
      setCode(prefillCode.toUpperCase());
    }
  }, [prefillCode]);

  useEffect(() => {
    const clean = code.trim().toUpperCase();
    if (clean.length < 4) {
      setPreview(null);
      return;
    }
    let cancelled = false;
    apiRequest<{
      competition: {
        title: string;
        subject: string;
        language: string;
        participantCount: number;
        maxStudents: number;
        status: string;
      };
    }>(`/api/competitions/by-code/${encodeURIComponent(clean)}`)
      .then((res) => {
        if (!cancelled) setPreview(res.competition);
      })
      .catch(() => {
        if (!cancelled) setPreview(null);
      });
    return () => {
      cancelled = true;
    };
  }, [code]);

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setJoining(true);
    try {
      const res = await apiRequest<{
        participant: {
          id: string;
          displayName: string;
          className: string;
          competitionId: string;
        };
        snapshot: CompetitionSnapshot;
      }>('/api/student/join', {
        method: 'POST',
        body: JSON.stringify({
          name: name.trim(),
          code: code.trim().toUpperCase(),
          className: className.trim(),
        }),
      });

      setStudentSession({
        participantId: res.participant.id,
        competitionId: res.participant.competitionId,
        displayName: res.participant.displayName,
        className: res.participant.className,
      });
      navigate(`/play/${res.participant.competitionId}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to join competition');
    } finally {
      setJoining(false);
    }
  };

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:py-12">
      {/* 2-Column Hero Split */}
      <section className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-stretch">
        {/* Left: Editorial Copy & Student Quick-Join */}
        <div className="lg:col-span-7 flex flex-col justify-between gap-8">
          <div className="space-y-4">
            <p className="text-sm font-semibold tracking-wide text-indigo-600 dark:text-indigo-400">
              {t.heroKicker}
            </p>
            <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.12] text-balance">
              {t.heroTitle}
            </h1>
            <p className="max-w-2xl text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
              {t.heroSubtitle}
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => navigate('/catalog')}
                className="inline-flex items-center gap-2 rounded-xl bg-slate-900 dark:bg-white px-5 py-3 text-base font-semibold text-white dark:text-slate-900 hover:opacity-90 transition-opacity cursor-pointer"
              >
                <LayoutGrid className="h-5 w-5" />
                <span>{t.exploreGamesBtn}</span>
              </button>
              <button
                type="button"
                onClick={() => navigate('/profile')}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white/90 dark:bg-slate-900/90 px-5 py-3 text-base font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <Radar className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                <span>{t.navProfile}</span>
              </button>
            </div>
          </div>

          {/* Student Quick Join Card */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 shadow-sm">
            <div className="mb-5">
              <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                {t.studentJoinTitle}
              </h2>
              <p className="mt-1 text-base text-slate-600 dark:text-slate-400">
                {t.studentJoinDesc}
              </p>
            </div>

            {preview && (
              <div className="mb-5 rounded-xl border border-indigo-200 dark:border-indigo-900/70 bg-indigo-50/70 dark:bg-indigo-950/40 px-4 py-3">
                <p className="font-semibold text-indigo-950 dark:text-indigo-100 text-base">
                  {preview.title}
                </p>
                <p className="text-sm text-indigo-700 dark:text-indigo-300 mt-0.5">
                  {preview.subject} · {preview.language.toUpperCase()} · {preview.participantCount}/
                  {preview.maxStudents}
                </p>
              </div>
            )}

            {error && (
              <div
                role="alert"
                className="mb-5 flex items-start gap-2.5 rounded-xl border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/40 px-4 py-3 text-sm sm:text-base text-red-700 dark:text-red-300"
              >
                <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleJoin} className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="student-name"
                    className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5"
                  >
                    {t.studentNameLabel}
                  </label>
                  <input
                    id="student-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={t.studentNamePlaceholder}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-600/20"
                  />
                </div>

                <div>
                  <label
                    htmlFor="game-code"
                    className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5"
                  >
                    {t.gameCodeLabel}
                  </label>
                  <input
                    id="game-code"
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder={t.gameCodePlaceholder}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 font-mono text-base font-bold uppercase tracking-wider text-slate-900 dark:text-white placeholder:font-sans placeholder:font-normal placeholder:normal-case placeholder:tracking-normal placeholder:text-slate-400 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-600/20"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:items-end">
                <div>
                  <label
                    htmlFor="student-class"
                    className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5"
                  >
                    {t.studentClassLabel}
                  </label>
                  <input
                    id="student-class"
                    type="text"
                    value={className}
                    onChange={(e) => setClassName(e.target.value)}
                    placeholder={t.studentClassPlaceholder}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-600/20"
                  />
                </div>

                <button
                  type="submit"
                  disabled={joining}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 px-6 py-3.5 text-base font-semibold text-white hover:bg-indigo-700 disabled:opacity-60 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <span>{joining ? t.loadingText : t.joinNowBtn}</span>
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-sm text-slate-500 dark:text-slate-400">
                <button
                  type="button"
                  onClick={() => setCode('IQ2026')}
                  className="font-mono font-medium text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                >
                  {t.demoCodeHint}
                </button>
                <div className="flex items-center gap-4">
                  <button
                    type="button"
                    onClick={() => navigate(user ? '/teacher' : '/login')}
                    className="font-semibold text-slate-700 dark:text-slate-200 hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer"
                  >
                    {user ? t.navTeacher : t.navLogin}
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate('/leaderboard')}
                    className="font-semibold text-slate-700 dark:text-slate-200 hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer"
                  >
                    {t.navLeaderboard}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>

        {/* Right: Geometric Educational Artwork */}
        <div className="lg:col-span-5 flex flex-col">
          <div className="relative flex-1 min-h-[280px] lg:min-h-0 overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-900">
            {!heroImgFailed ? (
              <img
                src="/src/assets/images/hero_iq_puzzle_1795032354734.jpg"
                alt="IQ PUZZLE geometric reasoning visual"
                referrerPolicy="no-referrer"
                onError={() => setHeroImgFailed(true)}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full min-h-[300px] items-center justify-center bg-gradient-to-br from-indigo-950 via-slate-900 to-sky-950 p-8 text-center text-white">
                <div className="space-y-2">
                  <BrainCircuit className="mx-auto h-14 w-14 text-amber-400" />
                  <p className="font-display text-2xl font-bold">{t.brand}</p>
                </div>
              </div>
            )}
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/90 via-slate-950/50 to-transparent p-6 text-white">
              <p className="font-display text-lg font-semibold">UZ · RU · EN</p>
              <p className="text-sm text-slate-200 mt-1">
                {t.feature2Desc}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3-Column Platform Capabilities */}
      <section className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 p-6">
          <Sparkles className="h-7 w-7 text-indigo-600 dark:text-indigo-400 mb-4" />
          <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white">
            {t.feature1Title}
          </h3>
          <p className="mt-2 text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            {t.feature1Desc}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 p-6">
          <QrCode className="h-7 w-7 text-sky-600 dark:text-sky-400 mb-4" />
          <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white">
            {t.feature2Title}
          </h3>
          <p className="mt-2 text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            {t.feature2Desc}
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 p-6">
          <Trophy className="h-7 w-7 text-amber-600 dark:text-amber-400 mb-4" />
          <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white">
            {t.feature3Title}
          </h3>
          <p className="mt-2 text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            {t.feature3Desc}
          </p>
        </div>
      </section>
    </main>
  );
}
