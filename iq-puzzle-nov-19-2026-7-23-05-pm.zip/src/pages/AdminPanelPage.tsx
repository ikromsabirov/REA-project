import { useEffect, useState } from 'react';
import { ShieldCheck, KeyRound, Save, Trash2, AlertCircle, CheckCircle2, Download, Server } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiRequest, getStoredToken } from '../lib/api';
import type { AIProvider } from '../types';

interface AdminOverview {
  stats: {
    totalUsers: number;
    totalGames: number;
    totalCompetitions: number;
    totalParticipants: number;
    totalAiRequests: number;
  };
  users: Array<{
    id: string;
    full_name: string;
    login: string;
    email: string;
    role: 'teacher' | 'admin';
    is_active: number;
    created_at: string;
  }>;
  aiLogs: Array<{
    id: string;
    user_name: string;
    provider: string;
    topic: string;
    language: string;
    question_count: number;
    tokens_used: number;
    status: string;
    error_message: string | null;
    created_at: string;
  }>;
}

interface AISettingsResponse {
  activeProvider: AIProvider;
  dailyLimitPerTeacher: number;
  providers: {
    gemini: { configured: boolean; managedByServerEnv: boolean };
    openai: { configured: boolean; maskedKey: string | null };
    anthropic: { configured: boolean; maskedKey: string | null };
  };
}

export function AdminPanelPage() {
  const { t, user, lang, navigate } = useApp();
  const [overview, setOverview] = useState<AdminOverview | null>(null);
  const [settings, setSettings] = useState<AISettingsResponse | null>(null);

  const [activeProvider, setActiveProvider] = useState<AIProvider>('gemini');
  const [dailyLimit, setDailyLimit] = useState(30);
  const [openaiKeyInput, setOpenaiKeyInput] = useState('');
  const [anthropicKeyInput, setAnthropicKeyInput] = useState('');

  const [saving, setSaving] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const loadAdminData = async () => {
    try {
      const [ov, aiSet] = await Promise.all([
        apiRequest<AdminOverview>('/api/admin/overview'),
        apiRequest<AISettingsResponse>('/api/admin/ai-settings'),
      ]);
      setOverview(ov);
      setSettings(aiSet);
      setActiveProvider(aiSet.activeProvider);
      setDailyLimit(aiSet.dailyLimitPerTeacher);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load admin data');
    }
  };

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (user.role !== 'admin') {
      navigate('/teacher');
      return;
    }
    loadAdminData();
  }, [user]);

  const handleSaveSettings = async (extra?: {
    clearOpenaiKey?: boolean;
    clearAnthropicKey?: boolean;
  }) => {
    setError('');
    setSuccessMsg('');
    setSaving(true);
    try {
      await apiRequest('/api/admin/ai-settings', {
        method: 'PUT',
        body: JSON.stringify({
          activeProvider,
          dailyLimitPerTeacher: dailyLimit,
          openaiKey: openaiKeyInput.trim() || undefined,
          anthropicKey: anthropicKeyInput.trim() || undefined,
          ...extra,
        }),
      });
      setOpenaiKeyInput('');
      setAnthropicKeyInput('');
      setSuccessMsg('AI settings saved securely.');
      await loadAdminData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save AI settings');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleUser = async (targetId: string, currentActive: number) => {
    setError('');
    try {
      await apiRequest(`/api/admin/users/${targetId}/role`, {
        method: 'PATCH',
        body: JSON.stringify({ isActive: !currentActive }),
      });
      await loadAdminData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update user');
    }
  };

  const handleDownloadDeployZip = async () => {
    setError('');
    setSuccessMsg('');
    setDownloadingZip(true);
    try {
      const token = getStoredToken();
      const res = await fetch('/api/admin/export-deploy-zip', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) {
        throw new Error(`Export failed (${res.status})`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'iq-puzzle-server-deploy.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setSuccessMsg(
        lang === 'ru'
          ? 'ZIP-архив платформы с базой игр успешно скачан.'
          : lang === 'en'
            ? 'Deployment ZIP archive with the game database downloaded.'
            : 'Öyin bazasi bilan serverga joylaştiriş ZIP arxivi yuklab olindi.'
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to download ZIP');
    } finally {
      setDownloadingZip(false);
    }
  };

  if (!user || user.role !== 'admin') return null;

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 space-y-8">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
          <ShieldCheck className="h-7 w-7 text-indigo-600 dark:text-indigo-400" />
          <span>{t.adminTitle}</span>
        </h1>
        <p className="mt-1.5 text-base text-slate-600 dark:text-slate-300">{t.adminSubtitle}</p>
      </div>

      {error && (
        <div
          role="alert"
          className="flex items-start gap-2.5 rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/40 px-4 py-3 text-base text-red-700 dark:text-red-300"
        >
          <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {successMsg && (
        <div className="flex items-center gap-2 rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/40 px-4 py-3 text-base text-emerald-700 dark:text-emerald-300">
          <CheckCircle2 className="h-5 w-5 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Platform Stats */}
      {overview && (
        <section className="grid grid-cols-2 gap-4 sm:grid-cols-5">
          {[
            { label: 'Users', val: overview.stats.totalUsers },
            { label: 'Games', val: overview.stats.totalGames },
            { label: 'Competitions', val: overview.stats.totalCompetitions },
            { label: 'Participants', val: overview.stats.totalParticipants },
            { label: 'AI Requests', val: overview.stats.totalAiRequests },
          ].map((item) => (
            <div
              key={item.label}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-5"
            >
              <div className="text-sm font-medium text-slate-500 dark:text-slate-400">
                {item.label}
              </div>
              <div className="mt-1 font-mono text-3xl font-extrabold tabular-nums text-slate-900 dark:text-white">
                {item.val}
              </div>
            </div>
          ))}
        </section>
      )}

      {/* Server Deployment ZIP Export */}
      <section className="rounded-2xl border border-indigo-200 dark:border-indigo-900/60 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2.5">
            <Server className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
            <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {lang === 'ru'
                ? 'Архив для деплоя на сервер (ZIP)'
                : lang === 'en'
                  ? 'Server Deployment Archive (ZIP)'
                  : 'Serverga joylaştiriş arxivi (ZIP)'}
            </h2>
          </div>
          <p className="text-base text-slate-600 dark:text-slate-300">
            {lang === 'ru'
              ? 'Включает весь исходный код, Docker/PM2-конфиги и текущую базу игр (data/iq_puzzle.db).'
              : lang === 'en'
                ? 'Includes full source code, Docker/PM2 configs, production build, and live game database (data/iq_puzzle.db).'
                : 'Töliq frontend/backend kodi, Docker/PM2 sozlamalari, tayyor build va mavjud öyin bazasi (data/iq_puzzle.db) bilan.'}
          </p>
        </div>

        <button
          type="button"
          disabled={downloadingZip}
          onClick={handleDownloadDeployZip}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-base font-semibold text-white hover:bg-indigo-700 disabled:opacity-60 cursor-pointer shrink-0 transition-colors"
        >
          <Download className="h-5 w-5" />
          <span>
            {downloadingZip
              ? lang === 'ru'
                ? 'Сборка ZIP...'
                : lang === 'en'
                  ? 'Building ZIP...'
                  : 'ZIP tayyorlanmoqda...'
              : lang === 'ru'
                ? 'Скачать ZIP с базой'
                : lang === 'en'
                  ? 'Download Deploy ZIP'
                  : 'ZIP faylni yuklab oliş'}
          </span>
        </button>
      </section>

      {/* AI Provider & Key Management */}
      {settings && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 sm:p-8 space-y-6">
          <div className="flex items-center gap-2.5">
            <KeyRound className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
            <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {t.aiConfigTitle}
            </h2>
          </div>

          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.activeProviderLabel}
              </label>
              <select
                value={activeProvider}
                onChange={(e) => setActiveProvider(e.target.value as AIProvider)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 text-base text-slate-900 dark:text-white"
              >
                <option value="gemini">Gemini (gemini-4-hydrogen)</option>
                <option value="openai">OpenAI (gpt-4o-mini)</option>
                <option value="anthropic">Anthropic (claude-3-5-haiku)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                {t.dailyLimitLabel}
              </label>
              <input
                type="number"
                min={1}
                max={500}
                value={dailyLimit}
                onChange={(e) => setDailyLimit(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-4 py-3 font-mono text-base text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Provider Status & Masked Keys */}
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            {/* Gemini (server env managed) */}
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-display font-bold text-slate-900 dark:text-white">
                  Gemini
                </span>
                <span
                  className={`text-xs font-semibold ${
                    settings.providers.gemini.configured
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-amber-600 dark:text-amber-400'
                  }`}
                >
                  {settings.providers.gemini.configured ? t.keyConfigured : t.keyNotConfigured}
                </span>
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-400">{t.geminiServerNote}</p>
            </div>

            {/* OpenAI */}
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-display font-bold text-slate-900 dark:text-white">
                  OpenAI API
                </span>
                <span
                  className={`font-mono text-xs font-semibold ${
                    settings.providers.openai.configured
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-slate-500'
                  }`}
                >
                  {settings.providers.openai.configured
                    ? settings.providers.openai.maskedKey
                    : t.keyNotConfigured}
                </span>
              </div>
              <input
                type="password"
                value={openaiKeyInput}
                onChange={(e) => setOpenaiKeyInput(e.target.value)}
                placeholder={t.enterNewKeyPlaceholder}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm text-slate-900 dark:text-white"
              />
              {settings.providers.openai.configured && (
                <button
                  type="button"
                  onClick={() => handleSaveSettings({ clearOpenaiKey: true })}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-red-600 dark:text-red-400 hover:underline cursor-pointer"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span>{t.clearKeyBtn}</span>
                </button>
              )}
            </div>

            {/* Anthropic */}
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-display font-bold text-slate-900 dark:text-white">
                  Anthropic API
                </span>
                <span
                  className={`font-mono text-xs font-semibold ${
                    settings.providers.anthropic.configured
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-slate-500'
                  }`}
                >
                  {settings.providers.anthropic.configured
                    ? settings.providers.anthropic.maskedKey
                    : t.keyNotConfigured}
                </span>
              </div>
              <input
                type="password"
                value={anthropicKeyInput}
                onChange={(e) => setAnthropicKeyInput(e.target.value)}
                placeholder={t.enterNewKeyPlaceholder}
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm text-slate-900 dark:text-white"
              />
              {settings.providers.anthropic.configured && (
                <button
                  type="button"
                  onClick={() => handleSaveSettings({ clearAnthropicKey: true })}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-red-600 dark:text-red-400 hover:underline cursor-pointer"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span>{t.clearKeyBtn}</span>
                </button>
              )}
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="button"
              disabled={saving}
              onClick={() => handleSaveSettings()}
              className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-3 text-base font-semibold text-white hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
            >
              <Save className="h-5 w-5" />
              <span>{saving ? t.loadingText : t.saveSettingsBtn}</span>
            </button>
          </div>
        </section>
      )}

      {/* Users Management */}
      {overview && (
        <section className="space-y-4">
          <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            {t.usersManagementTitle}
          </h2>
          <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-sm font-semibold text-slate-600 dark:text-slate-300">
                  <th className="px-5 py-3.5">{t.fullNameField}</th>
                  <th className="px-5 py-3.5">{t.loginUsernameField}</th>
                  <th className="px-5 py-3.5">{t.emailField}</th>
                  <th className="px-5 py-3.5">Role</th>
                  <th className="px-5 py-3.5">Status</th>
                  <th className="px-5 py-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-base">
                {overview.users.map((u) => (
                  <tr key={u.id}>
                    <td className="px-5 py-3.5 font-semibold text-slate-900 dark:text-white">
                      {u.full_name}
                    </td>
                    <td className="px-5 py-3.5 font-mono text-sm text-slate-600 dark:text-slate-300">
                      {u.login}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600 dark:text-slate-300">{u.email}</td>
                    <td className="px-5 py-3.5 text-slate-700 dark:text-slate-200">
                      {u.role === 'admin' ? t.roleAdmin : t.roleTeacher}
                    </td>
                    <td className="px-5 py-3.5">
                      <span
                        className={
                          u.is_active
                            ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                            : 'text-red-600 dark:text-red-400 font-semibold'
                        }
                      >
                        {u.is_active ? t.activeStatus : t.disabledStatus}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      {u.id !== user.id && (
                        <button
                          type="button"
                          onClick={() => handleToggleUser(u.id, u.is_active)}
                          className="rounded-lg border border-slate-200 dark:border-slate-700 px-3 py-1.5 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          {t.toggleStatus}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* AI Usage Logs */}
      {overview && overview.aiLogs.length > 0 && (
        <section className="space-y-4">
          <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            {t.aiLogsTitle}
          </h2>
          <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-sm font-semibold text-slate-600 dark:text-slate-300">
                  <th className="px-5 py-3.5">{t.fullNameField}</th>
                  <th className="px-5 py-3.5">Provider</th>
                  <th className="px-5 py-3.5">Topic</th>
                  <th className="px-5 py-3.5">Lang</th>
                  <th className="px-5 py-3.5 text-right">Tokens</th>
                  <th className="px-5 py-3.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-sm">
                {overview.aiLogs.map((l) => (
                  <tr key={l.id}>
                    <td className="px-5 py-3 font-medium text-slate-900 dark:text-white">
                      {l.user_name}
                    </td>
                    <td className="px-5 py-3 font-mono uppercase">{l.provider}</td>
                    <td className="px-5 py-3 text-slate-700 dark:text-slate-300">{l.topic}</td>
                    <td className="px-5 py-3 font-mono uppercase">{l.language}</td>
                    <td className="px-5 py-3 text-right font-mono tabular-nums">
                      {l.tokens_used}
                    </td>
                    <td className="px-5 py-3">
                      <span
                        className={
                          l.status === 'success'
                            ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                            : 'text-red-600 dark:text-red-400 font-semibold'
                        }
                      >
                        {l.status}
                        {l.error_message ? ` — ${l.error_message}` : ''}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </main>
  );
}
