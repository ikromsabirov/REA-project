import { useEffect, useState } from 'react';
import { io, type Socket } from 'socket.io-client';
import {
  Copy,
  Check,
  Download,
  Maximize2,
  Play,
  SkipForward,
  Flag,
  Send,
  Users,
  X,
  ArrowLeft,
  Trophy,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiRequest } from '../lib/api';
import { getCatalogEntry, isGameTypeId } from '../games/registry';
import type { CompetitionSnapshot } from '../types';

export function CompetitionLobbyPage({ competitionId }: { competitionId: string }) {
  const { t, lang, user, token, navigate } = useApp();
  const [snapshot, setSnapshot] = useState<CompetitionSnapshot | null>(null);
  const [joinUrl, setJoinUrl] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [copiedKey, setCopiedKey] = useState<'code' | 'link' | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [socketRef, setSocketRef] = useState<Socket | null>(null);
  const [remainingSec, setRemainingSec] = useState(0);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!user || !token) {
      navigate('/login');
      return;
    }

    let active = true;
    apiRequest<CompetitionSnapshot & { joinUrl: string; qrDataUrl: string }>(
      `/api/competitions/${competitionId}`
    )
      .then((res) => {
        if (!active) return;
        setSnapshot(res);
        setJoinUrl(res.joinUrl);
        setQrDataUrl(res.qrDataUrl);
        setRemainingSec(res.competition.remainingSec);
      })
      .catch((err) => {
        if (!active) return;
        setError(err instanceof Error ? err.message : 'Unable to load competition');
      });

    const socket = io({ path: '/socket.io' });
    setSocketRef(socket);

    socket.on('connect', () => {
      socket.emit('competition:join', { competitionId, token });
    });

    socket.on('competition:state', (nextSnap: CompetitionSnapshot) => {
      setSnapshot(nextSnap);
      setRemainingSec(nextSnap.competition.remainingSec);
    });

    socket.on('competition:error', (payload: { message: string }) => {
      setError(payload.message);
    });

    return () => {
      active = false;
      socket.disconnect();
    };
  }, [competitionId, user, token]);

  useEffect(() => {
    if (!snapshot || snapshot.competition.status !== 'active') return;
    const startedAt = snapshot.competition.questionStartedAt;
    const totalMs = snapshot.game.timePerQuestion * 1000;
    if (!startedAt) return;

    const timer = setInterval(() => {
      const left = Math.max(0, Math.ceil((totalMs - (Date.now() - startedAt)) / 1000));
      setRemainingSec(left);
    }, 250);
    return () => clearInterval(timer);
  }, [
    snapshot?.competition.status,
    snapshot?.competition.currentQuestionIndex,
    snapshot?.competition.questionStartedAt,
  ]);

  const copyText = (text: string, key: 'code' | 'link') => {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  const downloadQrPng = () => {
    if (!qrDataUrl || !snapshot) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `IQ_PUZZLE_QR_${snapshot.competition.code}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const handleStart = () => {
    if (!socketRef || !token) return;
    socketRef.emit('competition:start', { competitionId, token });
  };

  const handleNext = () => {
    if (!socketRef || !token) return;
    socketRef.emit('competition:next', { competitionId, token });
  };

  const handleFinish = () => {
    if (!socketRef || !token) return;
    socketRef.emit('competition:finish', { competitionId, token });
  };

  if (error) {
    return (
      <main className="mx-auto max-w-4xl px-4 py-12">
        <div className="rounded-2xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/40 p-6 text-red-700 dark:text-red-300">
          {error}
        </div>
      </main>
    );
  }

  if (!snapshot) {
    return (
      <main className="mx-auto max-w-6xl px-4 py-12 text-base text-slate-600 dark:text-slate-300">
        {t.loadingText}
      </main>
    );
  }

  const { competition, game, participants, currentQuestion, answeredParticipantIds } = snapshot;
  const isInteractiveGame = Boolean(
    game.gameType && game.gameType !== 'quiz' && isGameTypeId(game.gameType)
  );
  const gameTypeLabel =
    (game.gameType && isGameTypeId(game.gameType)
      ? getCatalogEntry(game.gameType)?.name[lang]
      : undefined) || 'Quiz';

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <button
            type="button"
            onClick={() => navigate('/teacher')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600 cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>{t.teacherCabinet}</span>
          </button>
          <h1 className="mt-2 font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            {competition.title}
          </h1>
          <p className="mt-1 text-base text-slate-600 dark:text-slate-300">
            {gameTypeLabel} · {game.subject} · {game.language.toUpperCase()} ·{' '}
            {competition.className} · {competition.totalQuestions} {t.questionsCount}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {competition.status === 'waiting' && (
            <button
              type="button"
              onClick={handleStart}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-3.5 text-base font-semibold text-white hover:bg-emerald-700 transition-colors cursor-pointer"
            >
              <Play className="h-5 w-5" />
              <span>{t.startCompetitionBtn}</span>
            </button>
          )}
          {competition.status === 'active' && (
            <>
              {!isInteractiveGame && (
                <button
                  type="button"
                  onClick={handleNext}
                  className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-base font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  <SkipForward className="h-5 w-5" />
                  <span>{t.nextQuestionBtn}</span>
                </button>
              )}
              <button
                type="button"
                onClick={handleFinish}
                className="inline-flex items-center gap-2 rounded-xl border border-red-200 dark:border-red-800 bg-white dark:bg-slate-900 px-4 py-3 text-base font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 cursor-pointer"
              >
                <Flag className="h-4 w-4" />
                <span>{t.finishCompetitionBtn}</span>
              </button>
            </>
          )}
          {competition.status === 'finished' && (
            <button
              type="button"
              onClick={() => navigate(`/results/${competition.id}`)}
              className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-3 text-base font-semibold text-white hover:bg-indigo-700 cursor-pointer"
            >
              <Trophy className="h-5 w-5" />
              <span>{t.viewResults}</span>
            </button>
          )}
        </div>
      </div>

      {/* Waiting Room Join Tools (Code + Link + QR) */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6 space-y-6">
          {/* Code */}
          <div>
            <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">
              {t.competitionCodeLabel}
            </p>
            <div className="mt-2 flex items-center justify-between gap-3 rounded-xl border border-indigo-200 dark:border-indigo-900/70 bg-indigo-50/70 dark:bg-indigo-950/40 px-4 py-3">
              <span className="font-mono text-3xl sm:text-4xl font-extrabold tracking-widest text-indigo-700 dark:text-indigo-300">
                {competition.code}
              </span>
              <button
                type="button"
                onClick={() => copyText(competition.code, 'code')}
                className="inline-flex items-center gap-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 px-3 py-2 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                {copiedKey === 'code' ? (
                  <Check className="h-4 w-4 text-emerald-600" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
                <span>{copiedKey === 'code' ? t.copiedText : t.copyBtn}</span>
              </button>
            </div>
          </div>

          {/* Join Link */}
          <div>
            <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">
              {t.competitionLinkLabel}
            </p>
            <div className="mt-2 flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={joinUrl}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 font-mono text-sm text-slate-700 dark:text-slate-200"
              />
              <button
                type="button"
                onClick={() => copyText(joinUrl, 'link')}
                className="shrink-0 inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                {copiedKey === 'link' ? (
                  <Check className="h-4 w-4 text-emerald-600" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
                <span>{copiedKey === 'link' ? t.copiedText : t.copyBtn}</span>
              </button>
            </div>
            <a
              href={`https://t.me/share/url?url=${encodeURIComponent(joinUrl)}&text=${encodeURIComponent(
                `${competition.title} — ${t.competitionCodeLabel}: ${competition.code}`
              )}`}
              target="_blank"
              rel="noreferrer"
              className="mt-2.5 inline-flex items-center gap-1.5 text-sm font-semibold text-sky-600 dark:text-sky-400 hover:underline"
            >
              <Send className="h-4 w-4" />
              <span>{t.shareTelegram}</span>
            </a>
          </div>

          {/* QR Code */}
          {qrDataUrl && (
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center gap-4">
              <img
                src={qrDataUrl}
                alt={`QR ${competition.code}`}
                className="h-36 w-36 rounded-xl border border-slate-200 dark:border-slate-700 bg-white p-1.5"
              />
              <div className="flex flex-col gap-2.5 w-full">
                <button
                  type="button"
                  onClick={downloadQrPng}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
                >
                  <Download className="h-4 w-4" />
                  <span>{t.downloadQR}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowQrModal(true)}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 dark:bg-slate-100 px-4 py-2.5 text-sm font-semibold text-white dark:text-slate-900 hover:opacity-90 cursor-pointer"
                >
                  <Maximize2 className="h-4 w-4" />
                  <span>{t.enlargeQR}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right: Real-Time Participants & Active Question Monitor */}
        <div className="lg:col-span-7 space-y-6">
          {competition.status === 'active' && isInteractiveGame && (
            <div className="rounded-2xl border border-indigo-200 dark:border-indigo-900 bg-white/95 dark:bg-slate-900/95 p-6 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400">
                  {gameTypeLabel}
                </span>
                <span className="font-mono text-sm font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums">
                  {participants.filter((p) => Boolean(p.finishedAt)).length}/{participants.length}
                </span>
              </div>
              <p className="text-base text-slate-700 dark:text-slate-200">
                {t.interactiveLiveNote}
              </p>
            </div>
          )}

          {competition.status === 'active' && !isInteractiveGame && currentQuestion && (
            <div className="rounded-2xl border border-indigo-200 dark:border-indigo-900 bg-white/95 dark:bg-slate-900/95 p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <span className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400">
                  {t.questionNumber} {currentQuestion.index + 1} / {competition.totalQuestions}
                </span>
                <div className="flex items-center gap-4 font-mono text-sm font-semibold tabular-nums">
                  <span className="text-slate-600 dark:text-slate-300">
                    {t.answeredCount}: {answeredParticipantIds.length}/{participants.length}
                  </span>
                  <span className="rounded-lg bg-amber-100 dark:bg-amber-950/60 px-3 py-1 text-amber-800 dark:text-amber-300">
                    {remainingSec}s
                  </span>
                </div>
              </div>
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                {currentQuestion.prompt}
              </h2>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {currentQuestion.options.map((opt, idx) => (
                  <div
                    key={idx}
                    className={`rounded-xl border px-4 py-2.5 text-base ${
                      currentQuestion.correctIndex === idx
                        ? 'border-emerald-500 bg-emerald-50/70 dark:bg-emerald-950/30 font-semibold text-emerald-900 dark:text-emerald-200'
                        : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <span className="font-mono font-bold mr-2">
                      {String.fromCharCode(65 + idx)}.
                    </span>
                    {opt}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 p-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                {t.participantsJoined}
              </h2>
              <div className="inline-flex items-center gap-2 font-mono text-base font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
                <Users className="h-5 w-5" />
                <span>{participants.length}</span>
              </div>
            </div>

            {participants.length === 0 ? (
              <p className="py-10 text-center text-base text-slate-500 dark:text-slate-400">
                {t.waitingForStudents}
              </p>
            ) : (
              <div className="mt-4 divide-y divide-slate-200 dark:divide-slate-800">
                {participants.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between py-3 text-base gap-4"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="font-mono text-sm font-bold text-slate-400 w-6 tabular-nums">
                        #{p.rank}
                      </span>
                      <div className="truncate">
                        <span className="font-semibold text-slate-900 dark:text-white">
                          {p.displayName}
                        </span>
                        <span className="ml-2 text-sm text-slate-500 dark:text-slate-400">
                          ({p.className})
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 font-mono text-sm font-semibold tabular-nums shrink-0">
                      <span className="text-emerald-600 dark:text-emerald-400">
                        {p.correctCount}✓
                      </span>
                      <span className="text-slate-900 dark:text-white">{p.score}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Fullscreen Projector QR Modal */}
      {showQrModal && qrDataUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-6 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-3xl bg-white p-8 text-center shadow-2xl">
            <button
              type="button"
              onClick={() => setShowQrModal(false)}
              aria-label={t.closeBtn}
              className="absolute right-4 top-4 rounded-xl p-2 text-slate-500 hover:bg-slate-100 cursor-pointer"
            >
              <X className="h-6 w-6" />
            </button>
            <h3 className="font-display text-2xl font-bold text-slate-900">{competition.title}</h3>
            <p className="mt-2 font-mono text-4xl font-extrabold tracking-widest text-indigo-600">
              {competition.code}
            </p>
            <img
              src={qrDataUrl}
              alt="Large QR"
              className="mx-auto mt-6 h-72 w-72 sm:h-80 sm:w-80 rounded-2xl border border-slate-200 p-2"
            />
            <p className="mt-4 font-mono text-sm text-slate-600 break-all">{joinUrl}</p>
          </div>
        </div>
      )}
    </main>
  );
}
