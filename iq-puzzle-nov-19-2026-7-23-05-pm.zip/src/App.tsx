import { AppProvider, useApp } from './context/AppContext';
import { GeometricBackdrop } from './components/GeometricBackdrop';
import { TopNav } from './components/TopNav';
import { HomePage } from './pages/HomePage';
import { LoginPage, RegisterPage } from './pages/AuthPages';
import { TeacherDashboard } from './pages/TeacherDashboard';
import { CreateGameWizard } from './pages/CreateGameWizard';
import { CompetitionLobbyPage } from './pages/CompetitionLobbyPage';
import { StudentArenaPage } from './pages/StudentArenaPage';
import { ResultsPage } from './pages/ResultsPage';
import { LeaderboardPage } from './pages/LeaderboardPage';
import { AdminPanelPage } from './pages/AdminPanelPage';
import { CatalogPage } from './pages/CatalogPage';
import { PracticePage } from './pages/PracticePage';
import { ProfilePage } from './pages/ProfilePage';

function RouterView() {
  const { route } = useApp();

  // Match /join/:code
  if (route.startsWith('/join/')) {
    const code = decodeURIComponent(route.slice(6).split('/')[0] || '');
    return (
      <>
        <TopNav />
        <HomePage prefillCode={code} />
      </>
    );
  }

  // Match /play/:competitionId (distraction-free student mode)
  if (route.startsWith('/play/')) {
    const compId = route.slice(6).split('/')[0];
    return (
      <>
        <TopNav minimalStudentMode />
        <StudentArenaPage competitionId={compId} />
      </>
    );
  }

  // Match /competition/:id (teacher waiting room & live control)
  if (route.startsWith('/competition/')) {
    const compId = route.slice(13).split('/')[0];
    return (
      <>
        <TopNav />
        <CompetitionLobbyPage competitionId={compId} />
      </>
    );
  }

  // Match /results/:id
  if (route.startsWith('/results/')) {
    const compId = route.slice(9).split('/')[0];
    return (
      <>
        <TopNav />
        <ResultsPage competitionId={compId} />
      </>
    );
  }

  // Match /edit/:gameId
  if (route.startsWith('/edit/')) {
    const gameId = route.slice(6).split('/')[0];
    return (
      <>
        <TopNav />
        <CreateGameWizard editGameId={gameId} />
      </>
    );
  }

  // Match /practice/:gameType
  if (route.startsWith('/practice/')) {
    const gameType = route.slice(10).split('/')[0] || 'iq-matrix';
    return (
      <>
        <TopNav />
        <PracticePage gameType={gameType} />
      </>
    );
  }

  if (route === '/catalog') {
    return (
      <>
        <TopNav />
        <CatalogPage />
      </>
    );
  }

  if (route === '/profile') {
    return (
      <>
        <TopNav />
        <ProfilePage />
      </>
    );
  }

  if (route === '/login') {
    return (
      <>
        <TopNav />
        <LoginPage />
      </>
    );
  }

  if (route === '/register') {
    return (
      <>
        <TopNav />
        <RegisterPage />
      </>
    );
  }

  if (route === '/teacher') {
    return (
      <>
        <TopNav />
        <TeacherDashboard />
      </>
    );
  }

  if (route === '/create') {
    return (
      <>
        <TopNav />
        <CreateGameWizard />
      </>
    );
  }

  if (route === '/leaderboard') {
    return (
      <>
        <TopNav />
        <LeaderboardPage />
      </>
    );
  }

  if (route === '/admin') {
    return (
      <>
        <TopNav />
        <AdminPanelPage />
      </>
    );
  }

  return (
    <>
      <TopNav />
      <HomePage />
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <div className="relative min-h-screen flex flex-col">
        <GeometricBackdrop />
        <div className="flex-1">
          <RouterView />
        </div>
      </div>
    </AppProvider>
  );
}
