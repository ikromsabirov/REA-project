import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { Language, Theme, User } from '../types';
import { translations, type TranslationDict } from '../i18n/translations';
import { apiRequest, getStoredToken, setStoredToken } from '../lib/api';

interface StudentSession {
  participantId: string;
  competitionId: string;
  displayName: string;
  className: string;
}

interface AppContextValue {
  lang: Language;
  setLang: (l: Language) => void;
  t: TranslationDict;
  theme: Theme;
  toggleTheme: () => void;
  user: User | null;
  authLoading: boolean;
  token: string | null;
  loginWithToken: (token: string, user: User) => void;
  logout: () => void;
  studentSession: StudentSession | null;
  setStudentSession: (session: StudentSession | null) => void;
  route: string;
  navigate: (to: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const LANG_KEY = 'iq_puzzle_lang';
const THEME_KEY = 'iq_puzzle_theme';
const STUDENT_KEY = 'iq_puzzle_student_session';

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem(LANG_KEY);
      if (saved === 'uz' || saved === 'ru' || saved === 'en') return saved;
    } catch {
      // ignore
    }
    return 'uz';
  });

  const [theme, setTheme] = useState<Theme>(() => {
    try {
      const saved = localStorage.getItem(THEME_KEY);
      if (saved === 'dark' || saved === 'light') return saved;
    } catch {
      // ignore
    }
    return 'light';
  });

  const [token, setToken] = useState<string | null>(() => getStoredToken());
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(Boolean(getStoredToken()));
  const [route, setRoute] = useState<string>(() => window.location.pathname || '/');

  const [studentSession, setStudentSessionState] = useState<StudentSession | null>(() => {
    try {
      const raw = sessionStorage.getItem(STUDENT_KEY);
      return raw ? (JSON.parse(raw) as StudentSession) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');
    try {
      localStorage.setItem(THEME_KEY, theme);
    } catch {
      // ignore
    }
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = lang;
    try {
      localStorage.setItem(LANG_KEY, lang);
    } catch {
      // ignore
    }
  }, [lang]);

  useEffect(() => {
    const onPopState = () => {
      setRoute(window.location.pathname || '/');
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    if (!token) {
      setAuthLoading(false);
      return;
    }
    let cancelled = false;
    apiRequest<{ user: User }>('/api/auth/me')
      .then((data) => {
        if (cancelled) return;
        setUser(data.user);
        if (data.user.preferredLang) {
          setLangState(data.user.preferredLang);
        }
      })
      .catch(() => {
        if (cancelled) return;
        setStoredToken(null);
        setToken(null);
        setUser(null);
      })
      .finally(() => {
        if (!cancelled) setAuthLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [token]);

  const setLang = useCallback(
    (next: Language) => {
      setLangState(next);
      if (token) {
        apiRequest('/api/auth/preferences', {
          method: 'PATCH',
          body: JSON.stringify({ preferredLang: next }),
        }).catch(() => {});
      }
    },
    [token]
  );

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  }, []);

  const loginWithToken = useCallback((newToken: string, newUser: User) => {
    setStoredToken(newToken);
    setToken(newToken);
    setUser(newUser);
    if (newUser.preferredLang) {
      setLangState(newUser.preferredLang);
    }
  }, []);

  const logout = useCallback(() => {
    setStoredToken(null);
    setToken(null);
    setUser(null);
    setRoute('/');
    window.history.pushState({}, '', '/');
  }, []);

  const setStudentSession = useCallback((session: StudentSession | null) => {
    setStudentSessionState(session);
    try {
      if (session) sessionStorage.setItem(STUDENT_KEY, JSON.stringify(session));
      else sessionStorage.removeItem(STUDENT_KEY);
    } catch {
      // ignore
    }
  }, []);

  const navigate = useCallback((to: string) => {
    if (window.location.pathname !== to) {
      window.history.pushState({}, '', to);
    }
    setRoute(to);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return (
    <AppContext.Provider
      value={{
        lang,
        setLang,
        t: translations[lang],
        theme,
        toggleTheme,
        user,
        authLoading,
        token,
        loginWithToken,
        logout,
        studentSession,
        setStudentSession,
        route,
        navigate,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
