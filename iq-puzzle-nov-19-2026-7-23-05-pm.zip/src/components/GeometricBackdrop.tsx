export function GeometricBackdrop() {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden iq-gradient-canvas"
    >
      {/* Fine academic graph-notebook grid */}
      <svg
        className="absolute inset-0 h-full w-full text-indigo-950/[0.035] dark:text-sky-200/[0.035]"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern id="iq-notebook-grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.75" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#iq-notebook-grid)" />
      </svg>

      {/* Education, science & geometry motif layer */}
      <svg
        className="absolute inset-0 h-full w-full text-indigo-950/[0.075] dark:text-indigo-200/[0.07]"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern id="iq-edu-motifs" width="380" height="380" patternUnits="userSpaceOnUse">
            {/* Open Textbook */}
            <g transform="translate(36, 38)" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
              <path d="M 0 8 C 12 2, 24 2, 32 10 L 32 42 C 24 35, 12 35, 0 40 Z" />
              <path d="M 64 8 C 52 2, 40 2, 32 10 L 32 42 C 40 35, 52 35, 64 40 Z" />
              <line x1="8" y1="18" x2="24" y2="18" strokeWidth="1" />
              <line x1="8" y1="26" x2="24" y2="26" strokeWidth="1" />
              <line x1="40" y1="18" x2="56" y2="18" strokeWidth="1" />
              <line x1="40" y1="26" x2="56" y2="26" strokeWidth="1" />
            </g>

            {/* Academic Mortarboard / Graduation Cap */}
            <g transform="translate(230, 32)" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
              <polygon points="34,4 68,18 34,32 0,18" />
              <path d="M 14 24 L 14 38 C 24 45, 44 45, 54 38 L 54 24" />
              <line x1="64" y1="20" x2="64" y2="38" />
              <circle cx="64" cy="40" r="2.2" fill="currentColor" />
            </g>

            {/* Right Triangle with 90-degree geometry mark */}
            <g transform="translate(132, 134)" fill="none" stroke="currentColor" strokeWidth="1.3">
              <polygon points="0,56 0,0 74,56" />
              <polyline points="0,44 12,44 12,56" />
              <text x="-14" y="34" fill="currentColor" stroke="none" fontSize="14" fontFamily="serif" fontStyle="italic">
                a
              </text>
              <text x="32" y="70" fill="currentColor" stroke="none" fontSize="14" fontFamily="serif" fontStyle="italic">
                b
              </text>
              <text x="42" y="24" fill="currentColor" stroke="none" fontSize="14" fontFamily="serif" fontStyle="italic">
                c
              </text>
            </g>

            {/* Science Atom / Orbital Rings */}
            <g transform="translate(308, 178)" fill="none" stroke="currentColor" strokeWidth="1.2">
              <ellipse cx="0" cy="0" rx="28" ry="11" transform="rotate(28)" />
              <ellipse cx="0" cy="0" rx="28" ry="11" transform="rotate(-28)" />
              <ellipse cx="0" cy="0" rx="28" ry="11" transform="rotate(90)" />
              <circle cx="0" cy="0" r="3.5" fill="currentColor" />
            </g>

            {/* Protractor & Ruler Arc */}
            <g transform="translate(30, 224)" fill="none" stroke="currentColor" strokeWidth="1.3">
              <path d="M 0 38 A 34 34 0 0 1 68 38 Z" />
              <path d="M 16 38 A 18 18 0 0 1 52 38" strokeDasharray="3 3" />
              <line x1="34" y1="38" x2="34" y2="8" strokeWidth="1" />
              <line x1="34" y1="38" x2="54" y2="18" strokeWidth="1" />
            </g>

            {/* Isometric 3D Geometry Cube */}
            <g transform="translate(230, 264)" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round">
              <polygon points="28,0 56,16 56,48 28,64 0,48 0,16" />
              <polyline points="0,16 28,32 56,16" />
              <line x1="28" y1="32" x2="28" y2="64" />
            </g>

            {/* Lightbulb / Idea Icon */}
            <g transform="translate(136, 286)" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round">
              <path d="M 16 34 C 8 28, 6 16, 14 9 C 20 4, 30 4, 36 9 C 44 16, 42 28, 34 34 L 32 42 L 18 42 Z" />
              <line x1="20" y1="47" x2="30" y2="47" />
              <line x1="25" y1="0" x2="25" y2="-5" />
              <line x1="44" y1="10" x2="48" y2="7" />
              <line x1="6" y1="10" x2="2" y2="7" />
            </g>

            {/* Classical Academic Math Symbols */}
            <text x="150" y="74" fill="currentColor" fontSize="28" fontFamily="Georgia, serif">
              ∑
            </text>
            <text x="58" y="168" fill="currentColor" fontSize="26" fontFamily="Georgia, serif">
              π
            </text>
            <text x="336" y="88" fill="currentColor" fontSize="24" fontFamily="Georgia, serif">
              ∫
            </text>
            <text x="234" y="196" fill="currentColor" fontSize="24" fontFamily="Georgia, serif">
              Δ
            </text>
            <text x="64" y="346" fill="currentColor" fontSize="24" fontFamily="Georgia, serif">
              √
            </text>
            <text x="328" y="336" fill="currentColor" fontSize="24" fontFamily="Georgia, serif">
              ∞
            </text>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#iq-edu-motifs)" />
      </svg>
    </div>
  );
}
