import { useState } from 'react';
import { Menu, X, Sun, Moon, LogOut } from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { Language } from '../types';

export function TopNav({ minimalStudentMode = false }: { minimalStudentMode?: boolean }) {
  const { lang, setLang, t, theme, toggleTheme, user, logout, route, navigate } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);

  const langs: Array<{ code: Language; label: string }> = [
    { code: 'uz', label: 'UZ' },
    { code: 'ru', label: 'RU' },
    { code: 'en', label: 'EN' },
  ];

  const handleNav = (path: string) => {
    setMobileOpen(false);
    navigate(path);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 dark:border-slate-800/90 bg-white/85 dark:bg-slate-950/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 lg:gap-8 px-4 py-3.5 sm:px-6">
        {/* Zone 1: Single-element Brand Wordmark */}
        <button
          type="button"
          onClick={() => handleNav('/')}
          className="font-display text-xl font-extrabold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-indigo-600 rounded"
        >
          {t.brand}
        </button>

        {/* Zone 2: Concise single-line navigation links */}
        {!minimalStudentMode && (
          <nav className="hidden md:flex items-center gap-4 lg:gap-6 text-[16px] font-medium text-slate-600 dark:text-slate-300">
            <button
              type="button"
              onClick={() => handleNav('/')}
              className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors hover:text-indigo-600 dark:hover:text-indigo-400 ${
                route === '/' ? 'text-indigo-600 dark:text-indigo-400 font-semibold' : ''
              }`}
            >
              {t.navHome}
            </button>
            <button
              type="button"
              onClick={() => handleNav('/catalog')}
              className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors hover:text-indigo-600 dark:hover:text-indigo-400 ${
                route.startsWith('/catalog') || route.startsWith('/practice')
                  ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
                  : ''
              }`}
            >
              {t.navCatalog}
            </button>
            <button
              type="button"
              onClick={() => handleNav('/profile')}
              className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors hover:text-indigo-600 dark:hover:text-indigo-400 ${
                route === '/profile' ? 'text-indigo-600 dark:text-indigo-400 font-semibold' : ''
              }`}
            >
              {t.navProfile}
            </button>
            <button
              type="button"
              onClick={() => handleNav('/leaderboard')}
              className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors hover:text-indigo-600 dark:hover:text-indigo-400 ${
                route === '/leaderboard' ? 'text-indigo-600 dark:text-indigo-400 font-semibold' : ''
              }`}
            >
              {t.navLeaderboard}
            </button>
            {user && (
              <button
                type="button"
                onClick={() => handleNav('/teacher')}
                className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors hover:text-indigo-600 dark:hover:text-indigo-400 ${
                  route.startsWith('/teacher') || route.startsWith('/create')
                    ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
                    : ''
                }`}
              >
                {t.navTeacher}
              </button>
            )}
            {user?.role === 'admin' && (
              <button
                type="button"
                onClick={() => handleNav('/admin')}
                className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors hover:text-indigo-600 dark:hover:text-indigo-400 ${
                  route.startsWith('/admin') ? 'text-indigo-600 dark:text-indigo-400 font-semibold' : ''
                }`}
              >
                {t.navAdmin}
              </button>
            )}
          </nav>
        )}

        {/* Zone 3: Language Switcher + Theme + Primary Auth Action */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div
            role="group"
            aria-label="Language switcher"
            className="flex items-center rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100/80 dark:bg-slate-900 p-0.5"
          >
            {langs.map((item) => (
              <button
                key={item.code}
                type="button"
                onClick={() => setLang(item.code)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  lang === item.code
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={toggleTheme}
            aria-label={theme === 'light' ? 'Dark mode' : 'Light mode'}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
          >
            {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          </button>

          {!minimalStudentMode && (
            <div className="hidden md:flex items-center gap-2 shrink-0">
              {user ? (
                <button
                  type="button"
                  onClick={logout}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <LogOut className="h-4 w-4" />
                  <span>{t.navLogout}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => handleNav('/login')}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {t.navLogin}
                </button>
              )}
            </div>
          )}

          {!minimalStudentMode && (
            <button
              type="button"
              onClick={() => setMobileOpen((prev) => !prev)}
              aria-label="Menu"
              className="flex md:hidden h-10 w-10 items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 cursor-pointer"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          )}
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && !minimalStudentMode && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 py-4 space-y-2">
          <button
            type="button"
            onClick={() => handleNav('/')}
            className="block w-full text-left px-3 py-2.5 rounded-lg text-base font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900"
          >
            {t.navHome}
          </button>
          <button
            type="button"
            onClick={() => handleNav('/catalog')}
            className="block w-full text-left px-3 py-2.5 rounded-lg text-base font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900"
          >
            {t.navCatalog}
          </button>
          <button
            type="button"
            onClick={() => handleNav('/profile')}
            className="block w-full text-left px-3 py-2.5 rounded-lg text-base font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900"
          >
            {t.navProfile}
          </button>
          <button
            type="button"
            onClick={() => handleNav('/leaderboard')}
            className="block w-full text-left px-3 py-2.5 rounded-lg text-base font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900"
          >
            {t.navLeaderboard}
          </button>
          {user && (
            <button
              type="button"
              onClick={() => handleNav('/teacher')}
              className="block w-full text-left px-3 py-2.5 rounded-lg text-base font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900"
            >
              {t.navTeacher}
            </button>
          )}
          {user?.role === 'admin' && (
            <button
              type="button"
              onClick={() => handleNav('/admin')}
              className="block w-full text-left px-3 py-2.5 rounded-lg text-base font-medium text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900"
            >
              {t.navAdmin}
            </button>
          )}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
            {user ? (
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  logout();
                }}
                className="w-full rounded-lg border border-slate-200 dark:border-slate-700 px-4 py-2.5 text-base font-semibold text-slate-800 dark:text-slate-200"
              >
                {t.navLogout}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleNav('/login')}
                className="w-full rounded-lg bg-indigo-600 px-4 py-2.5 text-base font-semibold text-white"
              >
                {t.navLogin}
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
