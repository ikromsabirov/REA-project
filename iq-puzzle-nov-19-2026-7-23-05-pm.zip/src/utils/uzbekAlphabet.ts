/**
 * New Uzbek Latin Alphabet conversion & search normalization utilities.
 * Rules (applied strictly to Uzbek texts only):
 *   G‘ / g‘ -> Ğ / ğ
 *   Ch / ch -> Ç / ç
 *   O‘ / o‘ -> Ö / ö
 *   Sh / sh -> Ş / ş
 *
 * Idempotent: running toNewUzbekAlphabet twice will not alter already-converted characters.
 */

const APOSTROPHES = "['‘’ʻʼ`]";

export function toNewUzbekAlphabet(input: string): string {
  if (!input) return input;

  let result = input;

  // 1. O‘ / o‘ -> Ö / ö (with any apostrophe variant)
  result = result.replace(new RegExp(`O${APOSTROPHES}`, 'g'), 'Ö');
  result = result.replace(new RegExp(`o${APOSTROPHES}`, 'g'), 'ö');

  // 2. G‘ / g‘ -> Ğ / ğ (with any apostrophe variant)
  result = result.replace(new RegExp(`G${APOSTROPHES}`, 'g'), 'Ğ');
  result = result.replace(new RegExp(`g${APOSTROPHES}`, 'g'), 'ğ');

  // 3. Ch / ch / CH -> Ç / ç
  result = result.replace(/CH/g, 'Ç');
  result = result.replace(/Ch/g, 'Ç');
  result = result.replace(/ch/g, 'ç');

  // 4. Sh / sh / SH -> Ş / ş
  result = result.replace(/SH/g, 'Ş');
  result = result.replace(/Sh/g, 'Ş');
  result = result.replace(/sh/g, 'ş');

  return result;
}

/**
 * Applies New Uzbek Alphabet conversion only when the language is 'uz'.
 */
export function formatByLanguage(text: string, lang: 'uz' | 'ru' | 'en'): string {
  if (lang !== 'uz') return text;
  return toNewUzbekAlphabet(text);
}

/**
 * Normalizes text for search/filtering so queries written in either old Uzbek
 * ("o'quvchi", "shaxsiy") or new Uzbek ("öquvçi", "şaxsiy") match identically.
 */
export function normalizeUzbekSearch(input: string): string {
  if (!input) return '';
  return toNewUzbekAlphabet(input)
    .toLowerCase()
    .replace(/ö/g, 'o')
    .replace(/ğ/g, 'g')
    .replace(/ç/g, 'ch')
    .replace(/ş/g, 'sh')
    .replace(/['‘’ʻʼ`]/g, '');
}
