import { Server as SocketIOServer } from 'socket.io';
import type { Server as HttpServer } from 'http';
import crypto from 'crypto';
import { db } from './db.ts';
import { verifyToken } from './auth.ts';
import { deterministicSeedFromId, sanitizeSubmittedGameResult } from './gameEngine.ts';

interface CompetitionRow {
  id: string;
  game_id: string;
  teacher_id: string;
  title: string;
  class_name: string;
  code: string;
  status: 'waiting' | 'active' | 'finished';
  current_question_index: number;
  question_started_at: number | null;
  started_at: string | null;
  ended_at: string | null;
}

interface GameRow {
  id: string;
  title: string;
  language: 'uz' | 'ru' | 'en';
  subject: string;
  difficulty: string;
  question_count: number;
  time_per_question: number;
  points_per_question: number;
  total_duration_minutes: number;
  max_students: number;
  result_display_mode: 'after_each' | 'after_finish' | 'live_leaderboard';
  game_type: string;
  category: string;
  hints_limit: number;
  config_json: string;
}

interface QuestionRow {
  id: string;
  order_index: number;
  prompt: string;
  options_json: string;
  correct_index: number;
  explanation: string;
  is_approved: number;
}

interface ParticipantRow {
  id: string;
  competition_id: string;
  display_name: string;
  class_name: string;
  score: number;
  correct_count: number;
  wrong_count: number;
  total_time_ms: number;
  connected: number;
  joined_at: string;
  finished_at: string | null;
}

const activeTimers = new Map<string, NodeJS.Timeout>();

export function buildCompetitionSnapshot(competitionId: string, includeAnswers = false) {
  const comp = db
    .prepare('SELECT * FROM competitions WHERE id = ?')
    .get(competitionId) as CompetitionRow | undefined;
  if (!comp) return null;

  const game = db
    .prepare(
      `SELECT id, title, language, subject, difficulty, question_count, time_per_question, points_per_question,
              total_duration_minutes, max_students, result_display_mode, game_type, category, hints_limit, config_json
       FROM games WHERE id = ?`
    )
    .get(comp.game_id) as GameRow | undefined;
  if (!game) return null;

  const questions = db
    .prepare(
      'SELECT id, order_index, prompt, options_json, correct_index, explanation, is_approved FROM questions WHERE game_id = ? AND is_approved = 1 ORDER BY order_index ASC'
    )
    .all(comp.game_id) as unknown as QuestionRow[];

  const participants = db
    .prepare(
      `SELECT id, competition_id, display_name, class_name, score, correct_count, wrong_count, total_time_ms, connected, joined_at, finished_at
       FROM participants WHERE competition_id = ?
       ORDER BY score DESC, correct_count DESC, total_time_ms ASC, wrong_count ASC, joined_at ASC`
    )
    .all(competitionId) as unknown as ParticipantRow[];

  const currentQuestion = questions[comp.current_question_index] || null;
  const elapsedMs = comp.question_started_at ? Math.max(0, Date.now() - comp.question_started_at) : 0;
  const remainingSec =
    comp.status === 'active' && currentQuestion
      ? Math.max(0, Math.ceil((game.time_per_question * 1000 - elapsedMs) / 1000))
      : game.time_per_question;

  const answeredRows = currentQuestion
    ? (db
        .prepare('SELECT participant_id FROM answers WHERE competition_id = ? AND question_id = ?')
        .all(competitionId, currentQuestion.id) as Array<{ participant_id: string }>)
    : [];

  let parsedConfig: Record<string, unknown> = {};
  try {
    parsedConfig = JSON.parse(game.config_json || '{}') as Record<string, unknown>;
  } catch {
    parsedConfig = {};
  }

  return {
    competition: {
      id: comp.id,
      title: comp.title,
      className: comp.class_name,
      code: comp.code,
      status: comp.status,
      currentQuestionIndex: comp.current_question_index,
      totalQuestions: questions.length,
      questionStartedAt: comp.question_started_at,
      remainingSec,
      startedAt: comp.started_at,
      endedAt: comp.ended_at,
    },
    game: {
      id: game.id,
      title: game.title,
      language: game.language,
      subject: game.subject,
      difficulty: game.difficulty,
      questionCount: game.question_count,
      timePerQuestion: game.time_per_question,
      pointsPerQuestion: game.points_per_question,
      totalDurationMinutes: game.total_duration_minutes,
      maxStudents: game.max_students,
      resultDisplayMode: game.result_display_mode,
      gameType: game.game_type || 'quiz',
      category: game.category || 'logic',
      hintsLimit: game.hints_limit ?? 3,
      config: parsedConfig,
      seed: deterministicSeedFromId(comp.id),
    },
    currentQuestion: currentQuestion
      ? {
          id: currentQuestion.id,
          index: comp.current_question_index,
          prompt: currentQuestion.prompt,
          options: JSON.parse(currentQuestion.options_json) as string[],
          ...(includeAnswers || comp.status === 'finished'
            ? {
                correctIndex: currentQuestion.correct_index,
                explanation: currentQuestion.explanation,
              }
            : {}),
        }
      : null,
    answeredParticipantIds: answeredRows.map((r) => r.participant_id),
    participants: participants.map((p, idx) => ({
      rank: idx + 1,
      id: p.id,
      displayName: p.display_name,
      className: p.class_name,
      score: p.score,
      correctCount: p.correct_count,
      wrongCount: p.wrong_count,
      totalTimeMs: p.total_time_ms,
      connected: Boolean(p.connected),
      finishedAt: p.finished_at,
      joinedAt: p.joined_at,
    })),
    ...(comp.status === 'finished'
      ? {
          questionsReview: questions.map((q) => ({
            id: q.id,
            prompt: q.prompt,
            options: JSON.parse(q.options_json) as string[],
            correctIndex: q.correct_index,
            explanation: q.explanation,
          })),
        }
      : {}),
  };
}

let ioInstance: SocketIOServer | null = null;

export function broadcastCompetitionState(competitionId: string): void {
  if (!ioInstance) return;
  const studentSnapshot = buildCompetitionSnapshot(competitionId, false);
  const teacherSnapshot = buildCompetitionSnapshot(competitionId, true);
  if (studentSnapshot) {
    ioInstance.to(`comp:${competitionId}`).emit('competition:state', studentSnapshot);
  }
  if (teacherSnapshot) {
    ioInstance.to(`teacher:${competitionId}`).emit('competition:state', teacherSnapshot);
  }
}

function clearTimer(competitionId: string): void {
  const existing = activeTimers.get(competitionId);
  if (existing) {
    clearTimeout(existing);
    activeTimers.delete(competitionId);
  }
}

function scheduleQuestionAdvance(competitionId: string, timePerQuestionSec: number): void {
  clearTimer(competitionId);
  const timer = setTimeout(() => {
    advanceOrFinishCompetition(competitionId);
  }, timePerQuestionSec * 1000 + 800);
  activeTimers.set(competitionId, timer);
}

export function advanceOrFinishCompetition(competitionId: string): void {
  clearTimer(competitionId);
  const comp = db.prepare('SELECT * FROM competitions WHERE id = ?').get(competitionId) as CompetitionRow | undefined;
  if (!comp || comp.status !== 'active') return;

  const game = db
    .prepare('SELECT time_per_question, game_type FROM games WHERE id = ?')
    .get(comp.game_id) as { time_per_question: number; game_type: string } | undefined;

  if (game && game.game_type !== 'quiz') {
    finishCompetitionNow(competitionId);
    return;
  }

  const countRow = db
    .prepare('SELECT COUNT(*) as cnt FROM questions WHERE game_id = ? AND is_approved = 1')
    .get(comp.game_id) as { cnt: number };

  const nextIndex = comp.current_question_index + 1;
  if (nextIndex >= countRow.cnt) {
    finishCompetitionNow(competitionId);
  } else {
    const startedMs = Date.now();
    db.prepare(
      `UPDATE competitions SET current_question_index = ?, question_started_at = ? WHERE id = ?`
    ).run(nextIndex, startedMs, competitionId);
    broadcastCompetitionState(competitionId);
    scheduleQuestionAdvance(competitionId, game?.time_per_question || 30);
  }
}

export function finishCompetitionNow(competitionId: string): void {
  clearTimer(competitionId);
  const now = new Date().toISOString();
  db.prepare(
    `UPDATE competitions SET status = 'finished', ended_at = ?, question_started_at = NULL WHERE id = ?`
  ).run(now, competitionId);
  db.prepare(`UPDATE participants SET finished_at = ? WHERE competition_id = ? AND finished_at IS NULL`).run(
    now,
    competitionId
  );
  broadcastCompetitionState(competitionId);
}

export function setupSocketServer(httpServer: HttpServer): SocketIOServer {
  const io = new SocketIOServer(httpServer, {
    cors: { origin: '*', methods: ['GET', 'POST'] },
    path: '/socket.io',
  });
  ioInstance = io;

  io.on('connection', (socket) => {
    let joinedCompId: string | null = null;
    let joinedParticipantId: string | null = null;

    socket.on(
      'competition:join',
      (payload: { competitionId: string; participantId?: string; token?: string }) => {
        const comp = db
          .prepare('SELECT id, teacher_id FROM competitions WHERE id = ?')
          .get(payload.competitionId) as { id: string; teacher_id: string } | undefined;
        if (!comp) {
          socket.emit('competition:error', { message: 'Competition not found' });
          return;
        }

        joinedCompId = comp.id;

        if (payload.token) {
          const user = verifyToken(payload.token);
          if (user && (user.userId === comp.teacher_id || user.role === 'admin')) {
            socket.join(`teacher:${comp.id}`);
            const snap = buildCompetitionSnapshot(comp.id, true);
            if (snap) socket.emit('competition:state', snap);
            return;
          }
        }

        if (payload.participantId) {
          joinedParticipantId = payload.participantId;
          db.prepare('UPDATE participants SET connected = 1 WHERE id = ? AND competition_id = ?').run(
            payload.participantId,
            comp.id
          );
        }

        socket.join(`comp:${comp.id}`);
        broadcastCompetitionState(comp.id);
      }
    );

    socket.on('competition:start', (payload: { competitionId: string; token: string }) => {
      const user = verifyToken(payload.token);
      if (!user) {
        socket.emit('competition:error', { message: 'Unauthorized' });
        return;
      }
      const comp = db
        .prepare('SELECT * FROM competitions WHERE id = ?')
        .get(payload.competitionId) as CompetitionRow | undefined;
      if (!comp || (comp.teacher_id !== user.userId && user.role !== 'admin')) {
        socket.emit('competition:error', { message: 'Forbidden' });
        return;
      }
      const game = db
        .prepare('SELECT time_per_question, game_type, total_duration_minutes FROM games WHERE id = ?')
        .get(comp.game_id) as
        | { time_per_question: number; game_type: string; total_duration_minutes: number }
        | undefined;

      const isInteractiveGame = Boolean(game && game.game_type && game.game_type !== 'quiz');

      if (!isInteractiveGame) {
        const qCount = db
          .prepare('SELECT COUNT(*) as cnt FROM questions WHERE game_id = ? AND is_approved = 1')
          .get(comp.game_id) as { cnt: number };

        if (qCount.cnt === 0) {
          socket.emit('competition:error', { message: 'No approved questions in this game' });
          return;
        }
      }

      const nowIso = new Date().toISOString();
      const startMs = Date.now();
      db.prepare(
        `UPDATE competitions SET status = 'active', current_question_index = 0, question_started_at = ?, started_at = ? WHERE id = ?`
      ).run(startMs, nowIso, comp.id);

      broadcastCompetitionState(comp.id);

      if (!isInteractiveGame) {
        scheduleQuestionAdvance(comp.id, game?.time_per_question || 30);
      } else {
        // Guard timer for full interactive match duration
        clearTimer(comp.id);
        const maxMs = Math.max(2, game?.total_duration_minutes || 10) * 60 * 1000;
        const guardTimer = setTimeout(() => finishCompetitionNow(comp.id), maxMs);
        activeTimers.set(comp.id, guardTimer);
      }
    });

    socket.on('competition:next', (payload: { competitionId: string; token: string }) => {
      const user = verifyToken(payload.token);
      if (!user) return;
      const comp = db
        .prepare('SELECT teacher_id FROM competitions WHERE id = ?')
        .get(payload.competitionId) as { teacher_id: string } | undefined;
      if (!comp || (comp.teacher_id !== user.userId && user.role !== 'admin')) return;
      advanceOrFinishCompetition(payload.competitionId);
    });

    socket.on('competition:finish', (payload: { competitionId: string; token: string }) => {
      const user = verifyToken(payload.token);
      if (!user) return;
      const comp = db
        .prepare('SELECT teacher_id FROM competitions WHERE id = ?')
        .get(payload.competitionId) as { teacher_id: string } | undefined;
      if (!comp || (comp.teacher_id !== user.userId && user.role !== 'admin')) return;
      finishCompetitionNow(payload.competitionId);
    });

    socket.on(
      'competition:answer',
      (payload: {
        competitionId: string;
        participantId: string;
        questionId: string;
        selectedIndex: number;
      }) => {
        const comp = db
          .prepare('SELECT * FROM competitions WHERE id = ?')
          .get(payload.competitionId) as CompetitionRow | undefined;
        if (!comp || comp.status !== 'active') return;

        const participant = db
          .prepare('SELECT * FROM participants WHERE id = ? AND competition_id = ?')
          .get(payload.participantId, comp.id) as ParticipantRow | undefined;
        if (!participant) return;

        const game = db
          .prepare('SELECT time_per_question, points_per_question, result_display_mode FROM games WHERE id = ?')
          .get(comp.game_id) as {
          time_per_question: number;
          points_per_question: number;
          result_display_mode: string;
        };

        const questions = db
          .prepare(
            'SELECT * FROM questions WHERE game_id = ? AND is_approved = 1 ORDER BY order_index ASC'
          )
          .all(comp.game_id) as unknown as QuestionRow[];
        const currentQ = questions[comp.current_question_index];
        if (!currentQ || currentQ.id !== payload.questionId) return;

        const existingAnswer = db
          .prepare('SELECT id FROM answers WHERE participant_id = ? AND question_id = ?')
          .get(participant.id, currentQ.id);
        if (existingAnswer) return;

        const timeLimitMs = game.time_per_question * 1000;
        const timeTakenMs = comp.question_started_at
          ? Math.min(timeLimitMs, Math.max(200, Date.now() - comp.question_started_at))
          : timeLimitMs;

        const isCorrect = Number(payload.selectedIndex) === currentQ.correct_index ? 1 : 0;
        let pointsAwarded = 0;
        if (isCorrect) {
          const speedRatio = Math.max(0, (timeLimitMs - timeTakenMs) / timeLimitMs);
          const speedBonus = Math.round(game.points_per_question * 0.25 * speedRatio);
          pointsAwarded = game.points_per_question + speedBonus;
        }

        db.prepare(
          `INSERT INTO answers (id, competition_id, participant_id, question_id, selected_index, is_correct, points_awarded, time_taken_ms, answered_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(
          crypto.randomUUID(),
          comp.id,
          participant.id,
          currentQ.id,
          Number(payload.selectedIndex),
          isCorrect,
          pointsAwarded,
          timeTakenMs,
          new Date().toISOString()
        );

        db.prepare(
          `UPDATE participants
           SET score = score + ?,
               correct_count = correct_count + ?,
               wrong_count = wrong_count + ?,
               total_time_ms = total_time_ms + ?
           WHERE id = ?`
        ).run(pointsAwarded, isCorrect, isCorrect ? 0 : 1, timeTakenMs, participant.id);

        socket.emit('answer:ack', {
          questionId: currentQ.id,
          selectedIndex: Number(payload.selectedIndex),
          isCorrect: Boolean(isCorrect),
          pointsAwarded,
          ...(game.result_display_mode === 'after_each'
            ? {
                correctIndex: currentQ.correct_index,
                explanation: currentQ.explanation,
              }
            : {}),
        });

        broadcastCompetitionState(comp.id);
      }
    );

    // Live interactive 25-game stage progress & completion events
    socket.on(
      'competition:game_progress',
      (payload: {
        competitionId: string;
        participantId: string;
        pointsAwarded: number;
        isCorrect: boolean;
        timeTakenMs: number;
      }) => {
        const comp = db
          .prepare('SELECT id, status FROM competitions WHERE id = ?')
          .get(payload.competitionId) as { id: string; status: string } | undefined;
        if (!comp || comp.status !== 'active') return;

        const safePts = Math.max(0, Math.min(150, Math.round(Number(payload.pointsAwarded) || 0)));
        const safeTime = Math.max(100, Math.min(300000, Math.round(Number(payload.timeTakenMs) || 0)));
        const isCorrect = payload.isCorrect ? 1 : 0;

        db.prepare(
          `UPDATE participants
           SET score = score + ?,
               correct_count = correct_count + ?,
               wrong_count = wrong_count + ?,
               total_time_ms = total_time_ms + ?
           WHERE id = ? AND competition_id = ?`
        ).run(safePts, isCorrect, isCorrect ? 0 : 1, safeTime, payload.participantId, comp.id);

        broadcastCompetitionState(comp.id);
      }
    );

    socket.on(
      'competition:game_complete',
      (payload: {
        competitionId: string;
        participantId: string;
        stagesCount: number;
        score: number;
        correctCount: number;
        wrongCount: number;
        hintsUsed: number;
        timeSpentMs: number;
      }) => {
        const comp = db
          .prepare('SELECT id, status FROM competitions WHERE id = ?')
          .get(payload.competitionId) as { id: string; status: string } | undefined;
        if (!comp || comp.status === 'waiting') return;

        const safe = sanitizeSubmittedGameResult({
          stagesCount: Number(payload.stagesCount) || 5,
          correctCount: Number(payload.correctCount) || 0,
          wrongCount: Number(payload.wrongCount) || 0,
          hintsUsed: Number(payload.hintsUsed) || 0,
          timeSpentMs: Number(payload.timeSpentMs) || 1000,
          reportedScore: Number(payload.score) || 0,
        });

        db.prepare(
          `UPDATE participants
           SET score = ?,
               correct_count = ?,
               wrong_count = ?,
               total_time_ms = ?,
               finished_at = ?
           WHERE id = ? AND competition_id = ?`
        ).run(
          safe.score,
          safe.correctCount,
          safe.wrongCount,
          safe.timeSpentMs,
          new Date().toISOString(),
          payload.participantId,
          comp.id
        );

        broadcastCompetitionState(comp.id);

        // If all connected participants finished, mark competition finished
        const pending = db
          .prepare(
            'SELECT COUNT(*) as cnt FROM participants WHERE competition_id = ? AND connected = 1 AND finished_at IS NULL'
          )
          .get(comp.id) as { cnt: number };
        if (pending.cnt === 0) {
          finishCompetitionNow(comp.id);
        }
      }
    );

    socket.on('disconnect', () => {
      if (joinedCompId && joinedParticipantId) {
        db.prepare('UPDATE participants SET connected = 0 WHERE id = ? AND competition_id = ?').run(
          joinedParticipantId,
          joinedCompId
        );
        broadcastCompetitionState(joinedCompId);
      }
    });
  });

  return io;
}
