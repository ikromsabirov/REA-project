import { DatabaseSync } from 'node:sqlite';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { hashPassword } from './auth.ts';
import { toNewUzbekAlphabet } from '../src/utils/uzbekAlphabet.ts';

const dataDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'iq_puzzle.db');
export const db = new DatabaseSync(dbPath);

db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA journal_mode = WAL;');

function ensureColumn(table: string, column: string, definition: string): void {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
  if (!cols.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

export function initDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      full_name TEXT NOT NULL,
      login TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'teacher',
      preferred_lang TEXT NOT NULL DEFAULT 'uz',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS games (
      id TEXT PRIMARY KEY,
      teacher_id TEXT NOT NULL,
      title TEXT NOT NULL,
      language TEXT NOT NULL DEFAULT 'uz',
      subject TEXT NOT NULL,
      difficulty TEXT NOT NULL DEFAULT 'medium',
      question_count INTEGER NOT NULL DEFAULT 5,
      time_per_question INTEGER NOT NULL DEFAULT 30,
      points_per_question INTEGER NOT NULL DEFAULT 100,
      total_duration_minutes INTEGER NOT NULL DEFAULT 10,
      max_students INTEGER NOT NULL DEFAULT 50,
      scheduled_at TEXT,
      result_display_mode TEXT NOT NULL DEFAULT 'after_each',
      creation_method TEXT NOT NULL DEFAULT 'manual',
      status TEXT NOT NULL DEFAULT 'published',
      ai_topic TEXT,
      ai_provider TEXT,
      game_type TEXT NOT NULL DEFAULT 'quiz',
      category TEXT NOT NULL DEFAULT 'logic',
      hints_limit INTEGER NOT NULL DEFAULT 3,
      config_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS questions (
      id TEXT PRIMARY KEY,
      game_id TEXT NOT NULL,
      order_index INTEGER NOT NULL,
      prompt TEXT NOT NULL,
      options_json TEXT NOT NULL,
      correct_index INTEGER NOT NULL,
      explanation TEXT NOT NULL DEFAULT '',
      is_approved INTEGER NOT NULL DEFAULT 1,
      ai_generated INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS competitions (
      id TEXT PRIMARY KEY,
      game_id TEXT NOT NULL,
      teacher_id TEXT NOT NULL,
      title TEXT NOT NULL,
      class_name TEXT NOT NULL DEFAULT 'Umumiy',
      code TEXT NOT NULL UNIQUE,
      status TEXT NOT NULL DEFAULT 'waiting',
      current_question_index INTEGER NOT NULL DEFAULT 0,
      question_started_at INTEGER,
      started_at TEXT,
      ended_at TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE,
      FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS participants (
      id TEXT PRIMARY KEY,
      competition_id TEXT NOT NULL,
      display_name TEXT NOT NULL,
      class_name TEXT NOT NULL DEFAULT 'Umumiy',
      score INTEGER NOT NULL DEFAULT 0,
      correct_count INTEGER NOT NULL DEFAULT 0,
      wrong_count INTEGER NOT NULL DEFAULT 0,
      total_time_ms INTEGER NOT NULL DEFAULT 0,
      connected INTEGER NOT NULL DEFAULT 1,
      joined_at TEXT NOT NULL,
      finished_at TEXT,
      FOREIGN KEY (competition_id) REFERENCES competitions(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS answers (
      id TEXT PRIMARY KEY,
      competition_id TEXT NOT NULL,
      participant_id TEXT NOT NULL,
      question_id TEXT NOT NULL,
      selected_index INTEGER NOT NULL,
      is_correct INTEGER NOT NULL,
      points_awarded INTEGER NOT NULL,
      time_taken_ms INTEGER NOT NULL,
      answered_at TEXT NOT NULL,
      UNIQUE (participant_id, question_id),
      FOREIGN KEY (competition_id) REFERENCES competitions(id) ON DELETE CASCADE,
      FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE,
      FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS practice_results (
      id TEXT PRIMARY KEY,
      student_key TEXT NOT NULL,
      student_name TEXT NOT NULL,
      game_type TEXT NOT NULL,
      category TEXT NOT NULL,
      difficulty TEXT NOT NULL,
      language TEXT NOT NULL,
      score INTEGER NOT NULL,
      max_score INTEGER NOT NULL,
      correct_count INTEGER NOT NULL,
      wrong_count INTEGER NOT NULL,
      hints_used INTEGER NOT NULL DEFAULT 0,
      time_spent_ms INTEGER NOT NULL DEFAULT 0,
      accuracy INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS media_assets (
      id TEXT PRIMARY KEY,
      owner_id TEXT,
      title TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      byte_size INTEGER NOT NULL,
      data_url TEXT NOT NULL,
      is_builtin INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ai_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      active_provider TEXT NOT NULL DEFAULT 'gemini',
      openai_key_enc TEXT,
      anthropic_key_enc TEXT,
      custom_endpoint TEXT,
      custom_key_enc TEXT,
      daily_limit_per_teacher INTEGER NOT NULL DEFAULT 30,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ai_usage_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      provider TEXT NOT NULL,
      topic TEXT NOT NULL,
      language TEXT NOT NULL,
      question_count INTEGER NOT NULL,
      tokens_used INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL,
      error_message TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_games_teacher ON games(teacher_id);
    CREATE INDEX IF NOT EXISTS idx_questions_game ON questions(game_id, order_index);
    CREATE INDEX IF NOT EXISTS idx_comp_code ON competitions(code);
    CREATE INDEX IF NOT EXISTS idx_part_comp ON participants(competition_id);
    CREATE INDEX IF NOT EXISTS idx_answers_part ON answers(participant_id);
    CREATE INDEX IF NOT EXISTS idx_practice_student ON practice_results(student_key, created_at);
  `);

  // Safe migrations for pre-existing databases
  ensureColumn('games', 'game_type', "TEXT NOT NULL DEFAULT 'quiz'");
  ensureColumn('games', 'category', "TEXT NOT NULL DEFAULT 'logic'");
  ensureColumn('games', 'hints_limit', 'INTEGER NOT NULL DEFAULT 3');
  ensureColumn('games', 'config_json', "TEXT NOT NULL DEFAULT '{}'");

  const now = new Date().toISOString();

  // Ensure ai_settings singleton row exists
  const existingSettings = db.prepare('SELECT id FROM ai_settings WHERE id = 1').get();
  if (!existingSettings) {
    db.prepare(
      `INSERT INTO ai_settings (id, active_provider, daily_limit_per_teacher, updated_at)
       VALUES (1, 'gemini', 30, ?)`
    ).run(now);
  }

  // Seed built-in SVG media assets if empty
  const mediaCnt = db.prepare('SELECT COUNT(*) as cnt FROM media_assets WHERE is_builtin = 1').get() as {
    cnt: number;
  };
  if (mediaCnt.cnt === 0) {
    const builtins = [
      {
        title: 'Geometrik Matritsa',
        svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" rx="16" fill="#eef2ff"/><circle cx="36" cy="36" r="16" fill="#4f46e5"/><rect x="68" y="20" width="32" height="32" rx="6" fill="#0284c7"/><polygon points="36,66 54,98 18,98" fill="#059669"/><polygon points="84,64 100,84 84,104 68,84" fill="#d97706"/></svg>`,
      },
      {
        title: '3D Kub Yoyilmasi',
        svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" rx="16" fill="#fffbeb"/><g fill="#f59e0b" stroke="#92400e" stroke-width="2"><rect x="46" y="14" width="24" height="24"/><rect x="22" y="38" width="24" height="24"/><rect x="46" y="38" width="24" height="24"/><rect x="70" y="38" width="24" height="24"/><rect x="46" y="62" width="24" height="24"/><rect x="46" y="86" width="24" height="24"/></g></svg>`,
      },
      {
        title: 'Matematik Piramida',
        svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" rx="16" fill="#f5f3ff"/><g fill="#7c3aed" stroke="#ffffff" stroke-width="2"><rect x="44" y="20" width="32" height="22" rx="4"/><rect x="28" y="46" width="32" height="22" rx="4"/><rect x="60" y="46" width="32" height="22" rx="4"/><rect x="12" y="72" width="32" height="22" rx="4"/><rect x="44" y="72" width="32" height="22" rx="4"/><rect x="76" y="72" width="32" height="22" rx="4"/></g></svg>`,
      },
      {
        title: 'Mantiqiy Zanjir',
        svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" rx="16" fill="#ecfdf5"/><circle cx="28" cy="60" r="14" fill="#10b981"/><circle cx="60" cy="60" r="14" fill="#059669"/><circle cx="92" cy="60" r="14" fill="#047857"/><line x1="42" y1="60" x2="46" y2="60" stroke="#064e3b" stroke-width="4"/><line x1="74" y1="60" x2="78" y2="60" stroke="#064e3b" stroke-width="4"/></svg>`,
      },
    ];
    builtins.forEach((b) => {
      const dataUrl = `data:image/svg+xml;utf8,${encodeURIComponent(b.svg)}`;
      db.prepare(
        `INSERT INTO media_assets (id, owner_id, title, mime_type, byte_size, data_url, is_builtin, created_at)
         VALUES (?, NULL, ?, 'image/svg+xml', ?, ?, 1, ?)`
      ).run(crypto.randomUUID(), b.title, Buffer.byteLength(dataUrl), dataUrl, now);
    });
  }

  // Seed initial demo accounts and games only when users table is empty
  const userCountRow = db.prepare('SELECT COUNT(*) as cnt FROM users').get() as { cnt: number };
  if (userCountRow.cnt === 0) {
    const adminId = crypto.randomUUID();
    const teacherId = crypto.randomUUID();

    db.prepare(
      `INSERT INTO users (id, full_name, login, email, password_hash, role, preferred_lang, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      adminId,
      toNewUzbekAlphabet('Bosh Administrator'),
      'admin',
      'admin@iqpuzzle.uz',
      hashPassword('Admin123!'),
      'admin',
      'uz',
      now
    );

    db.prepare(
      `INSERT INTO users (id, full_name, login, email, password_hash, role, preferred_lang, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      teacherId,
      toNewUzbekAlphabet('Dilshodbek Karimov'),
      'ustoz',
      'teacher@iqpuzzle.uz',
      hashPassword('Teacher123!'),
      'teacher',
      'uz',
      now
    );

    // 1. Uzbek game (New Uzbek Alphabet)
    const uzGameId = crypto.randomUUID();
    db.prepare(
      `INSERT INTO games (id, teacher_id, title, language, subject, difficulty, question_count, time_per_question, points_per_question, total_duration_minutes, max_students, result_display_mode, creation_method, status, game_type, category, hints_limit, created_at, updated_at)
       VALUES (?, ?, ?, 'uz', ?, 'medium', 5, 30, 100, 10, 60, 'after_each', 'manual', 'published', 'quiz', 'logic', 3, ?, ?)`
    ).run(
      uzGameId,
      teacherId,
      toNewUzbekAlphabet('Mantiqiy tafakkur va matematika chempionati'),
      toNewUzbekAlphabet('Mantiq va Matematika'),
      now,
      now
    );

    const uzQuestions = [
      {
        prompt: toNewUzbekAlphabet("Ketma-ketlikni davom ettiring: 2, 6, 12, 20, 30, ... Keyingi son nechiga teng?"),
        options: ['40', '42', '44', '38'],
        correctIndex: 1,
        explanation: toNewUzbekAlphabet("Farqlar ketma-ket 4, 6, 8, 10 ga oshib bormoqda. Keyingi farq 12 bo'ladi: 30 + 12 = 42."),
      },
      {
        prompt: toNewUzbekAlphabet("Agar barcha kvadratchalar to'rtburchak bo'lsa va ba'zi to'rtburchaklar ko'k rangda bo'lsa, quyidagi xulosalardan qaysi biri doimo to'g'ri?"),
        options: [
          toNewUzbekAlphabet("Barcha kvadratchalar ko'k rangda"),
          toNewUzbekAlphabet("Har bir kvadrat to'rtburchak hisoblanadi"),
          toNewUzbekAlphabet("Ko'k to'rtburchaklarning barchasi kvadrat"),
          toNewUzbekAlphabet("Hech bir kvadrat ko'k emas"),
        ],
        correctIndex: 1,
        explanation: toNewUzbekAlphabet("Shartga ko'ra barcha kvadratchalar to'rtburchaklar to'plamiga kiradi."),
      },
      {
        prompt: toNewUzbekAlphabet("Soat 15:00 da soat va minut millari orasidagi burchak necha gradusni tashkil etadi?"),
        options: ['60°', '75°', '90°', '120°'],
        correctIndex: 2,
        explanation: toNewUzbekAlphabet("15:00 da minut mili 12 da, soat mili esa 3 da turadi. Ular orasidagi burchak 3 × 30° = 90°."),
      },
      {
        prompt: toNewUzbekAlphabet("Bir guruhda 5 nafar o'quvchi bor. Ularning har biri boshqalar bilan bir martadan qo'l berib ko'rishsa, jami nechta qo'l berish bo'ladi?"),
        options: ['10', '15', '20', '25'],
        correctIndex: 0,
        explanation: toNewUzbekAlphabet("Kombinatorika formulasi bo'yicha: 5 × 4 / 2 = 10 ta qo'l berish."),
      },
      {
        prompt: toNewUzbekAlphabet("Uchburchakning ikki ichki burchagi 48° va 67° ga teng. Uchinchi burchagini toping."),
        options: ['55°', '65°', '75°', '60°'],
        correctIndex: 1,
        explanation: toNewUzbekAlphabet("Uchburchak ichki burchaklari yig'indisi 180°. 180 - (48 + 67) = 65°."),
      },
    ];

    uzQuestions.forEach((q, idx) => {
      db.prepare(
        `INSERT INTO questions (id, game_id, order_index, prompt, options_json, correct_index, explanation, is_approved, ai_generated, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, ?)`
      ).run(
        crypto.randomUUID(),
        uzGameId,
        idx,
        q.prompt,
        JSON.stringify(q.options),
        q.correctIndex,
        q.explanation,
        now
      );
    });

    // 2. Russian game
    const ruGameId = crypto.randomUUID();
    db.prepare(
      `INSERT INTO games (id, teacher_id, title, language, subject, difficulty, question_count, time_per_question, points_per_question, total_duration_minutes, max_students, result_display_mode, creation_method, status, game_type, category, hints_limit, created_at, updated_at)
       VALUES (?, ?, ?, 'ru', ?, 'medium', 4, 30, 100, 8, 50, 'after_each', 'manual', 'published', 'quiz', 'logic', 3, ?, ?)`
    ).run(
      ruGameId,
      teacherId,
      'Логический турнир: Алгоритмы и числа',
      'Информатика и Логика',
      now,
      now
    );

    const ruQuestions = [
      {
        prompt: 'Чему равно двоичное число 10110 в десятичной системе счисления?',
        options: ['20', '22', '24', '18'],
        correctIndex: 1,
        explanation: '1×16 + 0×8 + 1×4 + 1×2 + 0×1 = 16 + 4 + 2 = 22.',
      },
      {
        prompt: 'Какое число пропущено в ряду: 3, 9, 27, 81, ...?',
        options: ['162', '243', '216', '324'],
        correctIndex: 1,
        explanation: 'Каждый следующий элемент умножается на 3: 81 × 3 = 243.',
      },
      {
        prompt: 'Сколько граней у правильного куба?',
        options: ['4', '6', '8', '12'],
        correctIndex: 1,
        explanation: 'У куба 6 квадратных граней, 12 рёбер и 8 вершин.',
      },
      {
        prompt: 'Если 4 машины за 4 минуты изготавливают 4 детали, сколько деталей изготовят 8 машин за 8 минут?',
        options: ['8', '16', '32', '64'],
        correctIndex: 1,
        explanation: 'Одна машина делает 1 деталь за 4 минуты. За 8 минут 1 машина сделает 2 детали, а 8 машин — 16.',
      },
    ];

    ruQuestions.forEach((q, idx) => {
      db.prepare(
        `INSERT INTO questions (id, game_id, order_index, prompt, options_json, correct_index, explanation, is_approved, ai_generated, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, ?)`
      ).run(
        crypto.randomUUID(),
        ruGameId,
        idx,
        q.prompt,
        JSON.stringify(q.options),
        q.correctIndex,
        q.explanation,
        now
      );
    });

    // 3. English game
    const enGameId = crypto.randomUUID();
    db.prepare(
      `INSERT INTO games (id, teacher_id, title, language, subject, difficulty, question_count, time_per_question, points_per_question, total_duration_minutes, max_students, result_display_mode, creation_method, status, game_type, category, hints_limit, created_at, updated_at)
       VALUES (?, ?, ?, 'en', ?, 'hard', 4, 30, 120, 8, 50, 'after_each', 'manual', 'published', 'quiz', 'spatial', 3, ?, ?)`
    ).run(
      enGameId,
      teacherId,
      'Global STEM & Spatial Reasoning Challenge',
      'STEM & Spatial IQ',
      now,
      now
    );

    const enQuestions = [
      {
        prompt: 'What is the next prime number after 29?',
        options: ['31', '33', '35', '37'],
        correctIndex: 0,
        explanation: '31 has no divisors other than 1 and itself.',
      },
      {
        prompt: 'A clock shows 4:20. What is the acute angle between the hour and minute hands?',
        options: ['0°', '10°', '15°', '20°'],
        correctIndex: 1,
        explanation: 'At 4:20, minute hand is at 120°. Hour hand is at 4×30° + 20×0.5° = 130°. Difference = 10°.',
      },
      {
        prompt: 'If a sequence is defined by a(n) = n² + n, what is a(6)?',
        options: ['36', '42', '48', '40'],
        correctIndex: 1,
        explanation: '6² + 6 = 36 + 6 = 42.',
      },
      {
        prompt: 'Which shape has the largest area for a fixed perimeter?',
        options: ['Square', 'Equilateral Triangle', 'Regular Hexagon', 'Circle'],
        correctIndex: 3,
        explanation: 'By the isoperimetric inequality, a circle encloses the maximum area for a given perimeter.',
      },
    ];

    enQuestions.forEach((q, idx) => {
      db.prepare(
        `INSERT INTO questions (id, game_id, order_index, prompt, options_json, correct_index, explanation, is_approved, ai_generated, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, ?)`
      ).run(
        crypto.randomUUID(),
        enGameId,
        idx,
        q.prompt,
        JSON.stringify(q.options),
        q.correctIndex,
        q.explanation,
        now
      );
    });

    // Seed an interactive 25-game IQ Matrix studio game too
    const matrixGameId = crypto.randomUUID();
    db.prepare(
      `INSERT INTO games (id, teacher_id, title, language, subject, difficulty, question_count, time_per_question, points_per_question, total_duration_minutes, max_students, result_display_mode, creation_method, status, game_type, category, hints_limit, created_at, updated_at)
       VALUES (?, ?, ?, 'uz', ?, 'medium', 5, 45, 100, 5, 50, 'after_each', 'manual', 'published', 'iq-matrix', 'logic', 3, ?, ?)`
    ).run(
      matrixGameId,
      teacherId,
      toNewUzbekAlphabet('IQ Matrix: Mantiqiy shakllar'),
      toNewUzbekAlphabet('Mantiqiy fikrlash'),
      now,
      now
    );

    // Seed an open waiting room competition code: IQ2026
    const openCompId = crypto.randomUUID();
    db.prepare(
      `INSERT INTO competitions (id, game_id, teacher_id, title, class_name, code, status, current_question_index, created_at)
       VALUES (?, ?, ?, ?, ?, 'IQ2026', 'waiting', 0, ?)`
    ).run(
      openCompId,
      uzGameId,
      teacherId,
      toNewUzbekAlphabet('Respublika Mantiq Kubogi — Ochiq Sinov'),
      '9-A',
      now
    );

    // Seed a finished historical competition for rich real leaderboard & export testing
    const pastCompId = crypto.randomUUID();
    const pastDate = new Date(Date.now() - 3600 * 1000 * 4).toISOString();
    db.prepare(
      `INSERT INTO competitions (id, game_id, teacher_id, title, class_name, code, status, current_question_index, started_at, ended_at, created_at)
       VALUES (?, ?, ?, ?, ?, 'MAT901', 'finished', 4, ?, ?, ?)`
    ).run(
      pastCompId,
      uzGameId,
      teacherId,
      toNewUzbekAlphabet('Matematika Olimpiadasi — 9-sinflar'),
      '9-A',
      pastDate,
      now,
      pastDate
    );

    const sampleWinners = [
      { name: toNewUzbekAlphabet('Azizbek Tursunov'), cls: '9-A', score: 540, correct: 5, wrong: 0, ms: 34200 },
      { name: toNewUzbekAlphabet('Madinabonu Alimova'), cls: '9-A', score: 465, correct: 4, wrong: 1, ms: 41800 },
      { name: toNewUzbekAlphabet('Shohruh Rahimov'), cls: '9-B', score: 430, correct: 4, wrong: 1, ms: 49500 },
      { name: toNewUzbekAlphabet('Chamanoy Qodirova'), cls: '9-B', score: 340, correct: 3, wrong: 2, ms: 55100 },
    ];
    sampleWinners.forEach((w) => {
      db.prepare(
        `INSERT INTO participants (id, competition_id, display_name, class_name, score, correct_count, wrong_count, total_time_ms, connected, joined_at, finished_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`
      ).run(crypto.randomUUID(), pastCompId, w.name, w.cls, w.score, w.correct, w.wrong, w.ms, pastDate, now);
    });
  }
}

export function generateUniqueCompetitionCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let attempt = 0; attempt < 25; attempt++) {
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars[crypto.randomInt(0, chars.length)];
    }
    const existing = db.prepare('SELECT id FROM competitions WHERE code = ?').get(code);
    if (!existing) return code;
  }
  return `IQ${Date.now().toString().slice(-4)}`;
}
