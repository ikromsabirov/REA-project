import express from 'express';
import crypto from 'crypto';
import QRCode from 'qrcode';
import * as XLSX from 'xlsx';
import { db, generateUniqueCompetitionCode } from './db.ts';
import {
  hashPassword,
  verifyPassword,
  signToken,
  requireAuth,
  requireRole,
  type AuthedRequest,
} from './auth.ts';
import { encryptSecret, decryptSecret, maskSecret } from './crypto.ts';
import { generateQuestionsWithAI, type AIProvider, type GameLang } from './ai.ts';
import { buildCompetitionSnapshot, broadcastCompetitionState } from './socket.ts';
import {
  buildStudentProfile,
  resolveCategoryForGameType,
  sanitizeSubmittedGameResult,
} from './gameEngine.ts';
import { GAME_CATALOG, GAME_CATEGORIES, isGameTypeId } from '../src/games/registry.ts';
import { formatByLanguage, normalizeUzbekSearch } from '../src/utils/uzbekAlphabet.ts';
import { buildProjectDeployZip } from './zipBuilder.ts';

export const apiRouter = express.Router();

function getBaseUrl(req: express.Request): string {
  if (process.env.APP_URL && process.env.APP_URL !== 'MY_APP_URL') {
    return process.env.APP_URL.replace(/\/$/, '');
  }
  const proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'http';
  const host = req.get('host') || 'localhost:3000';
  return `${proto}://${host}`;
}

/* ==================== CATALOG & PRACTICE & INTELLECTUAL PROFILE ==================== */

apiRouter.get('/catalog', (_req, res) => {
  res.json({
    categories: GAME_CATEGORIES,
    games: GAME_CATALOG,
  });
});

apiRouter.post('/practice/submit', (req, res) => {
  const body = req.body || {};
  const gameType = String(body.gameType || '').trim();
  if (!isGameTypeId(gameType)) {
    res.status(400).json({ error: 'Invalid gameType' });
    return;
  }

  const language: GameLang =
    body.language === 'ru' || body.language === 'en' ? body.language : 'uz';
  const difficulty = ['easy', 'medium', 'hard'].includes(body.difficulty)
    ? body.difficulty
    : 'medium';
  const studentKey = String(body.studentKey || 'guest').trim().slice(0, 80);
  const studentName = formatByLanguage(String(body.studentName || 'Guest').trim().slice(0, 80), language);
  const category = resolveCategoryForGameType(gameType);

  const safe = sanitizeSubmittedGameResult({
    stagesCount: Number(body.stagesCount) || 5,
    correctCount: Number(body.correctCount) || 0,
    wrongCount: Number(body.wrongCount) || 0,
    hintsUsed: Number(body.hintsUsed) || 0,
    timeSpentMs: Number(body.timeSpentMs) || 1000,
    reportedScore: Number(body.score) || 0,
  });

  const id = crypto.randomUUID();
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO practice_results
     (id, student_key, student_name, game_type, category, difficulty, language, score, max_score, correct_count, wrong_count, hints_used, time_spent_ms, accuracy, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    studentKey,
    studentName,
    gameType,
    category,
    difficulty,
    language,
    safe.score,
    safe.maxScore,
    safe.correctCount,
    safe.wrongCount,
    safe.hintsUsed,
    safe.timeSpentMs,
    safe.accuracy,
    now
  );

  const profile = buildStudentProfile(studentKey, studentName);
  res.status(201).json({ id, saved: safe, profile });
});

apiRouter.get('/profile', (req, res) => {
  const studentKey = String(req.query.studentKey || 'guest').trim();
  const studentName = String(req.query.studentName || '').trim() || undefined;
  const profile = buildStudentProfile(studentKey, studentName);
  res.json(profile);
});

/* ==================== MEDIA ASSETS LIBRARY ==================== */

const ALLOWED_MEDIA_MIMES = new Set([
  'image/png',
  'image/jpeg',
  'image/webp',
  'image/svg+xml',
  'audio/mpeg',
  'audio/ogg',
  'audio/wav',
]);

apiRouter.get('/media', (_req, res) => {
  const assets = db
    .prepare(
      'SELECT id, owner_id, title, mime_type, byte_size, data_url, is_builtin, created_at FROM media_assets ORDER BY is_builtin DESC, created_at DESC LIMIT 60'
    )
    .all();
  res.json({ assets });
});

apiRouter.post('/media', requireAuth, (req: AuthedRequest, res) => {
  const { title, mimeType, dataUrl } = req.body || {};
  const cleanTitle = String(title || 'Media').trim().slice(0, 80);
  const cleanMime = String(mimeType || '').trim().toLowerCase();
  const rawData = String(dataUrl || '');

  if (!ALLOWED_MEDIA_MIMES.has(cleanMime)) {
    res.status(400).json({ error: 'Unsupported media file type.' });
    return;
  }
  if (!rawData.startsWith(`data:${cleanMime}`)) {
    res.status(400).json({ error: 'Invalid media payload format.' });
    return;
  }
  const byteSize = Buffer.byteLength(rawData, 'utf8');
  if (byteSize > 1_500_000) {
    res.status(400).json({ error: 'File size exceeds 1.5 MB limit.' });
    return;
  }

  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO media_assets (id, owner_id, title, mime_type, byte_size, data_url, is_builtin, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 0, ?)`
  ).run(id, req.user!.userId, cleanTitle, cleanMime, byteSize, rawData, now);

  const asset = db.prepare('SELECT * FROM media_assets WHERE id = ?').get(id);
  res.status(201).json({ asset });
});

apiRouter.delete('/media/:id', requireAuth, (req: AuthedRequest, res) => {
  const id = String(req.params.id);
  const existing = db.prepare('SELECT owner_id, is_builtin FROM media_assets WHERE id = ?').get(id) as
    | { owner_id: string | null; is_builtin: number }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Asset not found' });
    return;
  }
  if (existing.is_builtin) {
    res.status(403).json({ error: 'Built-in media cannot be deleted.' });
    return;
  }
  if (existing.owner_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }
  db.prepare('DELETE FROM media_assets WHERE id = ?').run(id);
  res.json({ deleted: true });
});

/* ==================== AUTH ROUTES ==================== */

apiRouter.post('/auth/register', (req, res) => {
  const { fullName, login, email, password, confirmPassword, preferredLang } = req.body || {};

  if (!fullName || !login || !email || !password) {
    res.status(400).json({ error: 'All registration fields are required.' });
    return;
  }
  if (String(password).length < 6) {
    res.status(400).json({ error: 'Password must be at least 6 characters.' });
    return;
  }
  if (confirmPassword !== undefined && password !== confirmPassword) {
    res.status(400).json({ error: 'Passwords do not match.' });
    return;
  }

  const cleanLogin = String(login).trim().toLowerCase();
  const cleanEmail = String(email).trim().toLowerCase();
  const lang: GameLang =
    preferredLang === 'ru' || preferredLang === 'en' ? preferredLang : 'uz';
  const cleanName = formatByLanguage(String(fullName).trim(), lang);

  const existing = db
    .prepare('SELECT id FROM users WHERE login = ? OR email = ?')
    .get(cleanLogin, cleanEmail);
  if (existing) {
    res.status(409).json({ error: 'Login or email is already registered.' });
    return;
  }

  const userId = crypto.randomUUID();
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO users (id, full_name, login, email, password_hash, role, preferred_lang, created_at)
     VALUES (?, ?, ?, ?, ?, 'teacher', ?, ?)`
  ).run(userId, cleanName, cleanLogin, cleanEmail, hashPassword(String(password)), lang, now);

  const token = signToken({
    userId,
    role: 'teacher',
    login: cleanLogin,
    fullName: cleanName,
  });

  res.status(201).json({
    token,
    user: {
      id: userId,
      fullName: cleanName,
      login: cleanLogin,
      email: cleanEmail,
      role: 'teacher',
      preferredLang: lang,
    },
  });
});

apiRouter.post('/auth/login', (req, res) => {
  const { login, password } = req.body || {};
  if (!login || !password) {
    res.status(400).json({ error: 'Login and password are required.' });
    return;
  }

  const identifier = String(login).trim().toLowerCase();
  const user = db
    .prepare(
      'SELECT id, full_name, login, email, password_hash, role, preferred_lang, is_active FROM users WHERE login = ? OR email = ?'
    )
    .get(identifier, identifier) as
    | {
        id: string;
        full_name: string;
        login: string;
        email: string;
        password_hash: string;
        role: 'teacher' | 'admin';
        preferred_lang: GameLang;
        is_active: number;
      }
    | undefined;

  if (!user || !verifyPassword(String(password), user.password_hash)) {
    res.status(401).json({ error: 'Invalid login or password.' });
    return;
  }

  if (!user.is_active) {
    res.status(403).json({ error: 'Account is disabled by administrator.' });
    return;
  }

  const token = signToken({
    userId: user.id,
    role: user.role,
    login: user.login,
    fullName: user.full_name,
  });

  res.json({
    token,
    user: {
      id: user.id,
      fullName: user.full_name,
      login: user.login,
      email: user.email,
      role: user.role,
      preferredLang: user.preferred_lang,
    },
  });
});

apiRouter.get('/auth/me', requireAuth, (req: AuthedRequest, res) => {
  const user = db
    .prepare('SELECT id, full_name, login, email, role, preferred_lang FROM users WHERE id = ?')
    .get(req.user!.userId) as
    | {
        id: string;
        full_name: string;
        login: string;
        email: string;
        role: 'teacher' | 'admin';
        preferred_lang: GameLang;
      }
    | undefined;

  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  res.json({
    user: {
      id: user.id,
      fullName: user.full_name,
      login: user.login,
      email: user.email,
      role: user.role,
      preferredLang: user.preferred_lang,
    },
  });
});

apiRouter.patch('/auth/preferences', requireAuth, (req: AuthedRequest, res) => {
  const { preferredLang } = req.body || {};
  if (preferredLang !== 'uz' && preferredLang !== 'ru' && preferredLang !== 'en') {
    res.status(400).json({ error: 'Invalid language code' });
    return;
  }
  db.prepare('UPDATE users SET preferred_lang = ? WHERE id = ?').run(
    preferredLang,
    req.user!.userId
  );
  res.json({ preferredLang });
});

/* ==================== STUDENT JOIN ROUTES ==================== */

apiRouter.get('/competitions/by-code/:code', (req, res) => {
  const code = String(req.params.code || '')
    .trim()
    .toUpperCase();
  const row = db
    .prepare(
      `SELECT c.id, c.title, c.class_name, c.code, c.status, g.title as game_title, g.language, g.subject, g.difficulty, g.max_students, g.time_per_question, g.game_type, g.category,
              (SELECT COUNT(*) FROM participants p WHERE p.competition_id = c.id) as participant_count
       FROM competitions c
       JOIN games g ON g.id = c.game_id
       WHERE c.code = ?`
    )
    .get(code) as
    | {
        id: string;
        title: string;
        class_name: string;
        code: string;
        status: string;
        game_title: string;
        language: GameLang;
        subject: string;
        difficulty: string;
        max_students: number;
        time_per_question: number;
        game_type: string;
        category: string;
        participant_count: number;
      }
    | undefined;

  if (!row) {
    res.status(404).json({ error: 'Competition code not found.' });
    return;
  }

  res.json({
    competition: {
      id: row.id,
      title: row.title,
      className: row.class_name,
      code: row.code,
      status: row.status,
      gameTitle: row.game_title,
      language: row.language,
      subject: row.subject,
      difficulty: row.difficulty,
      maxStudents: row.max_students,
      timePerQuestion: row.time_per_question,
      gameType: row.game_type || 'quiz',
      category: row.category || 'logic',
      participantCount: row.participant_count,
    },
  });
});

apiRouter.post('/student/join', (req, res) => {
  const { name, code, className } = req.body || {};
  const cleanName = String(name || '').trim();
  const cleanCode = String(code || '')
    .trim()
    .toUpperCase();

  if (!cleanName || cleanName.length < 2) {
    res.status(400).json({ error: 'Please enter your name (at least 2 characters).' });
    return;
  }
  if (!cleanCode) {
    res.status(400).json({ error: 'Please enter a valid game code.' });
    return;
  }

  const comp = db
    .prepare(
      `SELECT c.id, c.status, c.class_name, g.language, g.max_students
       FROM competitions c
       JOIN games g ON g.id = c.game_id
       WHERE c.code = ?`
    )
    .get(cleanCode) as
    | {
        id: string;
        status: 'waiting' | 'active' | 'finished';
        class_name: string;
        language: GameLang;
        max_students: number;
      }
    | undefined;

  if (!comp) {
    res.status(404).json({ error: 'Game code not found. Please verify the code with your teacher.' });
    return;
  }

  if (comp.status === 'finished') {
    res.status(400).json({ error: 'This competition has already finished.' });
    return;
  }

  const countRow = db
    .prepare('SELECT COUNT(*) as cnt FROM participants WHERE competition_id = ?')
    .get(comp.id) as { cnt: number };

  if (countRow.cnt >= comp.max_students) {
    res.status(400).json({ error: 'This competition has reached its maximum participant limit.' });
    return;
  }

  const participantId = crypto.randomUUID();
  const formattedName = formatByLanguage(cleanName, comp.language);
  const resolvedClass = String(className || comp.class_name || 'Umumiy').trim();
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO participants (id, competition_id, display_name, class_name, score, correct_count, wrong_count, total_time_ms, connected, joined_at)
     VALUES (?, ?, ?, ?, 0, 0, 0, 0, 1, ?)`
  ).run(participantId, comp.id, formattedName, resolvedClass, now);

  broadcastCompetitionState(comp.id);
  const snapshot = buildCompetitionSnapshot(comp.id, false);

  res.status(201).json({
    participant: {
      id: participantId,
      displayName: formattedName,
      className: resolvedClass,
      competitionId: comp.id,
    },
    snapshot,
  });
});

apiRouter.get('/student/competition/:id', (req, res) => {
  const snapshot = buildCompetitionSnapshot(String(req.params.id), false);
  if (!snapshot) {
    res.status(404).json({ error: 'Competition not found' });
    return;
  }
  res.json(snapshot);
});

/* ==================== GAMES ROUTES (TEACHER & ADMIN) ==================== */

apiRouter.get('/games', requireAuth, (req: AuthedRequest, res) => {
  const search = String(req.query.search || '').trim();
  const isAdmin = req.user!.role === 'admin';

  const rows = (
    isAdmin
      ? db
          .prepare(
            `SELECT g.*, u.full_name as teacher_name,
                    (SELECT COUNT(*) FROM questions q WHERE q.game_id = g.id) as actual_question_count,
                    (SELECT COUNT(*) FROM questions q WHERE q.game_id = g.id AND q.is_approved = 1) as approved_question_count
             FROM games g
             JOIN users u ON u.id = g.teacher_id
             ORDER BY g.updated_at DESC`
          )
          .all()
      : db
          .prepare(
            `SELECT g.*, u.full_name as teacher_name,
                    (SELECT COUNT(*) FROM questions q WHERE q.game_id = g.id) as actual_question_count,
                    (SELECT COUNT(*) FROM questions q WHERE q.game_id = g.id AND q.is_approved = 1) as approved_question_count
             FROM games g
             JOIN users u ON u.id = g.teacher_id
             WHERE g.teacher_id = ?
             ORDER BY g.updated_at DESC`
          )
          .all(req.user!.userId)
  ) as Array<Record<string, unknown>>;

  const normQuery = normalizeUzbekSearch(search);
  const filtered = normQuery
    ? rows.filter((r) => {
        const hay = normalizeUzbekSearch(`${r.title} ${r.subject} ${r.ai_topic || ''} ${r.game_type || ''}`);
        return hay.includes(normQuery);
      })
    : rows;

  res.json({ games: filtered });
});

apiRouter.get('/games/:id', requireAuth, (req: AuthedRequest, res) => {
  const game = db.prepare('SELECT * FROM games WHERE id = ?').get(String(req.params.id)) as
    | Record<string, unknown>
    | undefined;

  if (!game) {
    res.status(404).json({ error: 'Game not found' });
    return;
  }

  if (game.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  const questions = db
    .prepare('SELECT * FROM questions WHERE game_id = ? ORDER BY order_index ASC')
    .all(String(req.params.id)) as Array<Record<string, unknown>>;

  res.json({
    game,
    questions: questions.map((q) => ({
      id: q.id,
      orderIndex: q.order_index,
      prompt: q.prompt,
      options: JSON.parse(String(q.options_json)) as string[],
      correctIndex: q.correct_index,
      explanation: q.explanation,
      isApproved: Boolean(q.is_approved),
      aiGenerated: Boolean(q.ai_generated),
    })),
  });
});

apiRouter.post('/games', requireAuth, (req: AuthedRequest, res) => {
  const body = req.body || {};
  const language: GameLang =
    body.language === 'ru' || body.language === 'en' ? body.language : 'uz';
  const title = formatByLanguage(String(body.title || '').trim(), language);
  const subject = formatByLanguage(String(body.subject || 'IQ').trim(), language);
  const gameType = isGameTypeId(String(body.gameType || '')) ? String(body.gameType) : 'quiz';
  const category = resolveCategoryForGameType(gameType);

  if (!title) {
    res.status(400).json({ error: 'Game title is required.' });
    return;
  }

  const gameId = crypto.randomUUID();
  const now = new Date().toISOString();
  const creationMethod = body.creationMethod === 'ai' ? 'ai' : 'manual';
  const initialStatus = creationMethod === 'ai' && gameType === 'quiz' ? 'draft' : 'published';
  const configJson = JSON.stringify(body.config && typeof body.config === 'object' ? body.config : {});

  db.prepare(
    `INSERT INTO games (id, teacher_id, title, language, subject, difficulty, question_count, time_per_question, points_per_question, total_duration_minutes, max_students, scheduled_at, result_display_mode, creation_method, status, ai_topic, game_type, category, hints_limit, config_json, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    gameId,
    req.user!.userId,
    title,
    language,
    subject,
    ['easy', 'medium', 'hard'].includes(body.difficulty) ? body.difficulty : 'medium',
    Math.min(Math.max(Number(body.questionCount) || 5, 1), 50),
    Math.min(Math.max(Number(body.timePerQuestion) || 30, 5), 300),
    Math.min(Math.max(Number(body.pointsPerQuestion) || 100, 10), 1000),
    Math.min(Math.max(Number(body.totalDurationMinutes) || 10, 1), 180),
    Math.min(Math.max(Number(body.maxStudents) || 50, 2), 500),
    body.scheduledAt ? String(body.scheduledAt) : null,
    ['after_each', 'after_finish', 'live_leaderboard'].includes(body.resultDisplayMode)
      ? body.resultDisplayMode
      : 'after_each',
    creationMethod,
    initialStatus,
    body.aiTopic ? formatByLanguage(String(body.aiTopic), language) : null,
    gameType,
    category,
    Math.min(Math.max(Number(body.hintsLimit ?? 3), 0), 10),
    configJson,
    now,
    now
  );

  if (Array.isArray(body.questions) && body.questions.length > 0) {
    body.questions.forEach((q: Record<string, unknown>, idx: number) => {
      const prompt = formatByLanguage(String(q.prompt || '').trim(), language);
      const opts = Array.isArray(q.options)
        ? q.options.slice(0, 4).map((o) => formatByLanguage(String(o || '').trim(), language))
        : [];
      if (prompt && opts.length === 4) {
        db.prepare(
          `INSERT INTO questions (id, game_id, order_index, prompt, options_json, correct_index, explanation, is_approved, ai_generated, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, ?)`
        ).run(
          crypto.randomUUID(),
          gameId,
          idx,
          prompt,
          JSON.stringify(opts),
          Math.min(Math.max(Number(q.correctIndex) || 0, 0), 3),
          formatByLanguage(String(q.explanation || '').trim(), language),
          now
        );
      }
    });
  }

  const game = db.prepare('SELECT * FROM games WHERE id = ?').get(gameId);
  res.status(201).json({ game });
});

apiRouter.post('/games/:id/duplicate', requireAuth, (req: AuthedRequest, res) => {
  const sourceId = String(req.params.id);
  const src = db.prepare('SELECT * FROM games WHERE id = ?').get(sourceId) as
    | Record<string, unknown>
    | undefined;
  if (!src) {
    res.status(404).json({ error: 'Game not found' });
    return;
  }
  if (src.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  const newId = crypto.randomUUID();
  const now = new Date().toISOString();
  const lang = src.language as GameLang;
  const suffix = lang === 'ru' ? ' (Копия)' : lang === 'en' ? ' (Copy)' : ' (Nusxa)';
  const copyTitle = `${String(src.title)}${suffix}`;

  db.prepare(
    `INSERT INTO games (id, teacher_id, title, language, subject, difficulty, question_count, time_per_question, points_per_question, total_duration_minutes, max_students, scheduled_at, result_display_mode, creation_method, status, ai_topic, ai_provider, game_type, category, hints_limit, config_json, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'published', ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    newId,
    req.user!.userId,
    copyTitle,
    String(src.language),
    String(src.subject),
    String(src.difficulty),
    Number(src.question_count),
    Number(src.time_per_question),
    Number(src.points_per_question),
    Number(src.total_duration_minutes),
    Number(src.max_students),
    src.scheduled_at ? String(src.scheduled_at) : null,
    String(src.result_display_mode),
    String(src.creation_method),
    src.ai_topic ? String(src.ai_topic) : null,
    src.ai_provider ? String(src.ai_provider) : null,
    String(src.game_type || 'quiz'),
    String(src.category || 'logic'),
    Number(src.hints_limit ?? 3),
    String(src.config_json || '{}'),
    now,
    now
  );

  const questions = db
    .prepare('SELECT * FROM questions WHERE game_id = ? ORDER BY order_index ASC')
    .all(sourceId) as Array<Record<string, unknown>>;

  for (const q of questions) {
    db.prepare(
      `INSERT INTO questions (id, game_id, order_index, prompt, options_json, correct_index, explanation, is_approved, ai_generated, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      crypto.randomUUID(),
      newId,
      Number(q.order_index),
      String(q.prompt),
      String(q.options_json),
      Number(q.correct_index),
      String(q.explanation || ''),
      Number(q.is_approved ?? 1),
      Number(q.ai_generated ?? 0),
      now
    );
  }

  const created = db.prepare('SELECT * FROM games WHERE id = ?').get(newId);
  res.status(201).json({ game: created });
});

apiRouter.put('/games/:id', requireAuth, (req: AuthedRequest, res) => {
  const gameId = String(req.params.id);
  const existing = db.prepare('SELECT * FROM games WHERE id = ?').get(gameId) as
    | { teacher_id: string; language: GameLang }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Game not found' });
    return;
  }
  if (existing.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  const body = req.body || {};
  const lang = existing.language;
  const now = new Date().toISOString();

  db.prepare(
    `UPDATE games SET
       title = COALESCE(?, title),
       subject = COALESCE(?, subject),
       difficulty = COALESCE(?, difficulty),
       question_count = COALESCE(?, question_count),
       time_per_question = COALESCE(?, time_per_question),
       points_per_question = COALESCE(?, points_per_question),
       total_duration_minutes = COALESCE(?, total_duration_minutes),
       max_students = COALESCE(?, max_students),
       scheduled_at = ?,
       result_display_mode = COALESCE(?, result_display_mode),
       status = COALESCE(?, status),
       hints_limit = COALESCE(?, hints_limit),
       config_json = COALESCE(?, config_json),
       updated_at = ?
     WHERE id = ?`
  ).run(
    body.title ? formatByLanguage(String(body.title).trim(), lang) : null,
    body.subject ? formatByLanguage(String(body.subject).trim(), lang) : null,
    body.difficulty || null,
    body.questionCount ? Number(body.questionCount) : null,
    body.timePerQuestion ? Number(body.timePerQuestion) : null,
    body.pointsPerQuestion ? Number(body.pointsPerQuestion) : null,
    body.totalDurationMinutes ? Number(body.totalDurationMinutes) : null,
    body.maxStudents ? Number(body.maxStudents) : null,
    body.scheduledAt !== undefined ? body.scheduledAt : null,
    body.resultDisplayMode || null,
    body.status || null,
    body.hintsLimit !== undefined ? Number(body.hintsLimit) : null,
    body.config ? JSON.stringify(body.config) : null,
    now,
    gameId
  );

  const updated = db.prepare('SELECT * FROM games WHERE id = ?').get(gameId);
  res.json({ game: updated });
});

apiRouter.delete('/games/:id', requireAuth, (req: AuthedRequest, res) => {
  const gameId = String(req.params.id);
  const existing = db.prepare('SELECT teacher_id FROM games WHERE id = ?').get(gameId) as
    | { teacher_id: string }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Game not found' });
    return;
  }
  if (existing.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }
  db.prepare('DELETE FROM games WHERE id = ?').run(gameId);
  res.json({ deleted: true });
});

apiRouter.post('/games/:id/questions', requireAuth, (req: AuthedRequest, res) => {
  const gameId = String(req.params.id);
  const existing = db.prepare('SELECT teacher_id, language FROM games WHERE id = ?').get(gameId) as
    | { teacher_id: string; language: GameLang }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Game not found' });
    return;
  }
  if (existing.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  const { questions, replaceAll } = req.body || {};
  if (!Array.isArray(questions) || questions.length === 0) {
    res.status(400).json({ error: 'Questions array is required' });
    return;
  }

  const now = new Date().toISOString();
  if (replaceAll) {
    db.prepare('DELETE FROM questions WHERE game_id = ?').run(gameId);
  }

  const maxOrderRow = db
    .prepare('SELECT COALESCE(MAX(order_index), -1) as max_idx FROM questions WHERE game_id = ?')
    .get(gameId) as { max_idx: number };
  let nextIdx = maxOrderRow.max_idx + 1;

  questions.forEach((q: Record<string, unknown>) => {
    const prompt = formatByLanguage(String(q.prompt || '').trim(), existing.language);
    const opts = Array.isArray(q.options)
      ? q.options.slice(0, 4).map((o) => formatByLanguage(String(o || '').trim(), existing.language))
      : [];
    if (!prompt || opts.length !== 4 || opts.some((o) => !o)) return;
    db.prepare(
      `INSERT INTO questions (id, game_id, order_index, prompt, options_json, correct_index, explanation, is_approved, ai_generated, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, ?)`
    ).run(
      crypto.randomUUID(),
      gameId,
      nextIdx++,
      prompt,
      JSON.stringify(opts),
      Math.min(Math.max(Number(q.correctIndex) || 0, 0), 3),
      formatByLanguage(String(q.explanation || '').trim(), existing.language),
      now
    );
  });

  db.prepare(
    `UPDATE games SET status = 'published', question_count = (SELECT COUNT(*) FROM questions WHERE game_id = ?), updated_at = ? WHERE id = ?`
  ).run(gameId, now, gameId);

  const saved = db
    .prepare('SELECT * FROM questions WHERE game_id = ? ORDER BY order_index ASC')
    .all(gameId) as Array<Record<string, unknown>>;

  res.json({
    questions: saved.map((q) => ({
      id: q.id,
      orderIndex: q.order_index,
      prompt: q.prompt,
      options: JSON.parse(String(q.options_json)),
      correctIndex: q.correct_index,
      explanation: q.explanation,
      isApproved: Boolean(q.is_approved),
      aiGenerated: Boolean(q.ai_generated),
    })),
  });
});

apiRouter.post('/games/:id/ai-generate', requireAuth, async (req: AuthedRequest, res) => {
  const gameId = String(req.params.id);
  const game = db.prepare('SELECT * FROM games WHERE id = ?').get(gameId) as
    | {
        id: string;
        teacher_id: string;
        language: GameLang;
        subject: string;
        difficulty: string;
        question_count: number;
        game_type: string;
      }
    | undefined;

  if (!game) {
    res.status(404).json({ error: 'Game not found' });
    return;
  }
  if (game.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  const topic = String(req.body?.topic || '').trim();
  const count = Number(req.body?.count) || game.question_count || 5;
  const preferredProvider = req.body?.provider as AIProvider | undefined;
  const ageGrade = String(req.body?.ageGrade || '').trim();
  const customInstructions = String(req.body?.customInstructions || '').trim();

  if (!topic) {
    res.status(400).json({ error: 'Please provide a topic for AI question generation.' });
    return;
  }

  try {
    const result = await generateQuestionsWithAI({
      userId: req.user!.userId,
      topic,
      language: game.language,
      subject: game.subject,
      difficulty: game.difficulty,
      count,
      gameType: game.game_type || 'quiz',
      ageGrade,
      customInstructions,
      preferredProvider,
    });

    const now = new Date().toISOString();
    db.prepare('DELETE FROM questions WHERE game_id = ? AND is_approved = 0').run(gameId);

    const maxOrderRow = db
      .prepare('SELECT COALESCE(MAX(order_index), -1) as max_idx FROM questions WHERE game_id = ?')
      .get(gameId) as { max_idx: number };
    let nextIdx = maxOrderRow.max_idx + 1;

    const inserted = result.questions.map((q) => {
      const qId = crypto.randomUUID();
      db.prepare(
        `INSERT INTO questions (id, game_id, order_index, prompt, options_json, correct_index, explanation, is_approved, ai_generated, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0, 1, ?)`
      ).run(
        qId,
        gameId,
        nextIdx++,
        q.prompt,
        JSON.stringify(q.options),
        q.correctIndex,
        q.explanation,
        now
      );
      return {
        id: qId,
        orderIndex: nextIdx - 1,
        prompt: q.prompt,
        options: q.options,
        correctIndex: q.correctIndex,
        explanation: q.explanation,
        isApproved: false,
        aiGenerated: true,
      };
    });

    db.prepare(
      `UPDATE games SET ai_topic = ?, ai_provider = ?, status = 'draft', updated_at = ? WHERE id = ?`
    ).run(formatByLanguage(topic, game.language), result.provider, now, gameId);

    res.json({
      provider: result.provider,
      tokensUsed: result.tokensUsed,
      questions: inserted,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'AI generation failed';
    res.status(502).json({ error: msg });
  }
});

apiRouter.put('/games/:id/questions/:qid', requireAuth, (req: AuthedRequest, res) => {
  const gameId = String(req.params.id);
  const qid = String(req.params.qid);
  const game = db.prepare('SELECT teacher_id, language FROM games WHERE id = ?').get(gameId) as
    | { teacher_id: string; language: GameLang }
    | undefined;
  if (!game) {
    res.status(404).json({ error: 'Game not found' });
    return;
  }
  if (game.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  const { prompt, options, correctIndex, explanation } = req.body || {};
  if (!prompt || !Array.isArray(options) || options.length !== 4) {
    res.status(400).json({ error: 'Prompt and 4 options are required' });
    return;
  }

  const formattedPrompt = formatByLanguage(String(prompt).trim(), game.language);
  const formattedOpts = options.map((o) => formatByLanguage(String(o).trim(), game.language));
  const formattedExp = formatByLanguage(String(explanation || '').trim(), game.language);

  db.prepare(
    `UPDATE questions SET prompt = ?, options_json = ?, correct_index = ?, explanation = ? WHERE id = ? AND game_id = ?`
  ).run(
    formattedPrompt,
    JSON.stringify(formattedOpts),
    Math.min(Math.max(Number(correctIndex) || 0, 0), 3),
    formattedExp,
    qid,
    gameId
  );

  res.json({
    question: {
      id: qid,
      prompt: formattedPrompt,
      options: formattedOpts,
      correctIndex: Math.min(Math.max(Number(correctIndex) || 0, 0), 3),
      explanation: formattedExp,
    },
  });
});

apiRouter.delete('/games/:id/questions/:qid', requireAuth, (req: AuthedRequest, res) => {
  const gameId = String(req.params.id);
  const qid = String(req.params.qid);
  const game = db.prepare('SELECT teacher_id FROM games WHERE id = ?').get(gameId) as
    | { teacher_id: string }
    | undefined;
  if (!game) {
    res.status(404).json({ error: 'Game not found' });
    return;
  }
  if (game.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }
  db.prepare('DELETE FROM questions WHERE id = ? AND game_id = ?').run(qid, gameId);
  res.json({ deleted: true });
});

apiRouter.post('/games/:id/approve', requireAuth, (req: AuthedRequest, res) => {
  const gameId = String(req.params.id);
  const game = db.prepare('SELECT teacher_id, game_type, question_count FROM games WHERE id = ?').get(gameId) as
    | { teacher_id: string; game_type: string; question_count: number }
    | undefined;
  if (!game) {
    res.status(404).json({ error: 'Game not found' });
    return;
  }
  if (game.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  const countRow = db
    .prepare('SELECT COUNT(*) as cnt FROM questions WHERE game_id = ?')
    .get(gameId) as { cnt: number };

  if (game.game_type === 'quiz' && countRow.cnt === 0) {
    res.status(400).json({ error: 'Cannot publish a quiz game with 0 questions.' });
    return;
  }

  const now = new Date().toISOString();
  db.prepare('UPDATE questions SET is_approved = 1 WHERE game_id = ?').run(gameId);
  const effectiveCount = countRow.cnt > 0 ? countRow.cnt : game.question_count;
  db.prepare(`UPDATE games SET status = 'published', question_count = ?, updated_at = ? WHERE id = ?`).run(
    effectiveCount,
    now,
    gameId
  );

  res.json({ approved: true, questionCount: effectiveCount });
});

/* ==================== COMPETITIONS & QR & EXCEL EXPORT ==================== */

apiRouter.get('/competitions', requireAuth, (req: AuthedRequest, res) => {
  const isAdmin = req.user!.role === 'admin';
  const rows = isAdmin
    ? db
        .prepare(
          `SELECT c.*, g.title as game_title, g.language as game_language, g.subject, g.game_type, g.category,
                  (SELECT COUNT(*) FROM participants p WHERE p.competition_id = c.id) as participant_count
           FROM competitions c
           JOIN games g ON g.id = c.game_id
           ORDER BY c.created_at DESC`
        )
        .all()
    : db
        .prepare(
          `SELECT c.*, g.title as game_title, g.language as game_language, g.subject, g.game_type, g.category,
                  (SELECT COUNT(*) FROM participants p WHERE p.competition_id = c.id) as participant_count
           FROM competitions c
           JOIN games g ON g.id = c.game_id
           WHERE c.teacher_id = ?
           ORDER BY c.created_at DESC`
        )
        .all(req.user!.userId);

  res.json({ competitions: rows });
});

apiRouter.post('/competitions', requireAuth, async (req: AuthedRequest, res) => {
  const { gameId, title, className } = req.body || {};
  const game = db.prepare('SELECT * FROM games WHERE id = ?').get(String(gameId || '')) as
    | { id: string; teacher_id: string; title: string; language: GameLang; status: string; game_type: string }
    | undefined;

  if (!game) {
    res.status(404).json({ error: 'Game not found' });
    return;
  }
  if (game.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'You can only organize competitions for your own games.' });
    return;
  }

  const isInteractiveGame = Boolean(game.game_type && game.game_type !== 'quiz');
  if (!isInteractiveGame) {
    const approvedCount = db
      .prepare('SELECT COUNT(*) as cnt FROM questions WHERE game_id = ? AND is_approved = 1')
      .get(game.id) as { cnt: number };
    if (approvedCount.cnt === 0) {
      res.status(400).json({ error: 'Please approve at least 1 question before starting a competition.' });
      return;
    }
  }

  const compId = crypto.randomUUID();
  const code = generateUniqueCompetitionCode();
  const compTitle = formatByLanguage(String(title || game.title).trim(), game.language);
  const compClass = String(className || 'Umumiy').trim();
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO competitions (id, game_id, teacher_id, title, class_name, code, status, current_question_index, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 'waiting', 0, ?)`
  ).run(compId, game.id, req.user!.userId, compTitle, compClass, code, now);

  const joinUrl = `${getBaseUrl(req)}/join/${code}`;
  const qrDataUrl = await QRCode.toDataURL(joinUrl, { width: 512, margin: 2 });

  res.status(201).json({
    competition: {
      id: compId,
      gameId: game.id,
      title: compTitle,
      className: compClass,
      code,
      status: 'waiting',
      joinUrl,
      qrDataUrl,
      createdAt: now,
    },
  });
});

apiRouter.get('/competitions/:id', requireAuth, async (req: AuthedRequest, res) => {
  const compId = String(req.params.id);
  const comp = db.prepare('SELECT * FROM competitions WHERE id = ?').get(compId) as
    | { id: string; teacher_id: string; code: string }
    | undefined;
  if (!comp) {
    res.status(404).json({ error: 'Competition not found' });
    return;
  }
  if (comp.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  const snapshot = buildCompetitionSnapshot(compId, true);
  const joinUrl = `${getBaseUrl(req)}/join/${comp.code}`;
  const qrDataUrl = await QRCode.toDataURL(joinUrl, { width: 512, margin: 2 });

  res.json({
    ...snapshot,
    joinUrl,
    qrDataUrl,
  });
});

apiRouter.get('/competitions/:id/results', (req, res) => {
  const snapshot = buildCompetitionSnapshot(String(req.params.id), true);
  if (!snapshot) {
    res.status(404).json({ error: 'Competition not found' });
    return;
  }
  res.json(snapshot);
});

apiRouter.get('/competitions/:id/export', requireAuth, (req: AuthedRequest, res) => {
  const compId = String(req.params.id);
  const comp = db.prepare('SELECT * FROM competitions WHERE id = ?').get(compId) as
    | { id: string; teacher_id: string; title: string; code: string; class_name: string }
    | undefined;
  if (!comp) {
    res.status(404).json({ error: 'Competition not found' });
    return;
  }
  if (comp.teacher_id !== req.user!.userId && req.user!.role !== 'admin') {
    res.status(403).json({ error: 'Access denied' });
    return;
  }

  const participants = db
    .prepare(
      `SELECT display_name, class_name, score, correct_count, wrong_count, total_time_ms, joined_at
       FROM participants
       WHERE competition_id = ?
       ORDER BY score DESC, correct_count DESC, total_time_ms ASC, wrong_count ASC`
    )
    .all(compId) as Array<{
    display_name: string;
    class_name: string;
    score: number;
    correct_count: number;
    wrong_count: number;
    total_time_ms: number;
    joined_at: string;
  }>;

  const rows = participants.map((p, index) => ({
    Rank: index + 1,
    Name: p.display_name,
    Class: p.class_name,
    Score: p.score,
    Correct: p.correct_count,
    Wrong: p.wrong_count,
    Time_Sec: Number((p.total_time_ms / 1000).toFixed(2)),
    Joined_At: p.joined_at,
  }));

  const workbook = XLSX.utils.book_new();
  const resultsSheet = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(workbook, resultsSheet, 'Natijalar');

  const summarySheet = XLSX.utils.json_to_sheet([
    {
      Competition: comp.title,
      Code: comp.code,
      Class: comp.class_name,
      Total_Participants: participants.length,
      Exported_At: new Date().toISOString(),
    },
  ]);
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Musobaqa');

  const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
  res.setHeader(
    'Content-Type',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
  res.setHeader(
    'Content-Disposition',
    `attachment; filename="IQ_PUZZLE_${comp.code}_results.xlsx"`
  );
  res.send(buffer);
});

/* ==================== LEADERBOARD ROUTES ==================== */

apiRouter.get('/leaderboard', (req, res) => {
  const period = String(req.query.period || 'all');
  const competitionId = String(req.query.competitionId || '').trim();
  const className = String(req.query.className || '').trim();

  let dateFilter = '';
  const params: Array<string> = [];

  if (period === 'daily') {
    const since = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
    dateFilter = 'AND p.joined_at >= ?';
    params.push(since);
  } else if (period === 'weekly') {
    const since = new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString();
    dateFilter = 'AND p.joined_at >= ?';
    params.push(since);
  } else if (period === 'monthly') {
    const since = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();
    dateFilter = 'AND p.joined_at >= ?';
    params.push(since);
  } else if (period === 'competition' && competitionId) {
    dateFilter = 'AND p.competition_id = ?';
    params.push(competitionId);
  } else if (period === 'class' && className) {
    dateFilter = 'AND p.class_name = ?';
    params.push(className);
  }

  const entries = db
    .prepare(
      `SELECT p.id, p.display_name, p.class_name, p.score, p.correct_count, p.wrong_count, p.total_time_ms, p.joined_at,
              c.id as competition_id, c.title as competition_title, c.code as competition_code, g.subject, g.language
       FROM participants p
       JOIN competitions c ON c.id = p.competition_id
       JOIN games g ON g.id = c.game_id
       WHERE 1=1 ${dateFilter}
       ORDER BY p.score DESC, p.correct_count DESC, p.total_time_ms ASC, p.wrong_count ASC
       LIMIT 100`
    )
    .all(...params) as Array<Record<string, unknown>>;

  const competitions = db
    .prepare('SELECT id, title, code, status FROM competitions ORDER BY created_at DESC LIMIT 30')
    .all();

  const classes = db
    .prepare("SELECT DISTINCT class_name FROM participants WHERE class_name != '' ORDER BY class_name ASC")
    .all() as Array<{ class_name: string }>;

  res.json({
    entries: entries.map((e, idx) => ({
      rank: idx + 1,
      id: e.id,
      displayName: e.display_name,
      className: e.class_name,
      score: e.score,
      correctCount: e.correct_count,
      wrongCount: e.wrong_count,
      totalTimeMs: e.total_time_ms,
      competitionId: e.competition_id,
      competitionTitle: e.competition_title,
      competitionCode: e.competition_code,
      subject: e.subject,
      language: e.language,
      joinedAt: e.joined_at,
    })),
    competitions,
    classes: classes.map((c) => c.class_name),
  });
});

/* ==================== ADMIN ROUTES ==================== */

apiRouter.get('/admin/overview', requireAuth, requireRole('admin'), (_req, res) => {
  const stats = {
    totalUsers: (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c,
    totalGames: (db.prepare('SELECT COUNT(*) as c FROM games').get() as { c: number }).c,
    totalCompetitions: (db.prepare('SELECT COUNT(*) as c FROM competitions').get() as { c: number }).c,
    totalParticipants: (db.prepare('SELECT COUNT(*) as c FROM participants').get() as { c: number }).c,
    totalAiRequests: (db.prepare('SELECT COUNT(*) as c FROM ai_usage_logs').get() as { c: number }).c,
  };

  const users = db
    .prepare('SELECT id, full_name, login, email, role, preferred_lang, is_active, created_at FROM users ORDER BY created_at DESC')
    .all();

  const aiLogs = db
    .prepare(
      `SELECT l.*, u.full_name as user_name
       FROM ai_usage_logs l
       JOIN users u ON u.id = l.user_id
       ORDER BY l.created_at DESC
       LIMIT 40`
    )
    .all();

  res.json({ stats, users, aiLogs });
});

apiRouter.get('/admin/ai-settings', requireAuth, requireRole('admin'), (_req, res) => {
  const row = db.prepare('SELECT * FROM ai_settings WHERE id = 1').get() as {
    active_provider: AIProvider;
    openai_key_enc: string | null;
    anthropic_key_enc: string | null;
    daily_limit_per_teacher: number;
    updated_at: string;
  };

  const openaiDec = decryptSecret(row.openai_key_enc) || process.env.OPENAI_API_KEY || null;
  const anthropicDec = decryptSecret(row.anthropic_key_enc) || process.env.ANTHROPIC_API_KEY || null;
  const geminiConfigured = Boolean(
    process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'
  );

  res.json({
    activeProvider: row.active_provider,
    dailyLimitPerTeacher: row.daily_limit_per_teacher,
    providers: {
      gemini: {
        configured: geminiConfigured,
        managedByServerEnv: true,
      },
      openai: {
        configured: Boolean(openaiDec),
        maskedKey: maskSecret(openaiDec),
      },
      anthropic: {
        configured: Boolean(anthropicDec),
        maskedKey: maskSecret(anthropicDec),
      },
    },
    updatedAt: row.updated_at,
  });
});

apiRouter.put('/admin/ai-settings', requireAuth, requireRole('admin'), (req, res) => {
  const { activeProvider, dailyLimitPerTeacher, openaiKey, anthropicKey, clearOpenaiKey, clearAnthropicKey } =
    req.body || {};

  const existing = db.prepare('SELECT * FROM ai_settings WHERE id = 1').get() as {
    active_provider: AIProvider;
    openai_key_enc: string | null;
    anthropic_key_enc: string | null;
    daily_limit_per_teacher: number;
  };

  const nextProvider: AIProvider = ['gemini', 'openai', 'anthropic'].includes(activeProvider)
    ? activeProvider
    : existing.active_provider;

  const nextLimit = dailyLimitPerTeacher
    ? Math.min(Math.max(Number(dailyLimitPerTeacher), 1), 500)
    : existing.daily_limit_per_teacher;

  let nextOpenai = existing.openai_key_enc;
  if (clearOpenaiKey) {
    nextOpenai = null;
  } else if (typeof openaiKey === 'string' && openaiKey.trim().length > 0) {
    nextOpenai = encryptSecret(openaiKey.trim());
  }

  let nextAnthropic = existing.anthropic_key_enc;
  if (clearAnthropicKey) {
    nextAnthropic = null;
  } else if (typeof anthropicKey === 'string' && anthropicKey.trim().length > 0) {
    nextAnthropic = encryptSecret(anthropicKey.trim());
  }

  const now = new Date().toISOString();
  db.prepare(
    `UPDATE ai_settings
     SET active_provider = ?, openai_key_enc = ?, anthropic_key_enc = ?, daily_limit_per_teacher = ?, updated_at = ?
     WHERE id = 1`
  ).run(nextProvider, nextOpenai, nextAnthropic, nextLimit, now);

  res.json({ updated: true, activeProvider: nextProvider, dailyLimitPerTeacher: nextLimit });
});

apiRouter.patch('/admin/users/:id/role', requireAuth, requireRole('admin'), (req: AuthedRequest, res) => {
  const targetId = String(req.params.id);
  const { role, isActive } = req.body || {};

  if (targetId === req.user!.userId && isActive === false) {
    res.status(400).json({ error: 'Cannot disable your own admin account.' });
    return;
  }

  if (role === 'teacher' || role === 'admin') {
    db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, targetId);
  }
  if (typeof isActive === 'boolean') {
    db.prepare('UPDATE users SET is_active = ? WHERE id = ?').run(isActive ? 1 : 0, targetId);
  }

  res.json({ updated: true });
});

apiRouter.get('/admin/export-deploy-zip', requireAuth, requireRole('admin'), (_req, res) => {
  try {
    // Flush any pending WAL frames into data/iq_puzzle.db before packaging
    db.exec('PRAGMA wal_checkpoint(TRUNCATE);');
    const { buffer } = buildProjectDeployZip(process.cwd());
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="iq-puzzle-server-deploy.zip"');
    res.setHeader('Content-Length', String(buffer.length));
    res.send(buffer);
  } catch (err) {
    res.status(500).json({
      error: err instanceof Error ? err.message : 'Failed to build deployment ZIP archive',
    });
  }
});
