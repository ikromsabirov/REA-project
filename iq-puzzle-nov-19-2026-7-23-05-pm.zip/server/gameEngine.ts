import { db } from './db.ts';
import type { GameCategoryId, GameTypeId } from '../src/games/types.ts';
import { toNewUzbekAlphabet } from '../src/utils/uzbekAlphabet.ts';

export const CATEGORY_BY_GAME_TYPE: Record<GameTypeId | 'quiz', GameCategoryId> = {
  quiz: 'logic',
  'iq-matrix': 'logic',
  sequence: 'logic',
  'logic-grid': 'logic',
  matchstick: 'logic',
  'odd-one-out': 'logic',
  'memory-cards': 'memory',
  'simon-memory': 'memory',
  'image-memory': 'memory',
  'number-memory': 'memory',
  'rotation-3d': 'spatial',
  'paper-folding': 'spatial',
  tangram: 'spatial',
  'cube-net': 'spatial',
  'find-difference': 'attention',
  stroop: 'attention',
  'hidden-objects': 'attention',
  'number-search': 'attention',
  sudoku: 'math',
  'number-crossword': 'math',
  'make-24': 'math',
  'number-pyramid': 'math',
  'word-search': 'words',
  anagram: 'words',
  rebus: 'words',
  'word-association': 'words',
};

export function resolveCategoryForGameType(gameType: string): GameCategoryId {
  return CATEGORY_BY_GAME_TYPE[gameType as GameTypeId] || 'logic';
}

export function deterministicSeedFromId(id: string): number {
  let hash = 2166136261;
  for (let i = 0; i < id.length; i++) {
    hash ^= id.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export function calculateServerStagePoints(params: {
  isCorrect: boolean;
  timeTakenMs: number;
  timeLimitSec: number;
  hintsUsed?: number;
  basePoints?: number;
}): number {
  if (!params.isCorrect) return 0;
  const base = params.basePoints ?? 100;
  const limitMs = Math.max(1000, params.timeLimitSec * 1000);
  const ratio = Math.max(0, Math.min(1, (limitMs - params.timeTakenMs) / limitMs));
  const speedBonus = Math.round(50 * ratio);
  const hintPenalty = Math.max(0, params.hintsUsed ?? 0) * 10;
  return Math.max(10, base + speedBonus - hintPenalty);
}

/**
 * Clamp and verify submitted game summary on the server against unified scoring bounds:
 * - Max per stage = 150 (100 base + 50 speed bonus)
 */
export function sanitizeSubmittedGameResult(params: {
  stagesCount: number;
  correctCount: number;
  wrongCount: number;
  hintsUsed: number;
  timeSpentMs: number;
  reportedScore: number;
}): {
  score: number;
  maxScore: number;
  correctCount: number;
  wrongCount: number;
  hintsUsed: number;
  timeSpentMs: number;
  accuracy: number;
} {
  const totalStages = Math.max(1, Math.min(50, Math.round(params.stagesCount)));
  const correctCount = Math.max(0, Math.min(totalStages, Math.round(params.correctCount)));
  const wrongCount = Math.max(0, Math.min(totalStages, Math.round(params.wrongCount)));
  const hintsUsed = Math.max(0, Math.min(50, Math.round(params.hintsUsed)));
  const timeSpentMs = Math.max(200, Math.min(3600000, Math.round(params.timeSpentMs)));
  const maxScore = totalStages * 150;
  const hardCap = Math.max(0, correctCount * 150 - hintsUsed * 10);
  const clampedScore = Math.max(0, Math.min(hardCap, Math.round(params.reportedScore)));
  const accuracy = Math.round((correctCount / totalStages) * 100);

  return {
    score: clampedScore,
    maxScore,
    correctCount,
    wrongCount,
    hintsUsed,
    timeSpentMs,
    accuracy,
  };
}

export interface StudentProfileSummary {
  studentKey: string;
  totalSessions: number;
  totalScore: number;
  avgAccuracy: number;
  dimensions: {
    logic: number;
    memory: number;
    spatial: number;
    attention: number;
    math: number;
    words: number;
    speed: number;
  };
  history: Array<{
    id: string;
    source: 'practice' | 'competition';
    gameType: string;
    category: GameCategoryId;
    score: number;
    maxScore: number;
    accuracy: number;
    timeSpentMs: number;
    createdAt: string;
  }>;
  disclaimer: Record<'uz' | 'ru' | 'en', string>;
}

export function buildStudentProfile(studentKey: string, studentName?: string): StudentProfileSummary {
  const practiceRows = db
    .prepare(
      `SELECT id, game_type, category, score, max_score, accuracy, time_spent_ms, created_at
       FROM practice_results
       WHERE student_key = ? OR LOWER(student_name) = LOWER(?)
       ORDER BY created_at DESC
       LIMIT 100`
    )
    .all(studentKey, studentName || studentKey) as Array<{
    id: string;
    game_type: string;
    category: GameCategoryId;
    score: number;
    max_score: number;
    accuracy: number;
    time_spent_ms: number;
    created_at: string;
  }>;

  const compRows = studentName
    ? (db
        .prepare(
          `SELECT p.id, g.game_type, g.category, p.score, p.correct_count, p.wrong_count, p.total_time_ms, p.joined_at
           FROM participants p
           JOIN competitions c ON c.id = p.competition_id
           JOIN games g ON g.id = c.game_id
           WHERE LOWER(p.display_name) = LOWER(?)
           ORDER BY p.joined_at DESC
           LIMIT 50`
        )
        .all(studentName) as Array<{
        id: string;
        game_type: string;
        category: GameCategoryId;
        score: number;
        correct_count: number;
        wrong_count: number;
        total_time_ms: number;
        joined_at: string;
      }>)
    : [];

  const history: StudentProfileSummary['history'] = [
    ...practiceRows.map((r) => ({
      id: r.id,
      source: 'practice' as const,
      gameType: r.game_type,
      category: r.category,
      score: r.score,
      maxScore: Math.max(1, r.max_score),
      accuracy: r.accuracy,
      timeSpentMs: r.time_spent_ms,
      createdAt: r.created_at,
    })),
    ...compRows.map((c) => {
      const totalQ = Math.max(1, c.correct_count + c.wrong_count);
      return {
        id: c.id,
        source: 'competition' as const,
        gameType: c.game_type,
        category: c.category || resolveCategoryForGameType(c.game_type),
        score: c.score,
        maxScore: totalQ * 150,
        accuracy: Math.round((c.correct_count / totalQ) * 100),
        timeSpentMs: c.total_time_ms,
        createdAt: c.joined_at,
      };
    }),
  ].sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  const buckets: Record<GameCategoryId, number[]> = {
    logic: [],
    memory: [],
    spatial: [],
    attention: [],
    math: [],
    words: [],
  };
  const speedScores: number[] = [];

  for (const h of history) {
    const pct = Math.min(100, Math.max(0, Math.round((h.score / h.maxScore) * 100)));
    if (buckets[h.category]) {
      buckets[h.category].push(pct);
    }
    const speedFactor = Math.min(100, Math.max(20, Math.round((h.accuracy * 0.6) + (pct * 0.4))));
    speedScores.push(speedFactor);
  }

  const avg = (arr: number[]) =>
    arr.length === 0 ? 0 : Math.round(arr.reduce((a, b) => a + b, 0) / arr.length);

  const totalScore = history.reduce((acc, h) => acc + h.score, 0);
  const avgAccuracy = avg(history.map((h) => h.accuracy));

  return {
    studentKey,
    totalSessions: history.length,
    totalScore,
    avgAccuracy,
    dimensions: {
      logic: avg(buckets.logic),
      memory: avg(buckets.memory),
      spatial: avg(buckets.spatial),
      attention: avg(buckets.attention),
      math: avg(buckets.math),
      words: avg(buckets.words),
      speed: avg(speedScores),
    },
    history: history.slice(0, 40),
    disclaimer: {
      uz: toNewUzbekAlphabet(
        "Izoh: Ushbu ko'rsatkichlar faqat platformadagi o'yin natijalari asosida hisoblanadi va klinik yoki standartlashtirilgan IQ testi hisoblanmaydi."
      ),
      ru: 'Примечание: данные показатели отражают результаты выполнения заданий на платформе и не являются клиническим тестом IQ.',
      en: 'Note: These scores reflect performance on platform intellectual tasks only and are not a clinical or standardized IQ assessment.',
    },
  };
}
