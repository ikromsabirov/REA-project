import { GoogleGenAI, Type } from '@google/genai';
import crypto from 'crypto';
import { db } from './db.ts';
import { decryptSecret } from './crypto.ts';
import { formatByLanguage } from '../src/utils/uzbekAlphabet.ts';

export type AIProvider = 'gemini' | 'openai' | 'anthropic';
export type GameLang = 'uz' | 'ru' | 'en';

export interface GeneratedQuestion {
  prompt: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
}

interface AISettingsRow {
  active_provider: AIProvider;
  openai_key_enc: string | null;
  anthropic_key_enc: string | null;
  daily_limit_per_teacher: number;
}

function getAISettings(): AISettingsRow {
  const row = db
    .prepare(
      'SELECT active_provider, openai_key_enc, anthropic_key_enc, daily_limit_per_teacher FROM ai_settings WHERE id = 1'
    )
    .get() as AISettingsRow | undefined;
  return (
    row ?? {
      active_provider: 'gemini',
      openai_key_enc: null,
      anthropic_key_enc: null,
      daily_limit_per_teacher: 30,
    }
  );
}

function checkTeacherDailyLimit(userId: string, limit: number): void {
  const startOfDay = new Date();
  startOfDay.setUTCHours(0, 0, 0, 0);
  const row = db
    .prepare(
      `SELECT COUNT(*) as cnt FROM ai_usage_logs
       WHERE user_id = ? AND status = 'success' AND created_at >= ?`
    )
    .get(userId, startOfDay.toISOString()) as { cnt: number };
  if (row.cnt >= limit) {
    throw new Error(
      `Daily AI generation limit reached (${row.cnt}/${limit}). Contact administrator to increase quota.`
    );
  }
}

function buildSystemInstruction(
  lang: GameLang,
  subject: string,
  difficulty: string,
  gameType = 'quiz',
  ageGrade = '',
  customInstructions = ''
): string {
  const langLabel =
    lang === 'uz'
      ? 'Uzbek (Latin script, clear educational academic Uzbek)'
      : lang === 'ru'
        ? 'Russian (clear academic Russian)'
        : 'English (clear academic English)';

  return [
    `You are an expert academic puzzle and game designer for an intellectual competition platform (IQ PUZZLE).`,
    `Generate original, accurate, non-trivial tasks tailored for game type "${gameType}" strictly in ${langLabel}.`,
    `Subject / Topic area: ${subject}. Difficulty level: ${difficulty}.`,
    ageGrade ? `Target age / grade level: ${ageGrade}.` : '',
    customInstructions ? `Additional teacher instructions: ${customInstructions}` : '',
    `Each generated item MUST have:`,
    `- "prompt": clear challenge text, rule, or puzzle statement appropriate for "${gameType}"`,
    `- "options": array of exactly 4 distinct answer strings`,
    `- "correctIndex": integer 0, 1, 2, or 3 indicating the single correct option`,
    `- "explanation": concise, educational step-by-step explanation of why the answer is correct`,
    `Return ONLY valid JSON matching the requested schema.`,
  ]
    .filter(Boolean)
    .join('\n');
}

function validateQuestions(raw: unknown, lang: GameLang): GeneratedQuestion[] {
  let list: unknown[] = [];
  if (Array.isArray(raw)) {
    list = raw;
  } else if (raw && typeof raw === 'object' && Array.isArray((raw as { questions?: unknown[] }).questions)) {
    list = (raw as { questions: unknown[] }).questions;
  }

  if (list.length === 0) {
    throw new Error('AI returned an empty task list.');
  }

  return list.map((item, idx) => {
    const q = item as Record<string, unknown>;
    const promptRaw = typeof q.prompt === 'string' ? q.prompt.trim() : '';
    const optsRaw = Array.isArray(q.options) ? q.options.map((o) => String(o).trim()) : [];
    const correctIdx = Number(q.correctIndex);
    const explanationRaw = typeof q.explanation === 'string' ? q.explanation.trim() : '';

    if (!promptRaw || optsRaw.length !== 4 || optsRaw.some((o) => !o)) {
      throw new Error(`AI task #${idx + 1} failed structural validation.`);
    }
    if (!Number.isInteger(correctIdx) || correctIdx < 0 || correctIdx > 3) {
      throw new Error(`AI task #${idx + 1} has invalid correctIndex.`);
    }

    return {
      prompt: formatByLanguage(promptRaw, lang),
      options: [
        formatByLanguage(optsRaw[0], lang),
        formatByLanguage(optsRaw[1], lang),
        formatByLanguage(optsRaw[2], lang),
        formatByLanguage(optsRaw[3], lang),
      ],
      correctIndex: correctIdx,
      explanation: formatByLanguage(explanationRaw || '—', lang),
    };
  });
}

async function generateWithGemini(
  prompt: string,
  systemInstruction: string,
  count: number
): Promise<{ questions: unknown; tokens: number }> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY is not configured on the server.');
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: `${prompt}\n\nGenerate exactly ${count} tasks.`,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            prompt: { type: Type.STRING, description: 'Task or puzzle prompt text' },
            options: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Exactly 4 answer choices',
            },
            correctIndex: {
              type: Type.INTEGER,
              description: '0-based index of the correct option (0 to 3)',
            },
            explanation: {
              type: Type.STRING,
              description: 'Concise educational explanation',
            },
          },
          required: ['prompt', 'options', 'correctIndex', 'explanation'],
        },
      },
    },
  });

  const text = (response.text ?? '[]').trim();
  const parsed = JSON.parse(text);
  const tokens = response.usageMetadata?.totalTokenCount ?? 0;
  return { questions: parsed, tokens };
}

async function generateWithOpenAI(
  apiKey: string,
  prompt: string,
  systemInstruction: string,
  count: number
): Promise<{ questions: unknown; tokens: number }> {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      response_format: { type: 'json_object' },
      messages: [
        {
          role: 'system',
          content: `${systemInstruction}\nOutput JSON object with key "questions": Array<{ prompt: string, options: string[4], correctIndex: number, explanation: string }>.`,
        },
        { role: 'user', content: `${prompt}\nGenerate exactly ${count} tasks.` },
      ],
    }),
  });

  const data = (await res.json()) as {
    error?: { message?: string };
    choices?: Array<{ message?: { content?: string } }>;
    usage?: { total_tokens?: number };
  };

  if (!res.ok) {
    throw new Error(data.error?.message || `OpenAI API error (${res.status})`);
  }

  const content = data.choices?.[0]?.message?.content || '{}';
  return {
    questions: JSON.parse(content),
    tokens: data.usage?.total_tokens ?? 0,
  };
}

async function generateWithAnthropic(
  apiKey: string,
  prompt: string,
  systemInstruction: string,
  count: number
): Promise<{ questions: unknown; tokens: number }> {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-3-5-haiku-latest',
      max_tokens: 4096,
      system: `${systemInstruction}\nReturn ONLY raw JSON array of objects: [{ "prompt": string, "options": [string,string,string,string], "correctIndex": number, "explanation": string }].`,
      messages: [{ role: 'user', content: `${prompt}\nGenerate exactly ${count} tasks.` }],
    }),
  });

  const data = (await res.json()) as {
    error?: { message?: string };
    content?: Array<{ text?: string }>;
    usage?: { input_tokens?: number; output_tokens?: number };
  };

  if (!res.ok) {
    throw new Error(data.error?.message || `Anthropic API error (${res.status})`);
  }

  const text = (data.content?.[0]?.text || '[]')
    .trim()
    .replace(/^```json\s*/i, '')
    .replace(/```$/, '')
    .trim();
  const tokens = (data.usage?.input_tokens ?? 0) + (data.usage?.output_tokens ?? 0);
  return { questions: JSON.parse(text), tokens };
}

export async function generateQuestionsWithAI(params: {
  userId: string;
  topic: string;
  language: GameLang;
  subject: string;
  difficulty: string;
  count: number;
  gameType?: string;
  ageGrade?: string;
  customInstructions?: string;
  preferredProvider?: AIProvider;
}): Promise<{ provider: AIProvider; questions: GeneratedQuestion[]; tokensUsed: number }> {
  const settings = getAISettings();
  checkTeacherDailyLimit(params.userId, settings.daily_limit_per_teacher);

  const provider: AIProvider = params.preferredProvider || settings.active_provider || 'gemini';
  const count = Math.min(Math.max(Number(params.count) || 5, 1), 20);
  const systemInstruction = buildSystemInstruction(
    params.language,
    params.subject,
    params.difficulty,
    params.gameType || 'quiz',
    params.ageGrade || '',
    params.customInstructions || ''
  );
  const userPrompt = `Game Type: ${params.gameType || 'quiz'}\nTopic: ${params.topic}`;

  try {
    let rawResult: { questions: unknown; tokens: number };

    if (provider === 'openai') {
      const key = decryptSecret(settings.openai_key_enc) || process.env.OPENAI_API_KEY;
      if (!key) {
        throw new Error('OpenAI API key is not configured in Admin Panel or .env.');
      }
      rawResult = await generateWithOpenAI(key, userPrompt, systemInstruction, count);
    } else if (provider === 'anthropic') {
      const key = decryptSecret(settings.anthropic_key_enc) || process.env.ANTHROPIC_API_KEY;
      if (!key) {
        throw new Error('Anthropic API key is not configured in Admin Panel or .env.');
      }
      rawResult = await generateWithAnthropic(key, userPrompt, systemInstruction, count);
    } else {
      rawResult = await generateWithGemini(userPrompt, systemInstruction, count);
    }

    const validated = validateQuestions(rawResult.questions, params.language);

    db.prepare(
      `INSERT INTO ai_usage_logs (id, user_id, provider, topic, language, question_count, tokens_used, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'success', ?)`
    ).run(
      crypto.randomUUID(),
      params.userId,
      provider,
      params.topic,
      params.language,
      validated.length,
      rawResult.tokens,
      new Date().toISOString()
    );

    return {
      provider,
      questions: validated,
      tokensUsed: rawResult.tokens,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown AI generation error';
    db.prepare(
      `INSERT INTO ai_usage_logs (id, user_id, provider, topic, language, question_count, tokens_used, status, error_message, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 0, 'error', ?, ?)`
    ).run(
      crypto.randomUUID(),
      params.userId,
      provider,
      params.topic,
      params.language,
      count,
      message,
      new Date().toISOString()
    );
    throw err;
  }
}
